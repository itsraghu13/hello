---
name: lakebridge-cdc-refactor
description: >
  End-to-end pipeline skill: analyzes, refactors, and standardizes any
  Lakebridge-converted Databricks PySpark ETL pipeline from CDC-based
  (Change Data Capture) processing into a single clean insert-only notebook.
  Phase 0 analyzes the input (script + notebooks) and pauses for confirmation.
  Phases 1-7 strip CDC logic (NetChange, Updates, Deletes, Inserts_Key) and
  merge the insert path. Phase 8 runs a full standardizer pass on the output.
  Use this skill whenever a user has a folder of PySpark notebooks generated
  by IBM Lakebridge / DataStage and wants to remove CDC logic and produce a
  single clean merged Databricks notebook that runs as an insert-only ETL
  process. Trigger on: "refactor ETL", "remove CDC logic", "insert-only
  pipeline", "Lakebridge notebook", "simplify ETL", "merge notebooks",
  "strip CDC", "remove NetChange", "insert-only refactor", or any mention of
  stripping NetChange / CDC comparison stages from PySpark notebooks.
  Works on any pipeline — not specific to any job name or table name.
---

# Lakebridge CDC-to-Insert Refactor Skill

End-to-end: analyze → CDC refactor → standardize.
Converts a Lakebridge-generated multi-notebook CDC pipeline into a single
clean insert-only Databricks PySpark notebook. Works on any pipeline folder
regardless of job name, domain, or table names.

---

## HARD RULES — read before every phase, never violate

**Transformation preservation — absolute:**
- NEVER drop a `.withColumn()`, `.select()`, `.filter()`, `.join()`, `.agg()`,
  or `.withColumnRenamed()` call unless it operates directly on a CDC comparison
  DataFrame (see CDC detection rules in Phase 2)
- NEVER rename DataFrame variables — if the original code uses `lnkTransIns`,
  it stays `lnkTransIns` throughout the merged notebook
- NEVER collapse or merge `.withColumn()` chains — preserve them exactly as written
- NEVER reorder transformations — preserve the exact sequence within each step

**Traceability block preservation — absolute:**
- Every cell that has a `# Processing node` / `# Node type` / `# Column count` /
  `# Original DS name` / `# Input link(s)` / `# Output link(s)` comment block
  MUST carry that block into the merged notebook, unchanged, on the same cell
- When intermediate table writes are eliminated and DataFrames are passed
  directly, keep the traceability block from the write cell on the passthrough comment

**Stage variable tracking — absolute:**
- Before removing any block, record every DataFrame variable name produced by
  non-CDC code in Step03. These variables must be reachable from Step05.
- If Step03 produces `df_inserts_no_key`, `lnkInserts`, `lnkTransIns` (or any
  equivalent) via non-CDC transformation — that variable must exist in the
  merged notebook and be wired to Step05's input

**CDC removal — absolute:**
- Remove ONLY code that depends on the comparison of SRC_CHG_DATA vs TGT_3NF_DATA
  (the NetChange join and everything downstream of it)
- When in doubt whether a block is CDC or business logic — KEEP IT and add
  `# REVIEW: verify this block is not CDC-specific`

---

## Phase 0: Analysis + Confirmation (runs before any refactor)

**This phase always runs first. No code is generated until the user types `proceed`.**

### 0.1 — Load reference files

Load these files before doing anything else:

**Always load:**
- `../../databricks-pipeline-advisor/references/analysis-rules.md`
- `../../datastage-notebook-standardizer/references/fix-rules.md`

**Load only if a `.ksh` / `.sh` / `.bash` file or shell script content is present:**
- `../../databricks-pipeline-advisor/references/script-analysis-rules.md`

**Load only if any of these patterns appear in any notebook input:**
Stage patterns trigger: `AGGREGATOR` `PIVOT` `MISSING_HANDLER` `SCD` `LOOKUP` `CHANGE_CAPTURE` `FUNNEL` `REMOVE_DUPLICATES` `DEDUP` `groupBy(` `.join(` `orderBy(` `Window.` `.over(` `union(` `unionAll(` `dropDuplicates(`
→ `../../datastage-notebook-standardizer/references/stage-patterns.md`

Expression map trigger: `Space(` `Field(` `@INROWNUM` `@NUMROWS` `@OUTROWNUM` `@NULL` `Iconv(` `Oconv(` `CurrentTimestamp(` `LENGTH(` `SUBSTRING(` `%yyyy` `%mm`
→ `../../datastage-notebook-standardizer/references/expression-map.md`

Read each loaded file fully before inspecting any input.

### 0.2 — Analyze script (if present)

If a shell script is detected, run the full script analysis from
`script-analysis-rules.md` Phases 1–5:
- Classify script type (ORCHESTRATION / PRE-PROCESSING / POST-PROCESSING / MIXED)
- Extract script profile: `script_name`, `ds_job_name`, `source_table`, `target_table`, `data_logic`
- Map script to notebooks by job ID + content match
- Discard shell infrastructure (DS job invocation, audit params, logging — see discard list)

### 0.3 — Index notebooks

For each notebook provided, extract using `analysis-rules.md` extraction rules:
- `file_name`, `seq_no`, `domain` — from filename
- `sources`, `targets` — from SRC/TGT widgets → spark.read/saveAsTable → traceability comments
- `stage_types` — from `# Node type` traceability comments
- `cell_count`

If script profile exists: override source_table / target_table widget defaultValues
with values from the script profile.

### 0.4 — Confirm CDC pattern

For the notebook identified as Step03 (CDC hub), verify these signals:
- Contains a `full_outer` or `inner` join between SRC_CHG_DATA and TGT_3NF_DATA (or their equivalent variable names from Step01/Step02 outputs)
- Contains `CHANGE_CAPTURE` or `CDC` stage type in traceability comments, OR contains CDC flag columns (`_cdc_flag`, `_change_type`, `CDC_FLAG`) used to split streams
- Produces multiple output streams (Inserts, Updates, Deletes)

**TRANSFORMER alone is NOT a CDC signal — it is present in almost every notebook. Only the join pattern and CDC flag columns confirm CDC.**

If CDC pattern NOT found in any notebook: report "No CDC pattern detected — this
pipeline may not need CDC refactoring. Verify input notebooks are correct."
Then STOP — do not proceed to refactor without user confirmation.

### 0.5 — Output ANALYSIS REPORT and pause

Output the following report, then stop and wait for the user to type `proceed`.

```
LAKEBRIDGE CDC REFACTOR — PIPELINE ANALYSIS
────────────────────────────────────────────────────────────────────
Pipeline  : {PIPELINE_NAME — common domain/job ID across notebooks}
Notebooks : {n}   Script: {script_name.ksh | NONE}
────────────────────────────────────────────────────────────────────

{If script present — paste SCRIPT ANALYSIS section from script-analysis-rules.md report format}

NOTEBOOK INDEX
  File                       Seq  Sources          Targets          Stage Types
  ─────────────────────────────────────────────────────────────────────────────
  {filename}                 {n}  {table or ?}     {table or ?}     {list}

EXECUTION ORDER (inferred from dependencies)
  STAGE 1: {notebook names}
  STAGE 2 (depends on Stage 1): {notebook names}
  ...

CDC CONFIRMATION
  CDC hub notebook : {Step03 filename}
  NetChange join   : {detected | NOT DETECTED — see warning above}
  CDC streams      : Inserts ✓   Updates ✓   Deletes ✓   Inserts_Key ✓
                     (✗ if not found — note any missing streams)
  INSERT_OUTPUT_VAR: {variable name or ? if not yet identified}

REFACTOR PLAN
  KEEP  : {source unload notebook filename} (source unload — full preservation)
  KEEP  : {target snapshot notebook filename} (target snapshot — full preservation)
  STRIP : {CDC hub notebook filename} → CDC blocks removed, insert path only
  {KEEP : {Step04 filename} (in insert chain) | EXCLUDE : {Step04 filename} — not in insert chain}
  REWIRE: {Step05 filename} input → {INSERT_OUTPUT_VAR} (in-memory, no Delta read)
  ELIMINATE intermediate tables: {list of tables to be removed}
  OUTPUT: {PIPELINE_NAME}_insert_only_merged.py

STANDARDIZER PASS (Phase 8 — runs automatically after merge)
  Will apply: Groups G Q R N I L S SEC from fix-rules.md
  Fix table will be included in final output summary.

────────────────────────────────────────────────────────────────────
Type `proceed` to start CDC refactor.
Type `abort` to stop.
────────────────────────────────────────────────────────────────────
```

Do not output any code until the user types `proceed`.
On `proceed`: run Phases 1–7 (CDC refactor), then immediately run Phase 8 (standardizer).
On `abort`: stop entirely.

---

## Overview of the Lakebridge CDC Pipeline Pattern

Lakebridge-converted pipelines typically follow this step structure.
Step names, domains, and job IDs vary — use the ROLE column to identify
each notebook, not the exact name.

| Step | Name pattern (example) | Role | Key signals |
|------|------------------------|------|-------------|
| Step01 | `Step01_Unload_<SRC>_CHG_*` | Unload source change data → `SRC_CHG_DATA` | Reads source system / change table |
| Step02 | `Step02_Unload_<TGT>_*` | Unload target snapshot → `TGT_3NF_DATA` | Reads target Delta table |
| Step03 | `Step03_CDC_<TGT>_*` | CDC hub — compare SRC vs TGT, split streams | Contains NetChange / full_outer join |
| Step04 | `Step04_Unl_Strt_SurNo_*` | Surrogate key unload (optional) | May feed insert stream |
| Step05 | `Step05_Ins_<TGT>_*` | Insert stream → target table | Reads Inserts_No_Key / insert DataFrame |
| Step06+ | `Step06_Upd_*`, audit steps | Update / audit (excluded from refactor) | Not in insert path |

**Target output:** Single merged notebook:
`Step01 → Step02 → Step03 (insert path only) → [Step04 if in insert chain] → Step05 → target table`

---

## Phase 1: Discover and Map the Notebooks

### 1.1 Accept input

Accept any of: filenames only, full notebook content pasted, folder path.
For each notebook provided, extract its ETL role using the signals below.
Do NOT assume step numbering is sequential — gaps are common (Step01, Step02, Step03, Step05).

### 1.2 Identify roles from content signals

For each notebook, scan for these signals to confirm its role:

**Step01 (source unload):**
- Reads from a source or staging table (not the final target)
- Produces a DataFrame written to `SRC_CHG_DATA` or equivalent
- May contain lookup joins and transformer stages

**Step02 (target snapshot):**
- Reads from the pipeline's target Delta table
- Produces a DataFrame written to `TGT_3NF_DATA` or equivalent
- Usually simple: read → minimal transform → write/assign

**Step03 (CDC hub — the key step to refactor):**
- Contains a full_outer or inner join between SRC_CHG_DATA and TGT_3NF_DATA
- Produces multiple output streams: Inserts, Updates, Deletes, Inserts_Key
- Contains stage names: `NetChange`, `TransIns`, `TransUpd`, `TransDel`
- Contains filter patterns: `_cdc_flag`, `_change_type`, `INROWNUM`, change type columns

**Step04 (surrogate key — conditional):**
- Contains surrogate key generation: `SURROGATE_KEY`, `monotonically_increasing_id()`,
  `row_number()` over a window with no partition
- Determine if it is in the INSERT chain (see Phase 3 for detection rule)

**Step05 (insert into target):**
- Reads from `Inserts_No_Key`, `lnkInserts`, or equivalent insert stream
- Writes to the final target table
- Contains `TransInsert` stage or equivalent insert transformation

### 1.3 Catalog all stage variables before touching any code

Before any removal, build a **stage variable map** for Step03:

```
STAGE VARIABLE MAP — Step03
─────────────────────────────────────────────────────
Variable name          | Source                 | CDC? | Keep?
───────────────────────|────────────────────────|──────|──────
df_tgt_3nf_data        | input (from Step02)    | No   | YES
df_src_chg_data        | input (from Step01)    | No   | YES (input only)
df_net_change          | join of src + tgt      | YES  | REMOVE
df_inserts             | df_net_change.filter() | YES  | REMOVE
df_updates             | df_net_change.filter() | YES  | REMOVE
df_deletes             | df_net_change.filter() | YES  | REMOVE
df_inserts_key         | df_net_change.filter() | YES  | REMOVE
lnkTransIns            | df_tgt_3nf_data.select/withColumn | No | YES
df_inserts_no_key      | lnkTransIns or tgt transform      | No | YES — wire to Step05
```

Fill this map from the actual notebook before proceeding.
Any variable not derived from a CDC comparison DataFrame → mark as KEEP.

---

## Phase 2: Analyse and Strip CDC Logic from Step03

### CDC detection rules — what to REMOVE

A block is CDC and must be removed if it satisfies ANY of these:

1. **NetChange join** — a join (any type) between `SRC_CHG_DATA` and `TGT_3NF_DATA`
   (or their equivalent variables from Step01/Step02 outputs)
2. **CDC-flagged filter** — a `.filter()` on a column that classifies change type:
   `_cdc_flag`, `_change_type`, `CDC_FLAG`, or any equivalent column whose values
   are `'I'`, `'U'`, `'D'`, `'INSERT'`, `'UPDATE'`, `'DELETE'`, `'REINSTATE'`
3. **Update stream** — any DataFrame derived from a CDC filter selecting updates
4. **Delete stream** — any DataFrame derived from a CDC filter selecting deletes
5. **Inserts_Key stream** — inserts that matched on existing key (reinstate/upsert path)
6. **Write of CDC outputs** — `.write` / `.saveAsTable` of update, delete, or inserts_key DataFrames

```python
# REMOVE — NetChange join
df_net_change = tgt_3nf_data.join(src_chg_data, on=[...], how='full_outer')

# REMOVE — CDC flag derivation on the join result
df_flagged = df_net_change.withColumn('_cdc_flag', F.when(...))

# REMOVE — Update/Delete/Inserts_Key filter streams
df_updates     = df_flagged.filter(F.col('_cdc_flag') == 'U')
df_deletes     = df_flagged.filter(F.col('_cdc_flag') == 'D')
df_inserts_key = df_flagged.filter(F.col('_cdc_flag') == 'I_KEY')

# REMOVE — writes of CDC streams
df_updates.write.format('delta').saveAsTable(...)
df_deletes.write.format('delta').saveAsTable(...)
df_inserts_key.write.format('delta').saveAsTable(...)
```

### Transformation preservation rules — what to KEEP

A block must be kept if it satisfies ANY of these:

1. **Reads only TGT_3NF_DATA** (or its equivalent variable) with no join to SRC_CHG_DATA
2. **TransIns logic** — any `.withColumn()`, `.select()`, `.filter()` operating on
   the insert-ready DataFrame that does not reference a CDC comparison column
3. **Column derivations** — `LOAD_DT`, `AUDIT_TS`, `BATCH_NO`, error codes, or any
   business column computed from the insert stream
4. **Insert-path filter** — a `.filter()` that removes records for business reasons
   (null checks, error flags) NOT based on CDC change type
5. **Traceability blocks** — ALL `# Processing node` / `# Node type` comment blocks

```python
# KEEP — reading TGT_3NF_DATA as sole input to insert path
df_tgt = spark.read.format('delta').table(tgt_3nf_table)

# KEEP — TransIns: all column mappings and derivations on insert stream
lnkTransIns = df_tgt.select(
    F.col('SRC_COL').alias('TGT_COL'),
    ...
).withColumn('LOAD_DT', F.current_date()) \
 .withColumn('AUDIT_TS', F.current_timestamp())

# KEEP — insert-path filter (business logic, not CDC type check)
df_inserts_no_key = lnkTransIns.filter(F.col('ERR_CD').isNull())

# KEEP — traceability block (copy verbatim to merged notebook)
# Processing node : lnkInserts
# Node type       : TRANSFORMER
# Column count    : 47
# Original DS name: TransIns
# Input link(s)   : lnkTGT_3NF_DATA  |  Output link(s) : lnkInserts_No_Key
```

**Ambiguous blocks — when not sure:**
- If a transformation is applied to a DataFrame that COULD be either CDC or insert-path,
  check what the DataFrame was assigned from. Trace back to its source.
- If tracing back leads to a CDC join → REMOVE. If it leads to TGT_3NF_DATA alone → KEEP.
- If still ambiguous → KEEP and add `# REVIEW: verify this block is not CDC-specific`

### Identify the insert output variable

After stripping CDC, confirm the final variable that carries the insert-ready records.
This is the variable that Step05 (or Step04 if present) must receive. Common names:

```
df_inserts_no_key   lnkInserts_No_Key   lnkInserts   df_insert_stream
lnkTransIns         df_insert_ready     df_ins       lnkIns
```

Record this as `INSERT_OUTPUT_VAR`. It will be used in Phase 3 rewiring.

---

## Phase 3: Determine if Step04 is in the Insert Chain

Step04 is optional. Include it only if it is in the direct path between Step03 and Step05.

**Detection rule:**
1. Read Step04 content
2. Check if its input is `INSERT_OUTPUT_VAR` or `Inserts_No_Key` or the insert stream name
3. Check if Step05's source matches Step04's output variable
4. If both true → Step04 is in the insert chain → include it between Step03 and Step05
5. If Step04 reads from a different source (e.g. a lookup table, or the target table for
   surrogate key allocation that is NOT tied to the insert stream) → EXCLUDE it and note:
   `# REVIEW: Step04 excluded — not in direct insert chain, verify surrogate key handling`

---

## Phase 4: Rewire Step05

Step05 previously read `Inserts_No_Key` from a Delta intermediate table written by
the CDC step. In the merged notebook, it receives the DataFrame directly.

### Identify Step05's input variable

Scan Step05 for the source read:
```python
# OLD — reads from intermediate table (REMOVE this read)
df_input = spark.read.format('delta').table('Inserts_No_Key')
df_input = spark.read.format('delta').table(inserts_no_key_table)
# or any spark.read pointing to the CDC intermediate output
```

Record the exact variable name used in Step05 as its input: `STEP05_INPUT_VAR`.

### Rewire

Replace the source read with a direct reference:
```python
# NEW — receive insert stream from Step03 (or Step04 if in chain)
{STEP05_INPUT_VAR} = {INSERT_OUTPUT_VAR}   # direct DataFrame handoff from Step03
# Intermediate CDC table eliminated — direct DataFrame passthrough
```

### Preserve everything else in Step05

Keep ALL of the following unchanged:
- Every `.withColumn()`, `.select()`, `.filter()` in TransInsert logic
- All stage variable names (`lnkTransInsert`, `lnkTarget`, or whatever names are used)
- The final `.write.format('delta').saveAsTable(target_table)` call
- Reject handling — the reject path filters and writes

**Reject path rewiring:**
If the reject stream is filtered from the Step05 input DataFrame, update its source
to `STEP05_INPUT_VAR` (which is now wired to `INSERT_OUTPUT_VAR`). The filter logic itself
does not change — only the DataFrame it operates on changes.

```python
# BEFORE
df_rej = spark.read.format('delta').table('Inserts_No_Key') \
              .filter(F.col('REJECT_FLAG') == 'Y')

# AFTER
df_rej = {STEP05_INPUT_VAR}.filter(F.col('REJECT_FLAG') == 'Y')
# REVIEW: reject filter now reads from in-memory DataFrame — verify filter logic unchanged
```

---

## Phase 5: Build the Merged Notebook

Assemble cells in this order. Use `# COMMAND ----------` as the Databricks cell delimiter.

### Cell structure

```
# Databricks notebook source

# COMMAND ----------
# MAGIC %md
# MAGIC # Merged Insert-Only Pipeline: {PIPELINE_NAME}
# MAGIC Refactored: CDC logic removed. Insert path only.
# MAGIC Source notebooks: {list all input notebooks}

# COMMAND ----------
# MAGIC %md
# MAGIC ## 1 — Setup & Imports

# COMMAND ----------
{consolidated imports — see import rules below}

# COMMAND ----------
# MAGIC %md
# MAGIC ## 2 — Parameters & Configuration

# COMMAND ----------
{consolidated widgets and variable declarations from all steps}

# COMMAND ----------
# MAGIC %md
# MAGIC ## 3 — Table Validation

# COMMAND ----------
{assert spark.catalog.tableExists() for every external source and final target}
{intermediate tables eliminated by merge: omit their assert, add comment}

# COMMAND ----------
# MAGIC %md
# MAGIC ## 4 — Step01: {original step name}
# MAGIC _{description inferred from stage types and table names}_

# COMMAND ----------
{Step01 cells verbatim — all transformations, all traceability blocks}
{Replace: df.write.saveAsTable('SRC_CHG_DATA') → df_src_chg_data = df  (in-memory)}

# COMMAND ----------
# MAGIC %md
# MAGIC ## 5 — Step02: {original step name}
# MAGIC _{description}_

# COMMAND ----------
{Step02 cells verbatim — all transformations, all traceability blocks}
{Replace: df.write.saveAsTable('TGT_3NF_DATA') → df_tgt_3nf_data = df  (in-memory)}

# COMMAND ----------
# MAGIC %md
# MAGIC ## 6 — Step03: Insert Stream Preparation (CDC Removed)
# MAGIC _{description of what TransIns does}_

# COMMAND ----------
{Step03 cells with CDC blocks removed — all kept transformations verbatim}
{Traceability blocks preserved}
{OUTPUT: INSERT_OUTPUT_VAR}

# COMMAND ----------   [only if Step04 is in insert chain]
# MAGIC %md
# MAGIC ## 7 — Step04: {original step name}

# COMMAND ----------
{Step04 cells verbatim if included}

# COMMAND ----------
# MAGIC %md
# MAGIC ## {N} — Step05: Insert into Target
# MAGIC _{description}_

# COMMAND ----------
{Step05 cells — source read replaced, everything else verbatim}
{Reject handling preserved}
```

### Intermediate table elimination

Where steps write to intermediate Delta tables that are only consumed within this pipeline:

```python
# OLD (write then read pattern — two cells):
df.write.mode('overwrite').saveAsTable('SRC_CHG_DATA')
# ... next cell ...
df_src = spark.read.format('delta').table('SRC_CHG_DATA')

# NEW (in-memory passthrough — one assignment):
df_src_chg_data = df
# Intermediate table SRC_CHG_DATA eliminated — direct DataFrame handoff
# REVIEW: SRC_CHG_DATA no longer written — verify no external consumers
```

**Exception:** Never eliminate writes to:
- The final target table (e.g. `PTY_CUST_ACCT`)
- Reject / error tables
- Any table explicitly flagged as consumed by another pipeline or team

### Import consolidation rules

Collect all imports from all steps. Apply these rules:
- One canonical import block at the top: `from pyspark.sql import functions as F`
- `from pyspark.sql.window import Window` — include only if `.over(` appears anywhere
- `from delta.tables import DeltaTable` — include only if `DeltaTable.forName` appears anywhere
- Remove: `from pyspark.sql.functions import *`, individual name imports (`col`, `lit`, `when`)
- Remove: `from pyspark import SparkContext`, `from pyspark.sql import SparkSession`
- Remove: `import os`, `import sys`, `import subprocess`
- Remove: `SparkSession.builder` blocks
- Remove: `if __name__ == '__main__':` blocks
- After removing individual name imports, prefix any bare calls: `col(` → `F.col(`, `lit(` → `F.lit(`

### Apply standardizer fixes inline during assembly

While assembling, apply fix groups from `fix-rules.md` (loaded in Phase 0).
Apply each group as cells are placed — do not defer to Phase 8 for issues visible now.

- **Group G**: DataStage syntax in Python context — using rules from fix-rules.md Group G
- **Group Q**: SQL context fixes — Q-HARD (never rewrite spark.sql body), Q-SOURCES, Q-VERIFY — using fix-rules.md Group Q
- **Group R**: source/target reads → `spark.read.format("delta").table(...)`, writes → `saveAsTable` — using fix-rules.md Group R
- **Group N**: naming standards — `source_table` / `target_table`, remove Teradata placeholders — using fix-rules.md Group N
- **Group I**: import canonicalization (covered in import consolidation rules above) — using fix-rules.md Group I
- **Group L**: broken `groupBy().select()` → `.agg()`, timestamp format tokens — using fix-rules.md Group L
- **Group S**: remove `SparkSession.builder`, `if __name__`, `dbutils.fs.mkdirs` — using fix-rules.md Group S
- **Group SEC**: clear hardcoded credentials — using fix-rules.md Group SEC

Phase 8 will perform a full scan of the completed notebook to catch anything missed here.

---

## Phase 6: Validation Checklist

Before outputting, verify every item. Fix failures before presenting.

```
PRESERVATION
[ ] Step01 logic 100% preserved — all source reads, lookups, transformations unchanged
[ ] Step02 logic 100% preserved — target table read, column mappings unchanged
[ ] All traceability blocks (# Processing node etc.) present on every stage cell
[ ] All stage variable names unchanged from originals (no renames)
[ ] Every .withColumn() / .select() chain from kept steps is intact and in original order

CDC REMOVAL
[ ] Step03 contains NO reference to: NetChange, full_outer join of src+tgt, df_updates,
    df_deletes, df_inserts_key, _cdc_flag, _change_type or equivalent CDC flag column
[ ] No write of update / delete / inserts_key intermediate tables
[ ] INSERT_OUTPUT_VAR (insert-ready DataFrame) is present and populated in merged notebook

WIRING
[ ] Step05 input is INSERT_OUTPUT_VAR (not a spark.read from a Delta table)
[ ] Step05 TransInsert transformation logic unchanged
[ ] Step05 writes to final target table — mode and table name unchanged
[ ] Reject handling in Step05 preserved — filter logic unchanged, only source DataFrame updated
[ ] Step04 included if in insert chain, excluded with REVIEW note if not

IMPORTS & STRUCTURE
[ ] Single canonical import block — no wildcard imports, no individual name imports
[ ] All bare function calls prefixed: col( → F.col(, lit( → F.lit(, when( → F.when(
[ ] No SparkSession.builder, no if __name__ == '__main__'
[ ] Widgets consolidated — no duplicate widget declarations
[ ] Table validation cell (assert spark.catalog.tableExists) for every external table
[ ] Intermediate eliminated tables NOT in assert cell — comment present instead
[ ] No broken DataFrame references across cells
[ ] No orphaned CDC intermediate tables written anywhere
```

---

## Phase 7: Output

### Internal CDC refactor summary

After Phase 6 validation passes, record the following internally (do NOT output yet —
the final output happens in Phase 8.5 after standardization):

```
CDC REFACTOR SUMMARY (internal — for Phase 8.5 output)
  Pipeline : {PIPELINE_NAME}
  Input    : {n} notebooks ({list actual filenames})
  Removed  : {list each removed block: variable name + what it was}
  Kept     : {list each kept transformation: variable name + stage type}
  Rewired  : {insert notebook filename} input → {INSERT_OUTPUT_VAR} (in-memory)
  Eliminated intermediate tables: {list}
```

**Output filename** (used in Phase 8.5):
`{PIPELINE_NAME}_insert_only_merged.py`
Where `PIPELINE_NAME` is the common domain/job identifier shared across the input notebooks
(e.g. `PTY_CUST_ACCT_wwptx03`, `ORD_HDR_wwvehx17`). If no common identifier:
`{source_unload_notebook_domain}_insert_only_merged.py`.

Do not output the merged notebook code block here. Pass the assembled notebook directly
to Phase 8 for standardization. Phase 8.5 outputs the final code block.

---

## Phase 8: Full Standardizer Pass (runs automatically after Phase 7)

**No pause. Runs immediately after the merged notebook is assembled.**

### 8.1 — Confirm reference files are loaded

All standardizer reference files were loaded in Phase 0.1:
- `fix-rules.md` — always loaded
- `stage-patterns.md` — loaded if stage pattern triggers were present
- `expression-map.md` — loaded if expression pattern triggers were present

If context was compacted since Phase 0, reload them now before proceeding.

### 8.2 — Scan and classify fixes

Scan every cell of the merged notebook from Phase 7.
For each issue: assign fix_id (FIX-001...), cell, group, severity, confidence.

Apply the same critical inspection guards as the standardizer:
- IF() inside F.expr() or spark.sql() → NOT Group G → skip
- <> inside spark.sql() body → NOT an issue → skip
- String literals 'Y', 'N', error codes → NEVER convert

### 8.3 — Apply all fixes

Apply ALL AUTO fixes immediately (no second approval required — user already typed `proceed`).
Apply REVIEW fixes with `# REVIEW: {assumption}` comments in the output.

### 8.4 — Validate output

Run the **complete Step 7 validation checklist from fix-rules.md** — every item must pass.
Fix any failures before outputting. Do not skip items.

If fix-rules.md is not in context (compacted), reload it from
`../../datastage-notebook-standardizer/references/fix-rules.md` before this step.

### 8.5 — Final output

```
LAKEBRIDGE CDC REFACTOR — COMPLETE
────────────────────────────────────────────────────────────────────
Pipeline  : {PIPELINE_NAME}
Input     : {n} notebooks  ({list actual input filenames})
Output    : {PIPELINE_NAME}_insert_only_merged.py
────────────────────────────────────────────────────────────────────
CDC REFACTOR
  Removed  : {list each removed block: variable name + what it was}
  Kept     : {list each kept transformation: variable name + stage type}
  Rewired  : {insert notebook filename} input → {INSERT_OUTPUT_VAR} (in-memory)
  Eliminated intermediate tables: {list}

STANDARDIZER PASS
  AUTO fixes applied : {n}
  REVIEW items       : {n} — search # REVIEW: in notebook
  Cells changed      : {list}
────────────────────────────────────────────────────────────────────
```

Then the final notebook in a ` ```python ` block.
Then REVIEW checklist if any REVIEW fixes were applied.

---

## Error Cases

### Phase 0 errors

| Situation | Action |
|-----------|--------|
| No CDC pattern found in any notebook | Output ANALYSIS REPORT with CDC CONFIRMATION showing NOT DETECTED. Add "WARNING: no CDC pattern detected — verify these are Lakebridge CDC notebooks." STOP — do not proceed without user confirmation. |
| User types `abort` | Stop entirely. Output "Refactor aborted. No changes made." |
| Script present but no matching notebook found by job ID or content | Report in SCRIPT ANALYSIS section: "No matching notebook found for {script_name} — confirm which notebook owns this script." Still output ANALYSIS REPORT. User must confirm before proceed. |
| Script mapping ambiguous — 2+ notebooks match equally | Mark all candidates as [LOW] confidence. Add REVIEW note in SCRIPT ANALYSIS. Do NOT inject widget defaultValues until engineer confirms. Still output report and wait for proceed. |
| Only a script provided, no notebooks | Output: "No notebooks detected in input. Paste the Lakebridge-generated .py notebook files to proceed." STOP. |
| Reference file not loadable at Phase 0.1 | Report which file failed to load. STOP — do not proceed with missing rules. |

### Phases 1–7 errors

| Situation | Action |
|-----------|--------|
| Step03 has no identifiable TransIns block | Keep all non-CDC transformations; add `# REVIEW: TransIns block not identified — verify insert logic is complete` |
| Step05 reads from a file path not a table | Rewrite to accept in-memory DataFrame; preserve all schema handling |
| Multiple insert streams in Step03 | Keep only `Inserts_No_Key` / non-key insert path; discard `Inserts_Key` with REVIEW note |
| Step04 feeds insert stream | Include between Step03 and Step05; verify surrogate key logic unchanged |
| Step04 does not feed insert stream | Exclude; add `# REVIEW: Step04 excluded — verify surrogate key handling` |
| Audit steps (Step06+) | Exclude; add to report: "Audit steps not included — run separately" |
| Step03 has transformations on SRC_CHG_DATA alone (not joined) | Keep — it is not CDC comparison logic |
| CDC flag column name is non-standard | Identify it from context; treat any column used to split Insert/Update/Delete streams as a CDC flag |
| Reject path references removed CDC DataFrame | Rewire to INSERT_OUTPUT_VAR; add REVIEW note |
| Phase 6 validation fails | Fix the failure before Phase 7. Do not proceed to Phase 8 with a failing validation item. |
