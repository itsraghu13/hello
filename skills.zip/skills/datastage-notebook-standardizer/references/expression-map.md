# Expression Map — DataStage BASIC → PySpark
# Read when notebook contains unrecognised DataStage function names,
# @ variables, or Oconv/Iconv date format strings.

---

## STRING FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Trim(col)` | `F.trim(F.col("col"))` | both sides |
| `LTrim(col)` | `F.ltrim(F.col("col"))` | leading only |
| `RTrim(col)` | `F.rtrim(F.col("col"))` | trailing only |
| `Strip(col,"leading")` | `F.ltrim(F.col("col"))` | |
| `Strip(col,"trailing")` | `F.rtrim(F.col("col"))` | |
| `Len(col)` | `F.length(F.col("col"))` | |
| `Length(col)` | `F.length(F.col("col"))` | alias of Len |
| `Space(n)` | `F.rpad(F.lit(""), n, " ")` | n spaces |
| `Str(col, n)` | `F.lpad(F.col("col"), n, " ")` | left-pad to width |
| `Upcase(col)` | `F.upper(F.col("col"))` | |
| `Downcase(col)` | `F.lower(F.col("col"))` | |
| `Left(col, n)` | `F.col("col").substr(1, n)` | |
| `Right(col, n)` | `F.expr(f"right(col, {n})")` | |
| `Mid(col, s, n)` | `F.col("col").substr(s, n)` | s is 1-based |
| `Field(col, delim, n)` | `F.split(F.col("col"), delim)[n-1]` | n is 1-based in DS |
| `Index(col, str, n)` | `F.locate(str, F.col("col"), n)` | n = occurrence |
| `Convert(col, from, to)` | `F.regexp_replace(F.col("col"), from, to)` | |
| `LJustify(col, n)` | `F.rpad(F.col("col"), n, " ")` | |
| `RJustify(col, n)` | `F.lpad(F.col("col"), n, " ")` | |
| `Squote(col)` | `F.concat(F.lit("'"), F.col("col"), F.lit("'"))` | |
| `Dquote(col)` | `F.concat(F.lit('"'), F.col("col"), F.lit('"'))` | |
| `col1 : col2` | `F.concat(F.col("col1"), F.col("col2"))` | DS concat op |
| `col1 \|\| col2` | `F.concat(F.col("col1"), F.col("col2"))` | |

---

## NUMERIC FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Abs(col)` | `F.abs(F.col("col"))` | |
| `Int(col)` | `F.floor(F.col("col"))` | truncate toward zero |
| `Round(col, n)` | `F.round(F.col("col"), n)` | |
| `Mod(a, b)` | `F.col("a") % F.col("b")` | |
| `Sqrt(col)` | `F.sqrt(F.col("col"))` | |
| `Num(col)` | `F.col("col").cast("double")` | string → number |
| `IntToString(col)` | `F.col("col").cast("string")` | |
| `StringToInteger(col)` | `F.col("col").cast("integer")` | |
| `StringToDecimal(col)` | `F.col("col").cast("double")` | |
| `DecimalToString(col)` | `F.col("col").cast("string")` | |

---

## DATE & TIMESTAMP FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Iconv(col, "D/MDY")` | `F.to_date(F.col("col"), "MM/dd/yyyy")` | parse string → date |
| `Iconv(col, "D/YMD")` | `F.to_date(F.col("col"), "yyyy-MM-dd")` | |
| `Oconv(col, "D/MDY[2,2,4]")` | `F.date_format(F.col("col"), "MM/dd/yyyy")` | format date → string |
| `Oconv(col, "D/YMD[4,2,2]")` | `F.date_format(F.col("col"), "yyyy-MM-dd")` | |
| `DateToString(col, fmt)` | `F.date_format(F.col("col"), fmt)` | |
| `StringToDate(col, fmt)` | `F.to_date(F.col("col"), fmt)` | |
| `StringToTimestamp(col, fmt)` | `F.to_timestamp(F.col("col"), fmt)` | |
| `TimeStampToDate(col)` | `F.to_date(F.col("col"))` | |
| `SecondsToTime(col)` | `F.from_unixtime(F.col("col"))` | |
| `Age(col)` | `F.datediff(F.current_date(), F.col("col"))` | days since date |
| `DaysSince(col)` | `F.datediff(F.current_date(), F.col("col"))` | alias |
| `Today()` | `F.current_date()` | |
| `Now()` | `F.current_timestamp()` | |
| `CurrentTimestamp()` | `F.current_timestamp()` | capital-C DS variant |

**DataStage date format token → Spark format token:**

| DataStage | Spark | Meaning |
|---|---|---|
| `%yyyy` | `yyyy` | 4-digit year |
| `%yy` | `yy` | 2-digit year |
| `%mm` | `MM` | month (01–12) |
| `%dd` | `dd` | day (01–31) |
| `%hh` | `HH` | hour 24h (00–23) |
| `%nn` | `mm` | minutes (00–59) |
| `%ss` | `ss` | seconds (00–59) |

---

## NULL & CONDITIONAL FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `IsNull(col)` | `F.col("col").isNull()` | |
| `IsNotNull(col)` | `F.col("col").isNotNull()` | |
| `NVL(col, val)` | `F.coalesce(F.col("col"), F.lit(val))` | |
| `NullToEmpty(col)` | `F.coalesce(F.col("col"), F.lit(""))` | |
| `NullToZero(col)` | `F.coalesce(F.col("col"), F.lit(0))` | |
| `IF(c, t, f)` | `F.when(c, t).otherwise(f)` | Python context |
| `IF(c, t, f)` | `CASE WHEN c THEN t ELSE f END` | SQL context |
| `Not(expr)` | `~(expr)` | logical NOT |
| `@NULL` | `F.lit(None)` | null literal |
| `@TRUE` | `F.lit(True)` | |
| `@FALSE` | `F.lit(False)` | |

---

## ROW & PARTITION VARIABLES

| DataStage Variable | PySpark | Notes |
|---|---|---|
| `@INROWNUM` | `F.row_number().over(Window.partitionBy(...).orderBy(F.lit(1)))` | row number within partition |
| `@NUMROWS` | `F.count("*").over(Window.partitionBy(...))` | total rows in partition |
| `@OUTROWNUM` | `F.row_number().over(Window.orderBy(F.lit(1)))` | global row number |

For all `@` row variables — always add:
```python
# REVIEW: Window partition/order columns inferred — verify correct keys
```

---

## OPERATORS

| DataStage | PySpark (Python context) | PySpark (SQL context) |
|---|---|---|
| `<>` | `!=` | keep as `<>` — valid ANSI SQL |
| `And` | `&` with parentheses | `AND` |
| `Or` | `\|` with parentheses | `OR` |
| `:` (concat) | `F.concat(...)` | `concat(...)` |
| `\|\|` (concat) | `F.concat(...)` | `concat(...)` or `\|\|` |

---

## DETECTION PATTERNS

Scan for these strings to know when to apply this map:

**Capitalised function names** (NameError at runtime):
`Trim(`, `LTrim(`, `RTrim(`, `Strip(`, `Upcase(`, `Downcase(`, `Left(`,
`Right(`, `Mid(`, `Field(`, `Index(`, `Convert(`, `LJustify(`, `RJustify(`,
`Space(`, `Str(`, `Len(`, `Length(`, `Abs(`, `Int(`, `Round(`, `Mod(`,
`Sqrt(`, `Num(`, `Iconv(`, `Oconv(`, `Age(`, `DaysSince(`, `Today(`,
`Now(`, `CurrentTimestamp(`, `IsNull(`, `IsNotNull(`, `NVL(`, `NullToEmpty(`,
`NullToZero(`, `Not(`

**@ variables** (SyntaxError or NameError):
`@INROWNUM`, `@NUMROWS`, `@OUTROWNUM`, `@NULL`, `@TRUE`, `@FALSE`

**Date format tokens** (wrong output):
`%yyyy`, `%mm`, `%dd`, `%hh`, `%nn`, `%ss`, `D/MDY`, `D/YMD`

**Concat operators in Python context** (SyntaxError):
`col1 : col2`, `col1 || col2` (when outside a spark.sql string)
