# Stage Patterns — DataStage Notebook Standardizer
# Read when notebook contains TRANSFORMER, AGGREGATOR, PIVOT, SCD,
# LOOKUP, JOIN, or SORT stage comments, or relevant PySpark patterns.

---

## TRANSFORMER STAGE

**Detection:** `# Processing node ... type TRANSFORMER` or `# type SOURCE`
comment with `.withColumn()` chains containing DataStage BASIC expressions.

**Common Lakebridge failures:**
- BASIC functions not mapped: `Space()`, `Field()`, `Str()`, `Index()`
- `@INROWNUM` left as placeholder or missing
- `@NULL` not converted to `F.lit(None)`
- Multi-output links with conditional routing only partially generated
- `If/Then/Else` chains converted to nested `when()` with wrong precedence
- DataStage date macros (`%yyyy`, `%mm`, `Oconv`, `Iconv`) not converted
- `Not(expr)` left as DataStage syntax instead of `~(expr)`

**Fix — string function patterns:**
```python
# Space(n) — pad with spaces
F.rpad(F.lit(""), n, " ")

# Field(col, delim, n) — split and get nth token (1-based in DS)
F.split(F.col("col"), delim)[n - 1]

# Str(col, n) — left-pad to width n
F.lpad(F.col("col"), n, " ")

# Index(col, str, n) — find nth occurrence (use locate for first)
F.locate("search_str", F.col("col"))

# Not(expr) — logical NOT
~(expr)

# @NULL
F.lit(None)
```

**Fix — @INROWNUM (row number within group):**
```python
from pyspark.sql.window import Window
# Inspect original stage for partition key — use lit(1) if no partition
_w = Window.partitionBy("partition_key_col").orderBy(F.lit(1))
df = df.withColumn("row_num", F.row_number().over(_w))
# REVIEW: partitionBy key inferred — verify correct partition column
```

**Fix — date macro conversion:**
```python
# Iconv(col, "D/MDY") → parse date string to date type
F.to_date(F.col("col"), "MM/dd/yyyy")

# Oconv(col, "D/MDY[2,2,4]") → format date to string
F.date_format(F.col("col"), "MM/dd/yyyy")

# DataStage %yyyy-%mm-%dd format tokens → Spark yyyy-MM-dd
# %yyyy → yyyy,  %mm → MM,  %dd → dd,  %hh → HH,  %nn → mm,  %ss → ss
```

**Fix — multi-output conditional routing:**
```python
# DataStage: one Transformer, two output links with different filter conditions
# Lakebridge often only generates one link — add the second
df_link1 = df.filter(F.col("flag") == "Y")
df_link2 = df.filter(F.col("flag") != "Y")
# REVIEW: filter condition inferred from stage comments — verify split logic
```

**Fix — nested IF precedence:**
```python
# BEFORE (wrong precedence from Lakebridge)
F.when(cond_a, val_a).when(cond_b, val_b).otherwise(
    F.when(cond_c, val_c).otherwise(val_d))

# AFTER (flat chain, correct precedence)
F.when(cond_a, val_a) \
 .when(cond_b, val_b) \
 .when(cond_c, val_c) \
 .otherwise(val_d)
```

---

## AGGREGATOR STAGE

**Detection:** `# type AGGREGATOR` or `.groupBy().` pattern.

**Common Lakebridge failures:**
- `F.first()` without `ignorenulls=True` — non-deterministic
- `F.last()` without `ignorenulls=True` — non-deterministic
- Running total (DataStage "Compute running totals") missing entirely
- GROUP BY key columns missing from `.agg()` select
- Single `F.sum()` inside `.groupBy()` call instead of `.agg()`
- Multiple agg functions collapsed into one wrong call

**Fix — standard aggregation:**
```python
df_agg = df.groupBy("key_col1", "key_col2").agg(
    F.sum("amount").alias("total_amount"),
    F.count("*").alias("record_count"),
    F.avg("price").alias("avg_price"),
    F.max("order_date").alias("latest_date"),
    F.min("order_date").alias("earliest_date"),
    F.first("description", ignorenulls=True).alias("first_desc"),
    F.last("description", ignorenulls=True).alias("last_desc"),
    F.countDistinct("customer_id").alias("unique_customers"),
)
```

**Fix — running total (DataStage "Compute running totals"):**
```python
from pyspark.sql.window import Window
_w_running = Window.partitionBy("group_col") \
    .orderBy("sort_col") \
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
df = df.withColumn("running_total", F.sum("amount").over(_w_running))
# REVIEW: partitionBy and orderBy inferred from stage — verify correct columns
```

**Fix — broken groupBy (sum inside groupBy args):**
```python
# BEFORE (Lakebridge error)
df.groupBy("dept", F.sum("salary"))
df.groupBy("dept").agg("SUM(salary)")

# AFTER
df.groupBy("dept").agg(F.sum("salary").alias("total_salary"))
```

---

## PIVOT STAGE

**Detection:** `# type PIVOT` or `PIVOT_COLUMNS_TO_ROWS` / `PIVOT_ROWS_TO_COLUMNS`
comment, or stub `# TODO: PIVOT`.

**Common Lakebridge failures:**
- Static pivot generated for dynamic DataStage pivot (column values at runtime)
- Unpivot (DataStage "Vertical pivot") missing or wrong
- Multiple value columns across pivot not handled
- PySpark version not detected — wrong unpivot syntax used

**Fix — rows to columns (standard pivot):**
```python
df_pivot = df.groupBy("key_col") \
    .pivot("category_col", ["CAT_A", "CAT_B", "CAT_C"]) \
    .agg(F.sum("value_col"))
# REVIEW: pivot values list inferred — specify known values for performance
# If values unknown at code time, omit the list (slower but dynamic):
# .pivot("category_col").agg(F.sum("value_col"))
```

**Fix — columns to rows (unpivot / vertical pivot):**
```python
# PySpark 3.4+ native
df_unpivot = df.unpivot(
    ids=["key_col"],
    values=["col_a", "col_b", "col_c"],
    variableColumnName="category",
    valueColumnName="value"
)

# PySpark < 3.4 (stack expression)
df_unpivot = df.selectExpr(
    "key_col",
    "stack(3, 'col_a', col_a, 'col_b', col_b, 'col_c', col_c) as (category, value)"
)
# REVIEW: column list for unpivot inferred from ErrRecIn/input schema — verify
```

---

## SCD (SLOWLY CHANGING DIMENSION) STAGE

**Detection:** `# type SCD` or `SCD_TYPE` comment, or Delta MERGE pattern
that is incomplete/missing for dimension tables.

**Common Lakebridge failures:**
- Type 1 (overwrite) generates inefficient loop-based UPDATE
- Type 2 (history) insert/expire logic missing or wrong
- Effective date defaults to `current_timestamp()` instead of business date
- `surrogate_key` generation missing
- `is_current` flag not set/reset correctly

**Fix — Type 1 SCD (overwrite current record):**
```python
from delta.tables import DeltaTable

dim = DeltaTable.forName(spark, TGT_dim)
dim.alias("t").merge(
    df_incoming.alias("s"),
    "t.natural_key = s.natural_key"  # REVIEW: natural key inferred — verify
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()
```

**Fix — Type 2 SCD (full history):**
```python
from delta.tables import DeltaTable

NATURAL_KEYS  = ["customer_id"]       # REVIEW: verify natural key columns
HIGH_DATE     = "9999-12-31"
join_cond     = " AND ".join([f"t.{k} = s.{k}" for k in NATURAL_KEYS])

dim = DeltaTable.forName(spark, TGT_dim)

# Step 1 — expire changed current rows
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenMatchedUpdate(
    condition="s.scd2_hash <> t.scd2_hash",
    set={
        "effective_end_date": F.current_date(),
        "is_current":         F.lit(False)
    }
).execute()

# Step 2 — insert new versions
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenNotMatchedInsert(values={
    "surrogate_key":      F.monotonically_increasing_id(),
    **{c: f"s.{c}" for c in df_incoming.columns},
    "effective_start_date": F.current_date(),
    "effective_end_date":   F.lit(HIGH_DATE),
    "is_current":           F.lit(True)
}).execute()
# REVIEW: scd2_hash must be pre-computed on SCD2 columns before merge
# REVIEW: column names (is_current, effective_start_date etc.) — verify schema
```

---

## LOOKUP STAGE

**Detection:** `# type LOOKUP` comment or `.join()` with broadcast pattern,
or unconnected lookup flat file reference.

**Common Lakebridge failures:**
- Sparse lookup (failure action = "continue with null") not handled — uses inner join, drops non-matching rows
- Unconnected lookup (flat file reference) generates broken file read
- Multiple lookup conditions partially mapped
- Broadcast hint missing on small reference tables
- Reject link (unmatched rows) not split out

**Fix — sparse lookup (left join):**
```python
# DataStage "Continue with null" → left join
df_result = df_main.join(
    F.broadcast(df_lookup),   # broadcast if lookup is small
    on=["join_key_col"],
    how="left"                # "inner" only for "Fail on no match"
)
# REVIEW: join type — use "inner" if DataStage was set to "Fail on no match"
```

**Fix — reject link (unmatched rows):**
```python
df_matched   = df_result.filter(F.col("lookup_col").isNotNull())
df_unmatched = df_result.filter(F.col("lookup_col").isNull())
# REVIEW: lookup_col is the first column from the lookup table — verify correct sentinel column
```

**Fix — unconnected lookup (flat file):**
```python
# Replace with Unity Catalog volume or already-ingested Delta table
df_lookup_ref = spark.read.format("delta").table(SRC_reference)
# REVIEW: original flat file path — verify Delta table exists at SRC_reference
```

**Fix — multi-condition lookup:**
```python
df_result = df_main.join(
    F.broadcast(df_lookup),
    (df_main["col_a"] == df_lookup["ref_col_a"]) &
    (df_main["col_b"] == df_lookup["ref_col_b"]),
    how="left"
)
```

---

## JOIN STAGE

**Detection:** `# type JOIN` comment or `.join()` calls with 3+ inputs,
or join key type mismatch, or duplicate columns after join.

**Common Lakebridge failures:**
- 3+ input joins converted as sequential joins losing correct join order
- DataStage "Full Outer" join missing — defaults to inner
- Join key type mismatch (string vs int) not cast before join
- Duplicate column names after join cause ambiguous reference errors
- Missing broadcast hint on small dimension tables

**Fix — multi-input join (3 sources):**
```python
# Join A + B first
df_ab = df_a.join(df_b, on="key_col", how="inner")
df_ab = df_ab.drop(df_b["key_col"])  # drop duplicate key

# Then join with C
df_final = df_ab.join(df_c, on="key_col", how="left")
# REVIEW: join order inferred from DataStage link order — verify correct sequence
```

**Fix — full outer join with coalesced key:**
```python
df_full = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="full")
df_full = df_full.withColumn(
    "key_col",
    F.coalesce(F.col("a.key_col"), F.col("b.key_col"))
)
```

**Fix — cast before join to prevent type mismatch:**
```python
df_a = df_a.withColumn("key_col", F.col("key_col").cast("string"))
df_b = df_b.withColumn("key_col", F.col("key_col").cast("string"))
df_joined = df_a.join(df_b, on="key_col", how="inner")
# REVIEW: cast to string assumed — verify correct target type for this key
```

**Fix — duplicate column dedup after join:**
```python
# After join, if both sides have same non-key column name
df_joined = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="inner")
# Reference with alias to avoid ambiguity
df_joined = df_joined.select(
    F.col("a.amount").alias("src_amount"),
    F.col("b.amount").alias("ref_amount"),
    "key_col"
)
```

---

## SORT STAGE

**Detection:** `# type SORT` comment or `.orderBy()` / `.sort()` calls.

**Common Lakebridge failures:**
- DataStage APT partition-aware sort emitted as global `orderBy()` — wrong semantics
- `NullFirst` / `NullLast` sort options not carried through — defaults to nulls last
- Sort immediately before Aggregator generates unnecessary extra shuffle
- Sort column direction (ASC/DESC) not preserved

**Fix — null-aware sort:**
```python
df_sorted = df.orderBy(
    F.col("sort_col1").asc_nulls_last(),
    F.col("sort_col2").desc_nulls_first()
)
# REVIEW: null handling (nulls_last / nulls_first) inferred — verify matches DS sort spec
```

**Fix — partition-aware sort (DataStage APT_SORT_PARTITIONED):**
```python
# DataStage sorted within each partition — use Window rather than global orderBy
from pyspark.sql.window import Window
_w = Window.partitionBy("partition_col").orderBy(F.col("sort_col").asc())
df = df.withColumn("row_rank", F.rank().over(_w))
# REVIEW: partition column inferred — verify correct partition key
```

**Fix — unnecessary sort before groupBy:**
```python
# BAD (Lakebridge often generates this — sorts then re-shuffles)
df.orderBy("key_col").groupBy("key_col").agg(F.sum("amount"))

# GOOD — groupBy already handles the shuffle, drop the orderBy
df.groupBy("key_col").agg(F.sum("amount").alias("total"))
```
