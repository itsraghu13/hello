# Fix Rules — Embedded Fallback
# Used when datastage-notebook-standardizer skill is not installed.
# Contains fix-rules.md + stage-patterns.md + expression-map.md combined.
# If standardizer skill IS installed, use its reference files instead.

---

# Fix Rules — DataStage Notebook Standardizer
# Read this file during STEP 2 INSPECT

---

## GROUP G — DataStage Syntax in Python Context

Applies inside: `F.expr("...")`, `.withColumn()`, `.filter()`, `.select()`,
any Python expression. These are DataStage BASIC functions that Lakebridge
failed to transpile.

Detection: any of these keywords inside a Python string passed to a PySpark
function: `IF(`, `Trim(`, `Upcase(`, `Downcase(`, `IsNull(`, `IsNotNull(`,
`NVL(`, `NullToEmpty(`, `Left(`, `Right(`, `Mid(`, `Length(`, `Index(`,
`Convert(`, `DateToString(`, `StringToDate(`, `Age(`, `DaysSince(`, `Int(`,
`Abs(`, `Round(`, `Mod(`, `LJustify(`, `RJustify(`, `Strip(`, `<>`, `||`

| DataStage | PySpark | Confidence |
|---|---|---|
| `IF(c, t, f)` | `F.when(c, t).otherwise(f)` | AUTO |
| `IF cond THEN t ELSE f` | `F.when(cond, t).otherwise(f)` | AUTO |
| `Trim(col)` | `F.trim(F.col("col"))` | AUTO |
| `Strip(col,"leading")` | `F.ltrim(F.col("col"))` | AUTO |
| `Strip(col,"trailing")` | `F.rtrim(F.col("col"))` | AUTO |
| `Upcase(col)` | `F.upper(F.col("col"))` | AUTO |
| `Downcase(col)` | `F.lower(F.col("col"))` | AUTO |
| `Left(col, n)` | `F.col("col").substr(1, n)` | AUTO |
| `Right(col, n)` | `F.expr(f"right(col, {n})")` | AUTO |
| `Mid(col, s, n)` | `F.col("col").substr(s, n)` | AUTO |
| `Length(col)` | `F.length(F.col("col"))` | AUTO |
| `IsNull(col)` | `F.col("col").isNull()` | AUTO |
| `IsNotNull(col)` | `F.col("col").isNotNull()` | AUTO |
| `NVL(col, val)` | `F.coalesce(F.col("col"), F.lit(val))` | AUTO |
| `NullToEmpty(col)` | `F.coalesce(F.col("col"), F.lit(""))` | AUTO |
| `Index(col, s, n)` | `F.locate(s, F.col("col"), n)` | AUTO |
| `Convert(c, from, to)` | `F.regexp_replace(F.col("c"), from, to)` | AUTO |
| `DateToString(c, fmt)` | `F.date_format(F.col("c"), fmt)` | AUTO |
| `StringToDate(c, fmt)` | `F.to_date(F.col("c"), fmt)` | AUTO |
| `StringToTimestamp(c, fmt)` | `F.to_timestamp(F.col("c"), fmt)` | AUTO |
| `Age(col)` / `DaysSince(col)` | `F.datediff(F.current_date(), F.col("col"))` | AUTO |
| `Int(col)` | `F.floor(F.col("col"))` | AUTO |
| `Abs(col)` | `F.abs(F.col("col"))` | AUTO |
| `Round(col, n)` | `F.round(F.col("col"), n)` | AUTO |
| `Mod(a, b)` | `F.col("a") % F.col("b")` | AUTO |
| `LJustify(col, n)` | `F.rpad(F.col("col"), n, " ")` | AUTO |
| `RJustify(col, n)` | `F.lpad(F.col("col"), n, " ")` | AUTO |
| `<>` in Python filter | `!=` | AUTO |
| `: ` or `\|\|` string concat | `F.concat(F.col("a"), F.col("b"))` | AUTO |
| Complex nested DS expr in `F.expr()` | Full transpile using table above | REVIEW |

---

## GROUP Q — DataStage Syntax in SQL Context

Applies ONLY inside `spark.sql("...")` string bodies.
Critical: different rules from Group G — same DataStage syntax, different fix.

| DataStage | Spark SQL fix | Confidence |
|---|---|---|
| `IF(c, t, f)` | `CASE WHEN c THEN t ELSE f END` | AUTO |
| `IF cond THEN t ELSE f` | `CASE WHEN c THEN t ELSE f END` | AUTO |
| `IsNull(col)` | `col IS NULL` | AUTO |
| `IsNotNull(col)` | `col IS NOT NULL` | AUTO |
| `NVL(col, val)` with capital N | `coalesce(col, val)` | AUTO |
| Hardcoded table name in FROM/JOIN | Replace with `{SRC_n}` f-string | AUTO |
| `<>` | **KEEP — valid ANSI SQL, never convert** | — |
| `trim()`, `upper()`, `lower()` etc. | **KEEP — valid Spark SQL** | — |

**When to keep spark.sql() vs convert to DataFrame API:**

| SQL Content | Action |
|---|---|
| Simple SELECT + WHERE + GROUP BY | Convert to DataFrame API + Delta read |
| JOINs (2 tables) | Convert to `df.join()` |
| UNION / UNION ALL | Convert to `df.union()` / `df.unionByName()` |
| CTEs (`WITH ... AS`) | Keep spark.sql(), fix refs + syntax only |
| Window functions (`OVER PARTITION BY`) | Keep spark.sql(), fix refs + syntax only |
| Subqueries | Keep spark.sql(), fix refs + syntax only |
| 4+ table JOINs | Keep spark.sql(), fix refs + syntax only |

---

## GROUP R — Source / Target Conversion

**Rule: every source read → Delta. No exceptions.**

Extract logical table name from original source:
- File path → filename stem (`/data/orders.csv` → `orders`)
- JDBC `dbtable` option → table name (`schema.orders` → `orders`)
- `spark.sql()` FROM clause → table name
- Oracle/DB2 connection properties → table name

Then: declare `SRC_n = f"{PREFIX}.{table_name}"` in parameters cell
and replace the read. Delta owns schema — no assertion needed.

| Original | Fixed |
|---|---|
| `spark.read.csv(path)` | `spark.read.format("delta").table(SRC_n)` |
| `spark.read.parquet(path)` | `spark.read.format("delta").table(SRC_n)` |
| `spark.read.json(path)` | `spark.read.format("delta").table(SRC_n)` |
| `spark.read.format("jdbc").load()` | `spark.read.format("delta").table(SRC_n)` |
| `spark.read.format("oracle")...` | `spark.read.format("delta").table(SRC_n)` |
| Any `spark.read` not `format("delta")` | `spark.read.format("delta").table(SRC_n)` |
| `df.write.csv/parquet/json(path)` | `df.write.format("delta").saveAsTable(TGT_n)` |

All confidence: AUTO.

After every converted read, add only the conversion traceability comment:
```python
# Converted from {original_type}: {original_path_or_table}
df_n = spark.read.format("delta").table(SRC_n)
```

---

## GROUP N — Naming Standards

**Standard widget naming (source_catalog / target_catalog style):**
See full parameter standard in SKILL.md. Summary of variable names:

| Widget name | Variable | Usage |
|---|---|---|
| `source_catalog` | `source_catalog` | shared across all sources |
| `source_schema` | `source_schema` | shared across all sources |
| `source_table` | `source_table` | single source only |
| `source1_table` | `source1_table` | multiple sources — numbered |
| `target_catalog` | `target_catalog` | shared across all targets |
| `target_schema` | `target_schema` | shared across all targets |
| `target_table` | `target_table` | single target only |
| `target1_table` | `target1_table` | multiple targets — numbered |
| `env` | `env` | environment |
| `load_type` | `load_type` | overwrite / append / merge |

**Table reference variables:**
```python
SRC  = f"{source_catalog}.{source_schema}.{source_table}"   # single source
SRC1 = f"{source_catalog}.{source_schema}.{source1_table}"  # multiple sources
SRC2 = f"{source_catalog}.{source_schema}.{source2_table}"
TGT  = f"{target_catalog}.{target_schema}.{target_table}"   # single target
TGT1 = f"{target_catalog}.{target_schema}.{target1_table}"  # multiple targets
```

| Issue | Fix | Confidence |
|---|---|---|
| Legacy Lakebridge widgets not used in notebook body | Remove widget + variable | AUTO |
| Old `CATALOG`/`SCHEMA`/`PREFIX` style | Replace with source_*/target_* style | AUTO |
| Old `SRC_n` / `TGT_n` uppercase style | Replace with `SRC`, `SRC1`, `TGT` etc. | AUTO |
| Hardcoded `"catalog.schema.table"` string | Replace with `f"{SRC}"` or `f"{TGT}"` | AUTO |
| Hardcoded env string in table path | Replace with `env` widget variable | AUTO |
| Table not in 3-part UC format | Reconstruct as full `f"{source_catalog}.{source_schema}.{source_table}"` | AUTO |
| `job_name` empty or missing | Set from traceability comment | AUTO |

**Legacy parameters — always remove if not referenced in notebook body:**
`TERA_SERVER_NAME`, `TERA_ENT_VIEW_DATABASE`, `TERA_STG_TABLE_DATABASE`,
`TERA_LGCY_VIEW_DATABASE`, `DATADIR`, `SUB`, `STAT`, `JOB`, `INST_NO`,
`STG_BTCH_NO`, any `EDW_*_USER_ID`, any `EDW_*_PASSWD`,
`PRCS_AUDT_NO`, `BTCH_NO`, `EXTRACT_CREAT_TS` (unless directly referenced)

---

## GROUP I — Imports & Passthrough DataFrames

### I000 — Import Style Canonicalization (AUTO — apply before all other fixes)

**Canonical form — one style only:**
```python
from pyspark.sql import functions as F
from pyspark.sql.window import Window        # only if Window used
from delta.tables import DeltaTable          # only if DeltaTable used
```

| Pattern detected | Fix |
|---|---|
| `import pyspark.sql.functions as F` | → `from pyspark.sql import functions as F` |
| `from pyspark.sql.functions import col, lit, ...` | → Remove; use `F.col()`, `F.lit()` |
| `from pyspark.sql.functions import *` | → Remove; replace with canonical |
| `from pyspark.sql import *` | → Remove; replace with canonical |
| Mixed: canonical F + individual name imports on same notebook | → Remove individual imports |
| `from pyspark import SparkContext` | → Remove |
| `from pyspark.sql import SparkSession` | → Remove |
| `import os`, `import oracledb`, `import logging` | → Remove if not used |
| Duplicate import line for same names | → Remove duplicate |

**After removing individual imports, prefix all bare names with `F.`:**

Scan for bare: `col(`, `lit(`, `when(`, `expr(`, `count(`, `sum(`, `max(`,
`min(`, `avg(`, `concat(`, `coalesce(`, `current_date(`, `current_timestamp(`,
`monotonically_increasing_id(`, `row_number(`, `rank(`, `dense_rank(`,
`lag(`, `lead(`, `trim(`, `upper(`, `lower(`, `length(`, `regexp_replace(`

→ Prefix each with `F.` where it is not already prefixed.

### I001 — Unused Imports (AUTO)

After canonicalization:
- `Window` imported but no `.over(` or `Window.` anywhere → remove
- `DeltaTable` imported but no `DeltaTable.forName` / `.forPath` → remove

### I002 — Passthrough DataFrames (AUTO)

`df_b = df_a` with zero transformation → collapse, update all downstream refs.
`df_b = df_a.select("*")` → same treatment.

Do NOT collapse `df_x = df_a.alias("x")` before a join — intentional.

```python
# BEFORE
df_source  = spark.read.format("delta").table(SRC)
df_orders  = df_source          # pure alias — collapse

# AFTER — df_orders removed, all downstream refs → df_source
df_source  = spark.read.format("delta").table(SRC)
```



---

## GROUP L — Logic Fixes

### L001 — Broken Aggregation (REVIEW)

```python
# BROKEN patterns Lakebridge emits
df.groupBy("dept").sum("salary")
df.groupBy("dept", F.sum("salary"))
df.groupBy("dept").agg("SUM(salary)")

# FIXED
df.groupBy("dept").agg(F.sum("salary").alias("total_salary"))
```

### L002 — MISSING_HANDLER Stub (REVIEW)

Inspect-then-implement protocol:
1. Read stage type from comment
2. Check input DataFrame columns
3. Check output link columns used by the next downstream cell
4. Check traceability block `# Processing node` metadata
5. Implement if derivation is traceable → else `# TODO: MANUAL`

| Stage type | PySpark pattern |
|---|---|
| `PxChangeCapture` | `DeltaTable.forName().merge()` CDC |
| `PxSurrogateKey` | `F.monotonically_increasing_id()` |
| `PxColumnExport` | `F.to_json(F.struct(*cols))` |
| `PxColumnImport` | `F.from_json(F.col("json_col"), schema)` |
| `PxHead` | `df.limit(n)` |
| `PxDifference` | `df_a.subtract(df_b)` |
| `PxIntersection` | `df_a.intersect(df_b)` |
| `PxSample` | `df.sample(fraction)` |

### L003 — PIVOT Stub (REVIEW)

```python
# ROWS_TO_COLUMNS (pivot)
df_out = df_in.groupBy(*keys).pivot("col", [v1,v2,v3]).agg(F.first("val"))

# COLUMNS_TO_ROWS (unpivot) — PySpark 3.4+
df_out = df_in.unpivot(
    ids=["id"], values=["a","b","c"],
    variableColumnName="attr", valueColumnName="val"
)

# COLUMNS_TO_ROWS — PySpark < 3.4 (stack expression)
df_out = df_in.select("id",
    F.expr("stack(3,'a',a,'b',b,'c',c) as (attr,val)"))
```

### L004 — Duplicate Variable Overwrite (REVIEW)

Same variable assigned in multiple cells → rename with descriptive suffix,
propagate rename to all downstream cells.

### L005 — Missing Reject Link (REVIEW)

When traceability comment shows `# Reject link(s): DSLink_reject` but no
reject split exists in the cell body:

```python
df_pass   = df_stage.filter(pass_condition)
df_reject = df_stage.filter(~pass_condition)
# TODO: REVIEW — confirm reject condition is exact complement of pass
```

---

## GROUP S — Structural Fixes

| Issue | Fix | Confidence |
|---|---|---|
| Missing `# Databricks notebook source` line 1 | Insert as absolute first line | AUTO |
| Missing `# COMMAND ----------` before a cell | Insert separator | AUTO |
| Two stages in one cell | Split into separate cells | REVIEW |
| Missing parameters cell | Insert with standard widget block | REVIEW |
| Stage cell missing traceability block | Insert from available metadata | REVIEW |
| Error handler cell present | Remove entirely | AUTO |

---

## NO MANUAL TIER — RESOLUTION RULES

Every issue must be fixed. When exact values cannot be determined, apply the
safest reasonable assumption and add `# REVIEW: <assumption>` inline.

### DataStage join key artifacts (AUTO)

Join arrays sometimes contain DataStage link-type metadata tokens — not real
column names. Strip any token that contains a backslash or is exactly
`"cs"`, `"ps"`, `"rs"`.

```python
# BEFORE
df.join(df2, ["SS_DLR_ACCT_NO","ci\cs","cs","SS_DLR_LOC_CD","ci\cs","cs"], "fullouter")

# AFTER
df.join(df2, ["SS_DLR_ACCT_NO","SS_DLR_LOC_CD","SS_SPA_NO"], "fullouter")
# REVIEW: join keys inferred by stripping DataStage artifacts — verify correct keys
```

### Empty sha2 column list — CDC hash (REVIEW)

`sha2(concat_ws("||", *[]), 256)` with empty list means Lakebridge dropped the
column list. Fix: hash all non-key columns (standard CDC approach).

```python
# BEFORE
sha2(concat_ws("||", *[]), 256)

# AFTER
_key_cols  = ["SS_DLR_ACCT_NO", "SS_DLR_LOC_CD", "SS_SPA_NO"]  # from join keys
_hash_cols = [c for c in df.columns if c not in _key_cols]
sha2(concat_ws("||", *[F.col(c).cast("string") for c in _hash_cols]), 256)
# REVIEW: hashing all non-key columns — verify this matches original DS job hash spec
```

### Hardcoded credentials in widget defaults (AUTO)

Any widget `defaultValue` that looks like a password → replace with `""`.
Detection: widget name contains `PASSWD`, `PASSWORD`, `PWD`, `SECRET`, `TOKEN`,
or value contains `@` with mixed case+digits+symbols and length > 8.

```python
# BEFORE
dbutils.widgets.text(name='EDW_SPA_USER_WW_TERA_PASSWD', defaultValue='HDI@IJV8O9JN064IL:JD1K95')
# AFTER
dbutils.widgets.text(name='EDW_SPA_USER_WW_TERA_PASSWD', defaultValue='')
# REVIEW: credential removed — inject via Databricks secret scope: dbutils.secrets.get(scope, key)
```

### CurrentTimestamp() undefined function (AUTO)

`CurrentTimestamp()` with capital C → `F.current_timestamp()`.

### DataStage timestamp format tokens (AUTO)

| DataStage | Spark |
|---|---|
| `%hh` | `HH` |
| `%nn` | `mm` |
| `%ss` | `ss` |
| `YYYY` | `yyyy` |

### Repeated validation withColumn block (REVIEW)

When identical `withColumn` validation expressions repeat across multiple cells
on the same DataFrame → compute once, `.cache()`, reference downstream.
Always add `.unpersist()` after the last cell that references the cached DataFrame.

```python
# Cache once
lnkChanges_validated = lnkChanges \
    .withColumn("SPANOERR1", ...) \
    .withColumn("REJECTRECORD", ...) \
    .cache()
# REVIEW: cache() — verify cluster memory sufficient

# ... intervening cells use lnkChanges_validated ...

# LAST cell referencing lnkChanges_validated
Updates = lnkChanges_validated.filter(...).select(...)
lnkChanges_validated.unpersist()  # memory released
```

**Rules:**
- ONE unpersist per cached DataFrame — always after the last reference
- Never unpersist before last use — scan all cells first
- If cached df feeds a target write, unpersist after the write + print

---

## NEVER TOUCH

- Business logic with no detected anti-pattern
- `.alias("name")` before a join — intentional column disambiguation
- `<>` inside `spark.sql()` bodies — valid ANSI SQL
- CTEs, window functions, 4+ table JOINs in `spark.sql()` — keep as-is, fix refs only
- `toPandas()` / `collect()` — add `# REVIEW: may OOM on large data` comment only

---

## GROUP G — ADDITIONAL PATTERNS (from real notebook testing)

### Capital-letter DataStage function names (AUTO)

These appear as unqualified Python calls — they fail with NameError at runtime.

| DataStage call | PySpark fix |
|---|---|
| `LENGTH(col)` | `F.length(col)` |
| `SUBSTRING(col, start, len)` | `F.substring(col, start, len)` |
| `TRIM(col)` | `F.trim(col)` |
| `COALESCE(a, b)` unqualified | `F.coalesce(a, b)` |
| `CurrentTimestamp()` | `F.current_timestamp()` |

Detection: any unqualified function call with ALL-CAPS or TitleCase name
that matches a known DataStage function — not prefixed with `F.` or `spark.`.

### || string concatenation in Python context (AUTO)

```python
# BEFORE
('ppr_' || lit(STAT) || '_s6_lst_run_ts').alias('CUR_KEY_DATA')

# AFTER
F.concat(F.lit('ppr_'), F.lit(STAT), F.lit('_s6_lst_run_ts')).alias('CUR_KEY_DATA')
```

### ${VAR} Teradata variable interpolation in spark.sql() (AUTO)

Teradata uses `${VAR}` and `#$DB#.TABLE` syntax — neither is valid Python f-string.

| Pattern | Fix |
|---|---|
| `#$TERA_DB#.TABLE_NAME` | `{SRC_table_name}` via declared variable |
| `>${STG_BTCH_NO}` inside SQL string | `>{STG_BTCH_NO}` (remove the `$`) |
| `>'${EXTRACT_CREAT_TS}'` | `>'{EXTRACT_CREAT_TS}'` (remove the `$`) |

### lit() wrapping a column name as Python variable (REVIEW)

`lit(COLUMN_NAME)` where `COLUMN_NAME` is a column name string, not a Python
variable — wraps as string literal instead of referencing the column.

```python
# BEFORE — broken: LANGCDERR1 treated as Python var, not column
LENGTH(coalesce(lit(LANGCDERR1) + lit(SCRNCOLNMEERR1) + lit(VALUEDTLCDERR1), ''))

# AFTER
F.length(F.coalesce(
    F.concat(F.col("LANGCDERR1"), F.col("SCRNCOLNMEERR1"), F.col("VALUEDTLCDERR1")),
    F.lit("")
))
# REVIEW: verify concat is the correct combination logic for this error count
```

### Self-referential lag/window SEQNO pattern (REVIEW)

DataStage running sequence counters using lag() referencing the column being
computed — not valid in PySpark. Replace with `F.sum().over(Window)`.

```python
# BEFORE
expr(f"""IF(ERR_CD <> '', lag(IF(ERR_CD<>'', SEQNO+1, SEQNO)) over(ORDER BY DF_ROW_ID)+1, ...)""")

# AFTER
from pyspark.sql.window import Window
_w = Window.orderBy("DF_ROW_ID")
df = df.withColumn("ERR_FLAG", (F.col("ERR_CD") != "").cast("int")) \
       .withColumn("SEQNO", F.sum("ERR_FLAG").over(_w))
# REVIEW: SEQNO = running count of non-empty ERR_CD rows — verify matches original intent
```
# Stage Patterns — DataStage Notebook Standardizer
# Read when notebook contains TRANSFORMER, AGGREGATOR, PIVOT, SCD,
# LOOKUP, JOIN, or SORT stage comments, or relevant PySpark patterns.

---

## TRANSFORMER STAGE

**Detection:** `# Processing node ... type TRANSFORMER` or `# type SOURCE`
comment with `.withColumn()` chains containing DataStage BASIC expressions.

**Common Lakebridge failures:**
- BASIC functions not mapped: `Space()`, `Field()`, `Str()`, `Index()`
- `@INROWNUM` left as placeholder or missing
- `@NULL` not converted to `F.lit(None)`
- Multi-output links with conditional routing only partially generated
- `If/Then/Else` chains converted to nested `when()` with wrong precedence
- DataStage date macros (`%yyyy`, `%mm`, `Oconv`, `Iconv`) not converted
- `Not(expr)` left as DataStage syntax instead of `~(expr)`

**Fix — string function patterns:**
```python
# Space(n) — pad with spaces
F.rpad(F.lit(""), n, " ")

# Field(col, delim, n) — split and get nth token (1-based in DS)
F.split(F.col("col"), delim)[n - 1]

# Str(col, n) — left-pad to width n
F.lpad(F.col("col"), n, " ")

# Index(col, str, n) — find nth occurrence (use locate for first)
F.locate("search_str", F.col("col"))

# Not(expr) — logical NOT
~(expr)

# @NULL
F.lit(None)
```

**Fix — @INROWNUM (row number within group):**
```python
from pyspark.sql.window import Window
# Inspect original stage for partition key — use lit(1) if no partition
_w = Window.partitionBy("partition_key_col").orderBy(F.lit(1))
df = df.withColumn("row_num", F.row_number().over(_w))
# REVIEW: partitionBy key inferred — verify correct partition column
```

**Fix — date macro conversion:**
```python
# Iconv(col, "D/MDY") → parse date string to date type
F.to_date(F.col("col"), "MM/dd/yyyy")

# Oconv(col, "D/MDY[2,2,4]") → format date to string
F.date_format(F.col("col"), "MM/dd/yyyy")

# DataStage %yyyy-%mm-%dd format tokens → Spark yyyy-MM-dd
# %yyyy → yyyy,  %mm → MM,  %dd → dd,  %hh → HH,  %nn → mm,  %ss → ss
```

**Fix — multi-output conditional routing:**
```python
# DataStage: one Transformer, two output links with different filter conditions
# Lakebridge often only generates one link — add the second
df_link1 = df.filter(F.col("flag") == "Y")
df_link2 = df.filter(F.col("flag") != "Y")
# REVIEW: filter condition inferred from stage comments — verify split logic
```

**Fix — nested IF precedence:**
```python
# BEFORE (wrong precedence from Lakebridge)
F.when(cond_a, val_a).when(cond_b, val_b).otherwise(
    F.when(cond_c, val_c).otherwise(val_d))

# AFTER (flat chain, correct precedence)
F.when(cond_a, val_a) \
 .when(cond_b, val_b) \
 .when(cond_c, val_c) \
 .otherwise(val_d)
```

---

## AGGREGATOR STAGE

**Detection:** `# type AGGREGATOR` or `.groupBy().` pattern.

**Common Lakebridge failures:**
- `F.first()` without `ignorenulls=True` — non-deterministic
- `F.last()` without `ignorenulls=True` — non-deterministic
- Running total (DataStage "Compute running totals") missing entirely
- GROUP BY key columns missing from `.agg()` select
- Single `F.sum()` inside `.groupBy()` call instead of `.agg()`
- Multiple agg functions collapsed into one wrong call

**Fix — standard aggregation:**
```python
df_agg = df.groupBy("key_col1", "key_col2").agg(
    F.sum("amount").alias("total_amount"),
    F.count("*").alias("record_count"),
    F.avg("price").alias("avg_price"),
    F.max("order_date").alias("latest_date"),
    F.min("order_date").alias("earliest_date"),
    F.first("description", ignorenulls=True).alias("first_desc"),
    F.last("description", ignorenulls=True).alias("last_desc"),
    F.countDistinct("customer_id").alias("unique_customers"),
)
```

**Fix — running total (DataStage "Compute running totals"):**
```python
from pyspark.sql.window import Window
_w_running = Window.partitionBy("group_col") \
    .orderBy("sort_col") \
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
df = df.withColumn("running_total", F.sum("amount").over(_w_running))
# REVIEW: partitionBy and orderBy inferred from stage — verify correct columns
```

**Fix — broken groupBy (sum inside groupBy args):**
```python
# BEFORE (Lakebridge error)
df.groupBy("dept", F.sum("salary"))
df.groupBy("dept").agg("SUM(salary)")

# AFTER
df.groupBy("dept").agg(F.sum("salary").alias("total_salary"))
```

---

## PIVOT STAGE

**Detection:** `# type PIVOT` or `PIVOT_COLUMNS_TO_ROWS` / `PIVOT_ROWS_TO_COLUMNS`
comment, or stub `# TODO: PIVOT`.

**Common Lakebridge failures:**
- Static pivot generated for dynamic DataStage pivot (column values at runtime)
- Unpivot (DataStage "Vertical pivot") missing or wrong
- Multiple value columns across pivot not handled
- PySpark version not detected — wrong unpivot syntax used

**Fix — rows to columns (standard pivot):**
```python
df_pivot = df.groupBy("key_col") \
    .pivot("category_col", ["CAT_A", "CAT_B", "CAT_C"]) \
    .agg(F.sum("value_col"))
# REVIEW: pivot values list inferred — specify known values for performance
# If values unknown at code time, omit the list (slower but dynamic):
# .pivot("category_col").agg(F.sum("value_col"))
```

**Fix — columns to rows (unpivot / vertical pivot):**
```python
# PySpark 3.4+ native
df_unpivot = df.unpivot(
    ids=["key_col"],
    values=["col_a", "col_b", "col_c"],
    variableColumnName="category",
    valueColumnName="value"
)

# PySpark < 3.4 (stack expression)
df_unpivot = df.selectExpr(
    "key_col",
    "stack(3, 'col_a', col_a, 'col_b', col_b, 'col_c', col_c) as (category, value)"
)
# REVIEW: column list for unpivot inferred from ErrRecIn/input schema — verify
```

---

## SCD (SLOWLY CHANGING DIMENSION) STAGE

**Detection:** `# type SCD` or `SCD_TYPE` comment, or Delta MERGE pattern
that is incomplete/missing for dimension tables.

**Common Lakebridge failures:**
- Type 1 (overwrite) generates inefficient loop-based UPDATE
- Type 2 (history) insert/expire logic missing or wrong
- Effective date defaults to `current_timestamp()` instead of business date
- `surrogate_key` generation missing
- `is_current` flag not set/reset correctly

**Fix — Type 1 SCD (overwrite current record):**
```python
from delta.tables import DeltaTable

dim = DeltaTable.forName(spark, TGT_dim)
dim.alias("t").merge(
    df_incoming.alias("s"),
    "t.natural_key = s.natural_key"  # REVIEW: natural key inferred — verify
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()
```

**Fix — Type 2 SCD (full history):**
```python
from delta.tables import DeltaTable

NATURAL_KEYS  = ["customer_id"]       # REVIEW: verify natural key columns
HIGH_DATE     = "9999-12-31"
join_cond     = " AND ".join([f"t.{k} = s.{k}" for k in NATURAL_KEYS])

dim = DeltaTable.forName(spark, TGT_dim)

# Step 1 — expire changed current rows
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenMatchedUpdate(
    condition="s.scd2_hash <> t.scd2_hash",
    set={
        "effective_end_date": F.current_date(),
        "is_current":         F.lit(False)
    }
).execute()

# Step 2 — insert new versions
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenNotMatchedInsert(values={
    "surrogate_key":      F.monotonically_increasing_id(),
    **{c: f"s.{c}" for c in df_incoming.columns},
    "effective_start_date": F.current_date(),
    "effective_end_date":   F.lit(HIGH_DATE),
    "is_current":           F.lit(True)
}).execute()
# REVIEW: scd2_hash must be pre-computed on SCD2 columns before merge
# REVIEW: column names (is_current, effective_start_date etc.) — verify schema
```

---

## LOOKUP STAGE

**Detection:** `# type LOOKUP` comment or `.join()` with broadcast pattern,
or unconnected lookup flat file reference.

**Common Lakebridge failures:**
- Sparse lookup (failure action = "continue with null") not handled — uses inner join, drops non-matching rows
- Unconnected lookup (flat file reference) generates broken file read
- Multiple lookup conditions partially mapped
- Broadcast hint missing on small reference tables
- Reject link (unmatched rows) not split out

**Fix — sparse lookup (left join):**
```python
# DataStage "Continue with null" → left join
df_result = df_main.join(
    F.broadcast(df_lookup),   # broadcast if lookup is small
    on=["join_key_col"],
    how="left"                # "inner" only for "Fail on no match"
)
# REVIEW: join type — use "inner" if DataStage was set to "Fail on no match"
```

**Fix — reject link (unmatched rows):**
```python
df_matched   = df_result.filter(F.col("lookup_col").isNotNull())
df_unmatched = df_result.filter(F.col("lookup_col").isNull())
# REVIEW: lookup_col is the first column from the lookup table — verify correct sentinel column
```

**Fix — unconnected lookup (flat file):**
```python
# Replace with Unity Catalog volume or already-ingested Delta table
df_lookup_ref = spark.read.format("delta").table(SRC_reference)
# REVIEW: original flat file path — verify Delta table exists at SRC_reference
```

**Fix — multi-condition lookup:**
```python
df_result = df_main.join(
    F.broadcast(df_lookup),
    (df_main["col_a"] == df_lookup["ref_col_a"]) &
    (df_main["col_b"] == df_lookup["ref_col_b"]),
    how="left"
)
```

---

## JOIN STAGE

**Detection:** `# type JOIN` comment or `.join()` calls with 3+ inputs,
or join key type mismatch, or duplicate columns after join.

**Common Lakebridge failures:**
- 3+ input joins converted as sequential joins losing correct join order
- DataStage "Full Outer" join missing — defaults to inner
- Join key type mismatch (string vs int) not cast before join
- Duplicate column names after join cause ambiguous reference errors
- Missing broadcast hint on small dimension tables

**Fix — multi-input join (3 sources):**
```python
# Join A + B first
df_ab = df_a.join(df_b, on="key_col", how="inner")
df_ab = df_ab.drop(df_b["key_col"])  # drop duplicate key

# Then join with C
df_final = df_ab.join(df_c, on="key_col", how="left")
# REVIEW: join order inferred from DataStage link order — verify correct sequence
```

**Fix — full outer join with coalesced key:**
```python
df_full = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="full")
df_full = df_full.withColumn(
    "key_col",
    F.coalesce(F.col("a.key_col"), F.col("b.key_col"))
)
```

**Fix — cast before join to prevent type mismatch:**
```python
df_a = df_a.withColumn("key_col", F.col("key_col").cast("string"))
df_b = df_b.withColumn("key_col", F.col("key_col").cast("string"))
df_joined = df_a.join(df_b, on="key_col", how="inner")
# REVIEW: cast to string assumed — verify correct target type for this key
```

**Fix — duplicate column dedup after join:**
```python
# After join, if both sides have same non-key column name
df_joined = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="inner")
# Reference with alias to avoid ambiguity
df_joined = df_joined.select(
    F.col("a.amount").alias("src_amount"),
    F.col("b.amount").alias("ref_amount"),
    "key_col"
)
```

---

## SORT STAGE

**Detection:** `# type SORT` comment or `.orderBy()` / `.sort()` calls.

**Common Lakebridge failures:**
- DataStage APT partition-aware sort emitted as global `orderBy()` — wrong semantics
- `NullFirst` / `NullLast` sort options not carried through — defaults to nulls last
- Sort immediately before Aggregator generates unnecessary extra shuffle
- Sort column direction (ASC/DESC) not preserved

**Fix — null-aware sort:**
```python
df_sorted = df.orderBy(
    F.col("sort_col1").asc_nulls_last(),
    F.col("sort_col2").desc_nulls_first()
)
# REVIEW: null handling (nulls_last / nulls_first) inferred — verify matches DS sort spec
```

**Fix — partition-aware sort (DataStage APT_SORT_PARTITIONED):**
```python
# DataStage sorted within each partition — use Window rather than global orderBy
from pyspark.sql.window import Window
_w = Window.partitionBy("partition_col").orderBy(F.col("sort_col").asc())
df = df.withColumn("row_rank", F.rank().over(_w))
# REVIEW: partition column inferred — verify correct partition key
```

**Fix — unnecessary sort before groupBy:**
```python
# BAD (Lakebridge often generates this — sorts then re-shuffles)
df.orderBy("key_col").groupBy("key_col").agg(F.sum("amount"))

# GOOD — groupBy already handles the shuffle, drop the orderBy
df.groupBy("key_col").agg(F.sum("amount").alias("total"))
```
# Expression Map — DataStage BASIC → PySpark
# Read when notebook contains unrecognised DataStage function names,
# @ variables, or Oconv/Iconv date format strings.

---

## STRING FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Trim(col)` | `F.trim(F.col("col"))` | both sides |
| `LTrim(col)` | `F.ltrim(F.col("col"))` | leading only |
| `RTrim(col)` | `F.rtrim(F.col("col"))` | trailing only |
| `Strip(col,"leading")` | `F.ltrim(F.col("col"))` | |
| `Strip(col,"trailing")` | `F.rtrim(F.col("col"))` | |
| `Len(col)` | `F.length(F.col("col"))` | |
| `Length(col)` | `F.length(F.col("col"))` | alias of Len |
| `Space(n)` | `F.rpad(F.lit(""), n, " ")` | n spaces |
| `Str(col, n)` | `F.lpad(F.col("col"), n, " ")` | left-pad to width |
| `Upcase(col)` | `F.upper(F.col("col"))` | |
| `Downcase(col)` | `F.lower(F.col("col"))` | |
| `Left(col, n)` | `F.col("col").substr(1, n)` | |
| `Right(col, n)` | `F.expr(f"right(col, {n})")` | |
| `Mid(col, s, n)` | `F.col("col").substr(s, n)` | s is 1-based |
| `Field(col, delim, n)` | `F.split(F.col("col"), delim)[n-1]` | n is 1-based in DS |
| `Index(col, str, n)` | `F.locate(str, F.col("col"), n)` | n = occurrence |
| `Convert(col, from, to)` | `F.regexp_replace(F.col("col"), from, to)` | |
| `LJustify(col, n)` | `F.rpad(F.col("col"), n, " ")` | |
| `RJustify(col, n)` | `F.lpad(F.col("col"), n, " ")` | |
| `Squote(col)` | `F.concat(F.lit("'"), F.col("col"), F.lit("'"))` | |
| `Dquote(col)` | `F.concat(F.lit('"'), F.col("col"), F.lit('"'))` | |
| `col1 : col2` | `F.concat(F.col("col1"), F.col("col2"))` | DS concat op |
| `col1 \|\| col2` | `F.concat(F.col("col1"), F.col("col2"))` | |

---

## NUMERIC FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Abs(col)` | `F.abs(F.col("col"))` | |
| `Int(col)` | `F.floor(F.col("col"))` | truncate toward zero |
| `Round(col, n)` | `F.round(F.col("col"), n)` | |
| `Mod(a, b)` | `F.col("a") % F.col("b")` | |
| `Sqrt(col)` | `F.sqrt(F.col("col"))` | |
| `Num(col)` | `F.col("col").cast("double")` | string → number |
| `IntToString(col)` | `F.col("col").cast("string")` | |
| `StringToInteger(col)` | `F.col("col").cast("integer")` | |
| `StringToDecimal(col)` | `F.col("col").cast("double")` | |
| `DecimalToString(col)` | `F.col("col").cast("string")` | |

---

## DATE & TIMESTAMP FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Iconv(col, "D/MDY")` | `F.to_date(F.col("col"), "MM/dd/yyyy")` | parse string → date |
| `Iconv(col, "D/YMD")` | `F.to_date(F.col("col"), "yyyy-MM-dd")` | |
| `Oconv(col, "D/MDY[2,2,4]")` | `F.date_format(F.col("col"), "MM/dd/yyyy")` | format date → string |
| `Oconv(col, "D/YMD[4,2,2]")` | `F.date_format(F.col("col"), "yyyy-MM-dd")` | |
| `DateToString(col, fmt)` | `F.date_format(F.col("col"), fmt)` | |
| `StringToDate(col, fmt)` | `F.to_date(F.col("col"), fmt)` | |
| `StringToTimestamp(col, fmt)` | `F.to_timestamp(F.col("col"), fmt)` | |
| `TimeStampToDate(col)` | `F.to_date(F.col("col"))` | |
| `SecondsToTime(col)` | `F.from_unixtime(F.col("col"))` | |
| `Age(col)` | `F.datediff(F.current_date(), F.col("col"))` | days since date |
| `DaysSince(col)` | `F.datediff(F.current_date(), F.col("col"))` | alias |
| `Today()` | `F.current_date()` | |
| `Now()` | `F.current_timestamp()` | |
| `CurrentTimestamp()` | `F.current_timestamp()` | capital-C DS variant |

**DataStage date format token → Spark format token:**

| DataStage | Spark | Meaning |
|---|---|---|
| `%yyyy` | `yyyy` | 4-digit year |
| `%yy` | `yy` | 2-digit year |
| `%mm` | `MM` | month (01–12) |
| `%dd` | `dd` | day (01–31) |
| `%hh` | `HH` | hour 24h (00–23) |
| `%nn` | `mm` | minutes (00–59) |
| `%ss` | `ss` | seconds (00–59) |

---

## NULL & CONDITIONAL FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `IsNull(col)` | `F.col("col").isNull()` | |
| `IsNotNull(col)` | `F.col("col").isNotNull()` | |
| `NVL(col, val)` | `F.coalesce(F.col("col"), F.lit(val))` | |
| `NullToEmpty(col)` | `F.coalesce(F.col("col"), F.lit(""))` | |
| `NullToZero(col)` | `F.coalesce(F.col("col"), F.lit(0))` | |
| `IF(c, t, f)` | `F.when(c, t).otherwise(f)` | Python context |
| `IF(c, t, f)` | `CASE WHEN c THEN t ELSE f END` | SQL context |
| `Not(expr)` | `~(expr)` | logical NOT |
| `@NULL` | `F.lit(None)` | null literal |
| `@TRUE` | `F.lit(True)` | |
| `@FALSE` | `F.lit(False)` | |

---

## ROW & PARTITION VARIABLES

| DataStage Variable | PySpark | Notes |
|---|---|---|
| `@INROWNUM` | `F.row_number().over(Window.partitionBy(...).orderBy(F.lit(1)))` | row number within partition |
| `@NUMROWS` | `F.count("*").over(Window.partitionBy(...))` | total rows in partition |
| `@OUTROWNUM` | `F.row_number().over(Window.orderBy(F.lit(1)))` | global row number |

For all `@` row variables — always add:
```python
# REVIEW: Window partition/order columns inferred — verify correct keys
```

---

## OPERATORS

| DataStage | PySpark (Python context) | PySpark (SQL context) |
|---|---|---|
| `<>` | `!=` | keep as `<>` — valid ANSI SQL |
| `And` | `&` with parentheses | `AND` |
| `Or` | `\|` with parentheses | `OR` |
| `:` (concat) | `F.concat(...)` | `concat(...)` |
| `\|\|` (concat) | `F.concat(...)` | `concat(...)` or `\|\|` |

---

## DETECTION PATTERNS

Scan for these strings to know when to apply this map:

**Capitalised function names** (NameError at runtime):
`Trim(`, `LTrim(`, `RTrim(`, `Strip(`, `Upcase(`, `Downcase(`, `Left(`,
`Right(`, `Mid(`, `Field(`, `Index(`, `Convert(`, `LJustify(`, `RJustify(`,
`Space(`, `Str(`, `Len(`, `Length(`, `Abs(`, `Int(`, `Round(`, `Mod(`,
`Sqrt(`, `Num(`, `Iconv(`, `Oconv(`, `Age(`, `DaysSince(`, `Today(`,
`Now(`, `CurrentTimestamp(`, `IsNull(`, `IsNotNull(`, `NVL(`, `NullToEmpty(`,
`NullToZero(`, `Not(`

**@ variables** (SyntaxError or NameError):
`@INROWNUM`, `@NUMROWS`, `@OUTROWNUM`, `@NULL`, `@TRUE`, `@FALSE`

**Date format tokens** (wrong output):
`%yyyy`, `%mm`, `%dd`, `%hh`, `%nn`, `%ss`, `D/MDY`, `D/YMD`

**Concat operators in Python context** (SyntaxError):
`col1 : col2`, `col1 || col2` (when outside a spark.sql string)
# Script Analysis Rules — Shell Script → Notebook Context
# Read when input contains a .ksh / .sh / .bash file

---

## STEP 0 — DETECT SCRIPT IN INPUT

A script is present if input contains any of:
- File with `.ksh`, `.sh`, `.bash` extension
- File starting with `#!/bin/ksh`, `#!/bin/bash`, `#!/bin/sh`
- Content that is clearly shell syntax (variable assignments, if/then/fi, function blocks)

If script detected: run this file BEFORE indexing notebooks.
Extract a **Script Profile** and use it to enrich all notebook profiles.

---

## PHASE 1 — CLASSIFY SCRIPT TYPE

Read the full script. Detect type using these signals:

### ORCHESTRATION
All of these true:
- Contains `${DS_JOB} -run` or `dsjob -run`
- Main body is: set variables → build AUDIT_PARMS → run DS job
- No `tr` / `sed` / `awk` commands on data file content
- No `while read` loops processing file lines
- No FTP/sftp/wwdapget/wwdaplist operations on data files

### PRE-PROCESSING
Any of these true AND data manipulation happens BEFORE `${DS_JOB} -run`:
- Contains `tr` command on data file
- Contains `sed` command transforming file content
- Contains `awk` on file data
- Contains `grep` filtering file content (not just checking existence)
- Contains `while read` loop over file lines
- Contains `wwdapget` / `wwdaplist` / FTP download of data files
- Contains `cat` concatenating multiple data files

### POST-PROCESSING
Any of these true AND operations happen AFTER `${DS_JOB} -run`:
- Contains `sqlplus` or database update commands
- Contains `wwdapsar` or archive of output data files
- Contains processing of DS job output files

### MIXED
Contains both PRE-PROCESSING and POST-PROCESSING signals.

---

## PHASE 2 — EXTRACT SCRIPT PROFILE

Always extract these regardless of type:

```
script_profile = {
  "script_name"  : filename without extension (e.g. "wwpcaxb1")
  "job_id"       : last segment of script_name (e.g. "x17", "b1", "x89")
  "script_type"  : ORCHESTRATION | PRE-PROCESSING | POST-PROCESSING | MIXED
  "purpose"      : from header comment block (lines 8-11 typically)
  "ds_job_name"  : value of DS_JOB_NM variable
  "source_table" : value of SOURCE_TABLE_NAME or STG_TBL_NM (snake_case)
  "target_table" : value of TARGET_TABLE_NAME or TGT_TBL_NM (snake_case)
  "data_logic"   : [] list of extracted logic items (see Phase 3)
}
```

**Variable name patterns to scan for source/target:**

| Variable name | Maps to |
|---|---|
| `SOURCE_TABLE_NAME` | source_table |
| `STG_TBL_NM` | source_table |
| `SRC_TBL_NM` | source_table |
| `SRC_FILE_NM` | source_table (use stem, strip .csv/.txt) |
| `TARGET_TABLE_NAME` | target_table |
| `TGT_TBL_NM` | target_table |
| `TGT_TBL` | target_table |
| `DS_JOB_NM` | ds_job_name |
| `JOB_NAME` | ds_job_name (secondary) |

**Convert to snake_case:**
`PAAME_TRIAL_BALANCE` → `paame_trial_balance`
`PCM_MDL` → `pcm_mdl`
`PLNT_UOM_CONV_TBL` → `plnt_uom_conv_tbl`

---

## PHASE 3 — EXTRACT DATA LOGIC (PRE/POST-PROCESSING only)

For each data manipulation command found, create a logic item:

### tr commands → PySpark regexp_replace

```bash
# Remove Windows carriage return
tr -d \\015 < input > output
tr -d '\r'  < input > output
```
→
```python
# From shell script: tr -d \\015 (remove Windows CR characters)
df = df.withColumn("{col}", F.regexp_replace(F.col("{col}"), "\r", ""))
# REVIEW: tr operated on full file — specify which column(s) to clean
```

```bash
# Remove non-printable characters
tr -dc "[:alnum:][:space:][:punct:]" < input > output
```
→
```python
# From shell script: tr -dc alnum/space/punct (remove non-printable chars)
df = df.withColumn("{col}", F.regexp_replace(F.col("{col}"), "[^\\x20-\\x7E\\n]", ""))
# REVIEW: tr operated on full file — specify which column(s) to clean
```

### grep filters → PySpark filter

```bash
grep "^Baan." file > output          # keep lines starting with Baan.
grep -v "^$"  file > output          # remove blank lines
grep "STATUS=ACTIVE" file > output   # keep matching lines
```
→
```python
# From shell script: grep "^Baan." (filter rows starting with Baan.)
df = df.filter(F.col("{col}").startswith("Baan."))
# REVIEW: identify which column contains the filename/pattern being filtered

# From shell script: grep -v "^$" (remove blank/empty rows)
df = df.filter(F.col("{col}").isNotNull() & (F.trim(F.col("{col}")) != ""))
# REVIEW: specify which column to check for emptiness
```

### sed commands → PySpark regexp_replace

```bash
sed 's/|/,/g' input > output         # replace pipe with comma
sed 's/old/new/g' input > output     # general substitution
```
→
```python
# From shell script: sed 's/|/,/g' (replace pipe delimiter with comma)
df = df.withColumn("{col}", F.regexp_replace(F.col("{col}"), "\\|", ","))
# REVIEW: delimiter replacement may already be handled by Delta ingestion
```

### awk commands → PySpark

```bash
awk 'NR>1' file > output             # skip header row
awk -F',' '{print $1,$3}' file       # select columns
```
→
```python
# From shell script: awk 'NR>1' (skip header row)
# Delta read handles headers natively — verify this is not needed
# REVIEW: confirm source Delta table already excludes header row

# From shell script: awk column selection
df = df.select("{col1}", "{col3}")
# REVIEW: verify column names match Delta table schema
```

### cat concatenation → PySpark union

```bash
cat file1 file2 file3 > combined
```
→
```python
# From shell script: cat (concatenate multiple files)
# In Delta: if all files are in same table, no action needed
# If separate tables:
# REVIEW: verify if source_table contains all concatenated data
# or if multiple source tables need to be unioned:
# df = df1.unionByName(df2)
```

### File existence/size check → assert

```bash
if [ -e ${FILE} ]; then ... else exit 0; fi
if [ -s ${FILE} ]; then ... else exit 1; fi
```
→
```python
# From shell script: file existence check
assert spark.catalog.tableExists(source_table), \
    f"Source table not found: {source_table}"

# From shell script: file size check (has data)
assert df.count() > 0, \
    f"No input data in {source_table} — nothing to process"
```

### sqlplus update → Delta update

```bash
sqlplus user/pass@sid << EOF
  UPDATE CONTROL_TABLE SET STATUS='COMPLETE' WHERE JOB='${JOB_NAME}';
EOF
```
→
```python
# From shell script: sqlplus control table update
from delta.tables import DeltaTable
DeltaTable.forName(spark, control_table) \
    .update(
        condition=F.col("JOB_NAME") == job_name,
        set={"STATUS": F.lit("COMPLETE"),
             "END_TS": F.current_timestamp()}
    )
# REVIEW: verify control_table name and column names match Delta schema
```

---

## PHASE 4 — MAP SCRIPT TO NOTEBOOKS

**Matching algorithm (both combined):**

**Step 1 — Job ID match (primary):**
Extract job_id from script_name (e.g. `wwvehx17` → `vehx17`, `x17`, `17`).
Find all notebooks whose filename contains the same job_id suffix.
If match found → those are the target notebooks.

**Step 2 — Content match (secondary, when Step 1 ambiguous):**
- DS_JOB_NM in script vs `# Original DS name` in notebook traceability comments
- SOURCE_TABLE_NAME in script vs `spark.read` or `SRC_*` variable in notebook
- TARGET_TABLE_NAME in script vs `saveAsTable` or `TGT_*` variable in notebook

**Step 3 — If no match found:**
Report: "Script {name} — no matching notebook found by job ID or content.
Please confirm which notebook this script belongs to."

---

## PHASE 5 — ASSIGN CONTEXT TO CORRECT NOTEBOOK

Once mapping is confirmed:

**For ORCHESTRATION scripts:**

| Script variable | Goes to | Position |
|---|---|---|
| source_table (STG_TBL_NM) | First notebook in sequence | source_table widget defaultValue |
| target_table (TGT_TBL_NM) | Last notebook in sequence | target_table widget defaultValue |
| ds_job_name | All notebooks | Notebook title + purpose summary |
| purpose comment | All notebooks | Purpose line in %md Cell 0 |

If multiple notebooks in sequence, distribute source/target by step number:
- Step01 → source_table from script
- Step02+ → target_table from script
- Middle steps → source = previous step's output, target = next step's input

**For PRE-PROCESSING scripts:**

All of the above PLUS:
- data_logic items → injected as new cells in FIRST notebook (lowest step number)
- Position: after Cell 6 (table validation), before source read cell
- New section header added: `## 4 — Pre-processing & Data Cleaning`
- Each logic item = one cell with traceability comment:
  `# Source file : {script_name}`
  `# Logic type  : PRE-PROCESSING`
  `# Shell cmd   : {original shell command}`

**For POST-PROCESSING scripts:**

All of the above PLUS:
- data_logic items → injected AFTER last target write cell
- New section header: `## N — Post-processing`

---

## PHASE 6 — DISCARD LIST

Always discard these from shell scripts — never convert to notebook:

```
${DS_JOB} -run ...            DataStage job invocation
AUDIT_PARMS=... building      Legacy audit framework
echo "..." | $T               Log file writing
sh_header.sh                  Shell logging header
sh_trailer.sh                 Shell logging trailer
. dsenv                       DataStage environment setup
. pca.properties              Shell properties file sourcing
. wwdapgenfunc / wwdapds func Shell function libraries
wwdapsar                      File archiving
wwdapsar                      Archive functions
check_status function         Shell error handling
DS_SERVER / DS_DOMAIN         DataStage server config
DS_LOGIN                      DataStage login
PROJECT=PROD/TEST/DEV         DataStage project name
LOG_FILE= / T=                Logging infrastructure
cp of audit control files     Audit file management
SUB_STAT_JOB building         Shell path construction
DATA_DIR_PATH construction    Shell path construction
FTP move/rename operations    File operations (data in Delta)
```

---

## REPORT FORMAT — SCRIPT SECTION

Add this section to the advisor report when a script is present:

```
SCRIPT ANALYSIS
────────────────────────────────────────────────────────────────────
Script    : {script_name}.ksh
Type      : {ORCHESTRATION | PRE-PROCESSING | POST-PROCESSING | MIXED}
Purpose   : {from header comment}
DS Job    : {DS_JOB_NM value}
────────────────────────────────────────────────────────────────────
EXTRACTED FOR NOTEBOOKS:
  source_table : {value}  → {notebook name} source_table widget
  target_table : {value}  → {notebook name} target_table widget
  job title    : {value}  → all notebooks purpose summary

DATA LOGIC TO INJECT: {n items}  [only for PRE/POST-PROCESSING]
  [1] {description}  → {target notebook} Cell after validation
      Shell : {original command}
      PySpark: {converted code}
      # REVIEW: {what engineer must verify}

  [2] ...

DISCARDED:
  DS job invocation, audit params, logging, archiving,
  DS environment setup, shell infrastructure

NOTEBOOK MAPPING:
  {script_name} → {notebook1} (source_table)
               → {notebook2} (target_table)
               [HIGH | MEDIUM | LOW] confidence ({match method})
────────────────────────────────────────────────────────────────────
```
