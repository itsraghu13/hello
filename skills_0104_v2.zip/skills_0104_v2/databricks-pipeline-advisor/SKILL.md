---
name: databricks-pipeline-advisor
description: >
  Analyzes a folder of Databricks PySpark notebooks to build a dependency
  map, suggest consolidation, and optionally merge approved notebooks into
  one standardized combined notebook. Trigger on: "analyze these notebooks",
  "can we merge these", "consolidate this pipeline", "what order do these
  run in", "are there duplicates", "reduce number of notebooks", or when
  a user pastes multiple .py files or a folder listing. Analysis phase is
  always read-only. Merge only runs after explicit approval.
---

# Databricks Pipeline Advisor

Analyze a collection of Databricks notebooks. Show dependency map and
consolidation recommendations. Merge and standardize only after approval.

**Hard rules:**
- Analysis (Steps 1–3) is always read-only — no code generated
- Merge (Steps 4–5) only runs after `merge` command from user
- Never change business logic during merge — structure only
- One combined notebook output for the whole folder

---

## Step 0 — Detect and analyze script (if present)

Before indexing notebooks, check if input contains a shell script
(.ksh / .sh / .bash / starts with #!/bin/ksh or #!/bin/bash).

If script detected:
1. Read `references/script-analysis-rules.md`
2. Classify script type (ORCHESTRATION / PRE-PROCESSING / POST-PROCESSING / MIXED)
3. Extract script profile (source_table, target_table, ds_job_name, data_logic)
4. Map script to notebooks using job ID + content matching
5. Store script profile — use it to enrich notebook profiles in Step 2

If no script detected: skip this step entirely, proceed to Step 1.

## Step 1 — Detect input

Accept any of: filenames only, full notebook content, mixed, or a path.
For paths: ask user to paste content — cannot fetch from DBFS directly.
For filenames only: partial analysis (no source/target detection).

Read `references/analysis-rules.md` for extraction rules and merge signals.

## Step 2 — Index (silent, per notebook)

For each notebook extract:
- `file_name`, `seq_no`, `domain` — from filename pattern
- `sources`, `targets` — from SRC/TGT widgets → spark.read/saveAsTable → traceability comments → filename
- `stage_types` — from `# Node type` traceability comments
- `cell_count`, `converted_on` — from header

If script profile exists from Step 0:
- Override source_table defaultValue with script profile source_table
- Override target_table defaultValue with script profile target_table
- Add ds_job_name to notebook purpose
- Add data_logic items to notebook profile for injection during fix

## Step 3 — Analyze (silent, across all profiles)

Using all profiles:
1. Build dependency DAG — notebook A depends on B if A's source = B's target
2. Topological sort → execution order + parallel groups
3. Apply merge signals from `references/analysis-rules.md`
4. Detect redundancies (duplicate source reads, same target written by 2+ notebooks)
5. Detect orphans (no detected source or target)

## Step 4 — Report

Output this exact structure:

```
DATABRICKS PIPELINE ADVISOR
────────────────────────────────────────────────────────────────────
Notebooks : {n}   Sources : {n}   Targets : {n}
────────────────────────────────────────────────────────────────────

EXECUTION ORDER
  STAGE 1 (parallel): {notebook names}
  STAGE 2 (depends on Stage 1): {notebook names}
  INDEPENDENT: {notebook names}

MERGE CANDIDATES
  MERGE-01 — {type}  [MERGE | KEEP SEPARATE]  [{HIGH|MEDIUM|LOW} confidence]
    Notebooks : {list}
    Reason    : {one sentence}
    Scoring   : {✓ or ✗ for each of the 7 factors — see analysis-rules.md}
    Decision  : MERGE | KEEP SEPARATE
    Risk      : {LOW | MEDIUM | HIGH}

REDUNDANCIES
  RED-01 — {type}: {description}  [{LOW|MEDIUM|HIGH} severity}]

ORPHANS
  {filename} — {reason no dependencies detected}

INVENTORY
  File                     Cells  Sources  Targets  Stage Types
  ──────────────────────────────────────────────────────────────
  {filename}               {n}    {n}      {n}      {list}

SUMMARY
  Merge candidates  : {n}
  Redundancies      : {n}
  Orphans           : {n}
  Execution stages  : {n}
────────────────────────────────────────────────────────────────────
{CONTEXT-AWARE COMMANDS — see rules below}
────────────────────────────────────────────────────────────────────
```

Confidence levels: HIGH = SRC/TGT widgets found, MEDIUM = spark.read/saveAsTable found, LOW = filename only.

**Context-aware commands rule — choose the right block based on analysis result:**

If ALL merge candidates are KEEP SEPARATE:
```
Commands:
  fix all              → run standardizer on all {n} notebooks individually
  fix Step01,Step03    → fix specific notebooks only
  report only          → stop here, no changes made
```

If at least one merge candidate is MERGE:
```
Commands:
  merge all            → merge all MERGE candidates + fix kept-separate notebooks
  merge MERGE-01       → merge specific group only + fix kept-separate notebooks
  skip MERGE-02        → exclude group from merge, fix it individually instead
  fix all              → skip merging, fix all notebooks individually
  report only          → stop here, no changes made
```

If zero merge candidates found (no dependency patterns detected):
```
Commands:
  fix all              → run standardizer on all {n} notebooks individually
  fix Step01           → fix one specific notebook
  report only          → stop here, no changes made
```

**Never show `merge all` or `merge MERGE-xx` commands when all candidates are KEEP SEPARATE.**
**Always show `fix all` as an option — it is always valid regardless of merge outcome.**
**Always show `report only` as the last option.**

Also add to SUMMARY section when all are KEEP SEPARATE:
```
RECOMMENDED NEXT STEP:
  All notebooks should remain separate.
  Type: fix all  → standardizer will fix each notebook individually.
  Use this execution order for your Databricks Workflow:
  {repeat the execution order from the EXECUTION ORDER section}
```

## Step 5 — Execute (after command)

**If command is `merge ...`:**
Read `references/fix-rules-embedded.md` and assemble merged notebook.
See assembly order below.

**If command is `fix all` or `fix Step01,Step03`:**
Run standardizer rules from `references/fix-rules-embedded.md` on each
specified notebook individually — same fixes as datastage-notebook-standardizer.
Output one fixed notebook per input notebook, in sequence.
Label each output clearly:
```
── Fixed: Step01_Unload_ENR005.py ──────────────────────
[fixed notebook in ```python block]
── Fixed: Step03_Ins_SSD_TYP.py ────────────────────────
[fixed notebook in ```python block]
```

Assembly order:
1. `# Databricks notebook source`
2. Cell 0: `%md` purpose summary (enriched with ds_job_name from script if available)
3. Cell 1: `%md` "1 — Setup & Imports" header
4. Cell 2: unified imports
5. Cell 3: `%md` "2 — Parameters & Configuration" header
6. Cell 4: unified parameters (widget defaultValues from script profile if available)
7. Cell 5: `%md` "3 — Table Validation" header
8. Cell 6: assert tableExists for every source and target
   - Include only tables that will exist at runtime (external sources + final targets)
   - For every intermediate table eliminated by this merge: omit its assert and add:
     `# Intermediate table {name} eliminated — direct DataFrame handoff, assertion skipped`
   - One assert per table variable, no exceptions for tables that remain

If script type is PRE-PROCESSING and data_logic items exist:
9. Cell 7: `%md` "4 — Pre-processing & Data Cleaning" header
         `_Cleaning logic from {script_name}.ksh — applied before source read_`
10. Cell 8+: one cell per data_logic item with traceability block:
    ```python
    # COMMAND ----------
    # Source file  : {script_name}.ksh
    # Logic type   : PRE-PROCESSING
    # Shell cmd    : {original shell command}
    {converted PySpark code}
    # REVIEW: {what engineer must verify}
    ```
Then stage cells from notebooks in DAG order.

If script type is POST-PROCESSING:
- Inject data_logic cells AFTER last target write cell
- Add section header: `## N — Post-processing`
- Same traceability block format as above

If script type is ORCHESTRATION:
- No extra cells injected — only widget defaultValues enriched

For each approved merge group — eliminate intermediate tables:
- Remove write cell from upstream notebook
- Remove read cell from downstream notebook
- Connect DataFrames directly
- Add `# Intermediate table {name} eliminated — direct DataFrame handoff`
- Add `# REVIEW: {table_name} no longer written — verify no external consumers`

For notebooks kept separate — include their cells with origin separator:
```
# ══════════════════════════════════════════════════
# FROM: {original_notebook_filename}
# ══════════════════════════════════════════════════
```

Apply standardizer fixes inline during assembly (not as a second pass):
- I000: canonicalize imports
- G/EXPR: DataStage syntax → PySpark
- Q: SQL context fixes
- R: source/target conversion
- N: naming standards
- I002: collapse passthrough DataFrames
- L: logic fixes (aggregations, PIVOT, MISSING_HANDLER, CDC, FUNNEL, REMOVE_DUPLICATES)
- S: structural fixes (SparkSession.builder, __main__, mkdirs)
- SEC: security fixes (hardcoded credentials → clear value)

## Step 6 — Output

```
MERGE SUMMARY
─────────────────────────────────────────
Merged    : {n} groups — {filenames}
Kept      : {filenames}
Eliminated: {n} intermediate tables
Fixes     : {n} applied (AUTO: {n}  REVIEW: {n})
```

Then combined notebook in ```python block.
Then REVIEW checklist for any REVIEW-tier fixes.

---

## References

`references/analysis-rules.md` — load in Steps 2–3.
Filename patterns, source/target extraction, merge signal scoring,
redundancy detection, DAG logic, consolidation decision rules.

`references/script-analysis-rules.md` — load in Step 0 only (when script detected).
Script classification, extraction rules, shell→PySpark conversion map,
notebook mapping algorithm, discard list, report format.

`references/fix-rules-embedded.md` — load in Step 5 only.
All standardizer fix rules (Groups G Q R N I L S + stage patterns + expression map).
