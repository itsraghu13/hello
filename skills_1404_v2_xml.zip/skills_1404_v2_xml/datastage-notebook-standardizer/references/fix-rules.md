# Fix Rules — DataStage Notebook Standardizer
# Version: 2026-04-14
# Load during Step 2. Read fully before inspecting.

---

## NEVER TOUCH — read before applying any rule

These patterns must NEVER be modified regardless of which group fires:

| Pattern | Why |
|---|---|
| IF() inside F.expr("...") or expr("...") | Valid Spark SQL — not DataStage BASIC — **EXCEPTION: the null+empty guard pattern `IF(col IS NOT NULL And trim(col) <> '', <expr>, NULL) as ALIAS` IS converted by Group G rule G-NULL-GUARD** |
| IF() inside spark.sql("...") body | Valid Spark SQL — Group Q handles syntax only |
| IF() inside .filter("...") string argument | Valid Spark SQL — Group Q handles syntax only |
| <> inside spark.sql("...") body or .filter("...") string | Valid ANSI SQL — NEVER convert to != |
| String literals 'Y', 'N', 'true', 'false' in any branch | Never convert to boolean/integer |
| Any error code string '5005', '5006', '5016' etc. | Business values — never change |
| .alias("name") before a join | Intentional column disambiguation |
| toPandas() / collect() | Add # REVIEW: may OOM on large data only |
| CTEs (WITH ... AS), window functions, 4+ table JOINs | Keep spark.sql(), fix refs + syntax only |
| Traceability block comments | Preserve on every cell including cache cells |
| DataFrame variable names | Never rename — lnkChanges stays lnkChanges |

---

## GROUP G — DataStage Syntax in Python Context

**Applies ONLY when the pattern appears as a bare Python call — outside any string.**

Detection scope:
- `.withColumn("col", IF(...))` — bare Python call → fix
- `.filter(col <> '')` — bare Python → fix
- `.withColumn("col", F.expr("IF(...)"))` — inside expr() → DO NOT touch (except G-NULL-GUARD below)
- `.withColumn("col", expr("IF(...)"))` — inside expr() → DO NOT touch (except G-NULL-GUARD below)
- `spark.sql("... IF(...) ...")` — inside SQL string → DO NOT touch (Group Q handles)

| DataStage | PySpark | Confidence |
|---|---|---|
| IF(c, t, f) bare Python | F.when(c, t).otherwise(f) | AUTO |
| IF cond THEN t ELSE f bare Python | F.when(cond, t).otherwise(f) | AUTO |
| Trim(col) | F.trim(F.col("col")) | AUTO |
| Strip(col,"leading") | F.ltrim(F.col("col")) | AUTO |
| Strip(col,"trailing") | F.rtrim(F.col("col")) | AUTO |
| Upcase(col) | F.upper(F.col("col")) | AUTO |
| Downcase(col) | F.lower(F.col("col")) | AUTO |
| Left(col, n) | F.col("col").substr(1, n) | AUTO |
| Right(col, n) | F.expr(f"right(col, {n})") | AUTO |
| Mid(col, s, n) | F.col("col").substr(s, n) | AUTO |
| Length(col) bare Python | F.length(F.col("col")) | AUTO |
| IsNull(col) bare Python | F.col("col").isNull() | AUTO |
| IsNotNull(col) bare Python | F.col("col").isNotNull() | AUTO |
| NVL(col, val) bare Python | F.coalesce(F.col("col"), F.lit(val)) | AUTO |
| NullToEmpty(col) | F.coalesce(F.col("col"), F.lit("")) | AUTO |
| Index(col, s, n) | F.locate(s, F.col("col"), n) | AUTO |
| Convert(c, from, to) | F.regexp_replace(F.col("c"), from, to) | AUTO |
| DateToString(c, fmt) | F.date_format(F.col("c"), fmt) | AUTO |
| StringToDate(c, fmt) | F.to_date(F.col("c"), fmt) | AUTO |
| StringToTimestamp(c, fmt) | F.to_timestamp(F.col("c"), fmt) | AUTO |
| Age(col) / DaysSince(col) | F.datediff(F.current_date(), F.col("col")) | AUTO |
| Int(col) | F.col("col").cast("long") | AUTO |
| Abs(col) | F.abs(F.col("col")) | AUTO |
| Round(col, n) | F.round(F.col("col"), n) | AUTO |
| Mod(a, b) | F.col("a") % F.col("b") | AUTO |
| LJustify(col, n) | F.rpad(F.col("col"), n, " ") | AUTO |
| RJustify(col, n) | F.lpad(F.col("col"), n, " ") | AUTO |
| <> in Python .filter() or .withColumn() | != | AUTO |
| || string concat in Python context | F.concat(F.col("a"), F.col("b")) | AUTO |
| col1 : col2 (DataStage colon concat) | F.concat(F.col("col1"), F.col("col2")) | AUTO |
| LTrim(col) | F.ltrim(F.col("col")) | AUTO |
| RTrim(col) | F.rtrim(F.col("col")) | AUTO |
| Len(col) | F.length(F.col("col")) | AUTO |
| Str(col, n) | F.lpad(F.col("col"), n, " ") | AUTO |
| Not(expr) | ~(expr) | AUTO |
| Squote(col) | F.concat(F.lit("'"), F.col("col"), F.lit("'")) | AUTO |
| Dquote(col) | F.concat(F.lit('"'), F.col("col"), F.lit('"')) | AUTO |
| Num(col) | F.col("col").cast("double") | AUTO |
| Sqrt(col) | F.sqrt(F.col("col")) | AUTO |
| NullToZero(col) | F.coalesce(F.col("col"), F.lit(0)) | AUTO |
| StringToInteger(col) | F.col("col").cast("integer") | AUTO |
| StringToDecimal(col) | F.col("col").cast("double") | AUTO |
| IntToString(col) | F.col("col").cast("string") | AUTO |
| DecimalToString(col) | F.col("col").cast("string") | AUTO |
| Today() | F.current_date() | AUTO |
| Now() | F.current_timestamp() | AUTO |
| TimeStampToDate(col) | F.to_date(F.col("col")) | AUTO |
| SecondsToTime(col) | F.from_unixtime(F.col("col")) | AUTO |
| @NULL bare Python | F.lit(None) | AUTO |
| @TRUE bare Python | F.lit(True) | AUTO |
| @FALSE bare Python | F.lit(False) | AUTO |
| @INROWNUM | row_number() over partition window — see stage-patterns.md | REVIEW |
| @NUMROWS | count("*") over partition window — see stage-patterns.md | REVIEW |
| @OUTROWNUM | row_number() over global order window — see stage-patterns.md | REVIEW |

**When converting IF(c, t, f) to F.when(c, t).otherwise(f):**
- Preserve t and f values EXACTLY — 'Y' → F.lit('Y'), 'N' → F.lit('N')
- Never convert string literals to boolean or integer equivalents
- If t or f is a string literal → wrap with F.lit("value") explicitly

```python
# CORRECT — literal values preserved
.withColumn("REJECTRECORD", F.when(F.col("SIEBELACCTIDERR1") != "", F.lit("Y")).otherwise(F.lit("N")))

# WRONG — never do this
.withColumn("REJECTRECORD", F.when(F.col("SIEBELACCTIDERR1") != "", 1).otherwise(0))
```

### G-NULL-GUARD — F.expr null-and-empty guard pattern (AUTO · MEDIUM)

Lakebridge generates a DataStage boilerplate pattern: a null+empty check wrapped in SQL
`IF()` inside `F.expr()` or `expr()`. Convert the outer guard to native PySpark.
Preserve the inner value expression exactly by re-wrapping it in `F.expr("""...""")`.

**Detect these patterns (case-insensitive AND/And, both `<>` and `!=` match):**
```python
F.expr("""IF ( col IS NOT NULL And trim(col) <> '' , <value_expr> , NULL ) as ALIAS""")
expr("""IF ( col IS NOT NULL And trim(col) <> '' , <value_expr> , NULL ) as ALIAS""")
```

**Convert to:**
```python
F.when(
    F.col("col").isNotNull() & (F.trim(F.col("col")) != ""),
    F.expr("""<value_expr>""")
).otherwise(None).alias("ALIAS")
```

**Conversion rules:**
- `col IS NOT NULL And trim(col) <> ''` → `F.col("col").isNotNull() & (F.trim(F.col("col")) != "")`
- The inner `<value_expr>` is re-wrapped in `F.expr("""...""")` triple-quotes unchanged — do NOT rewrite it
- `NULL` in the else branch → `.otherwise(None)`
- `as ALIAS` suffix → `.alias("ALIAS")`
- Applies to both `F.expr()` and bare `expr()` — scan all cells

```python
# BEFORE
F.expr("""IF ( DealCorEffectiveDate IS NOT NULL And trim(DealCorEffectiveDate) <> '' ,
    to_timestamp(concat( date_format(current_timestamp,'yyyymmdd') , ' ' , '00:00:00' )) ,
    NULL ) as DLR_CORE_EFF_DTE"""),
F.expr("""IF ( DealCorTerminationDate IS NOT NULL And trim(DealCorTerminationDate) <> '' ,
    to_timestamp(concat( date_format(current_timestamp,'yyyymmdd') , ' ' , '00:00:00' )) ,
    NULL ) as DLR_CORE_TRMNT_DTE"""),

# AFTER
F.when(
    F.col("DealCorEffectiveDate").isNotNull() & (F.trim(F.col("DealCorEffectiveDate")) != ""),
    F.expr("""to_timestamp(concat( date_format(current_timestamp,'yyyymmdd') , ' ' , '00:00:00' ))""")
).otherwise(None).alias("DLR_CORE_EFF_DTE"),
F.when(
    F.col("DealCorTerminationDate").isNotNull() & (F.trim(F.col("DealCorTerminationDate")) != ""),
    F.expr("""to_timestamp(concat( date_format(current_timestamp,'yyyymmdd') , ' ' , '00:00:00' ))""")
).otherwise(None).alias("DLR_CORE_TRMNT_DTE"),
```

**Do NOT apply when:**
- The `IF()` condition tests anything other than `col IS NOT NULL And trim(col) <> ''`
  (e.g. CDC flag, error code, business condition) → leave it as `F.expr()` / `expr()`
- The expression is inside a `spark.sql("...")` body → Group Q handles that context

---

## GROUP Q — DataStage Syntax in SQL Context

Applies inside spark.sql("...") string bodies AND inside .filter("...") string arguments.
Q-HARD restructuring rules apply to spark.sql() only — .filter() strings are simpler and safe to fix in place.

**Q-HARD — ABSOLUTE RULE, no exceptions:**
NEVER rewrite, summarize, simplify, or restructure the body of a spark.sql() call.
Copy the SQL body VERBATIM. The ONLY permitted change is replacing hardcoded table
name strings with f-string variable references (e.g. `ENR_HIER` → `{source_table}`).
Fabricating table references, dropping columns, changing WHERE conditions, collapsing
subqueries, or reformatting JOINs are all CRITICAL violations that produce runtime errors.

**Q-SOURCES — scan ALL nesting levels for table references:**
When parameterizing table names, scan every FROM and JOIN clause at ALL levels —
including inside inline subqueries, CTEs, and nested FROM clauses. Every distinct
table found must be added as a separate source_table parameter. A table inside a
subquery is just as real as a table in the outer FROM. Missing a subquery table =
CRITICAL violation (hardcoded name left in SQL).

**Q-VERIFY — cross-check SELECT columns after fixing:**
After fixing a spark.sql() SOURCE cell, verify every column in its SELECT list
exists by checking the NEXT cell that consumes the DataFrame. If the downstream cell
references df.COLUMN_NAME, that column MUST be present in the SELECT. Missing columns
= CRITICAL runtime error. Flag any discrepancy as REVIEW before outputting.

| DataStage | Spark SQL fix | Confidence |
|---|---|---|
| IF(c, t, f) inside SQL | CASE WHEN c THEN t ELSE f END | AUTO |
| IF cond THEN t ELSE f inside SQL | CASE WHEN c THEN t ELSE f END | AUTO |
| IsNull(col) inside SQL or .filter() string | col IS NULL | AUTO |
| IsNotNull(col) inside SQL or .filter() string | col IS NOT NULL | AUTO |
| NVL(col, val) capital N inside SQL | coalesce(col, val) | AUTO |
| <> inside SQL | KEEP — valid ANSI SQL | — |
| trim(), upper(), lower() inside SQL | KEEP — valid Spark SQL | — |
| String literal with trailing spaces: `= '2 '` | Strip spaces → `= '2'` — **REVIEW: trailing space may be DataStage CHAR field padding; verify target column data before removing** | REVIEW |

**When to keep spark.sql() vs convert to DataFrame API:**

| SQL Content | Action |
|---|---|
| Single-table SELECT + WHERE (no JOIN, no GROUP BY, no aggregation) | Convert to DataFrame API |
| Any JOIN present | Keep spark.sql() — fix refs and syntax only |
| Any GROUP BY present | Keep spark.sql() — fix refs and syntax only |
| Any aggregation function present | Keep spark.sql() — fix refs and syntax only |
| CTEs (WITH ... AS) | Keep spark.sql() — fix refs and syntax only |
| Window functions (OVER PARTITION BY) | Keep spark.sql() — fix refs and syntax only |
| Subqueries (inline or correlated) | Keep spark.sql() — fix refs and syntax only |
| UNION / UNION ALL | Keep spark.sql() — fix refs and syntax only |

**Default rule: when in doubt, keep spark.sql(). Only convert when 100% safe.**

**SQL fixes (apply when keeping spark.sql()):**

| Pattern | Fix | Confidence |
|---|---|---|
| GROUP BY 1,2 positional | Replace with actual column names | AUTO |
| SELECT * with known schema | Keep as-is — schema enforcement is Delta's job | — |

---

## GROUP R — Source / Target Conversion

**Rule: every source read → Delta. No exceptions.**

| Original | Fixed |
|---|---|
| spark.read.csv(path) | spark.read.format("delta").table(source_table) |
| spark.read.parquet(path) | spark.read.format("delta").table(source_table) |
| spark.read.json(path) | spark.read.format("delta").table(source_table) |
| spark.read.format("jdbc").load() | spark.read.format("delta").table(source_table) |
| spark.read.format("oracle")... | spark.read.format("delta").table(source_table) |
| spark.read.format("delta").load(path) | spark.read.format("delta").table(source_table) |
| Any spark.read not format("delta").table(...) | spark.read.format("delta").table(source_table) |
| df.write.csv/parquet/json(path) | df.write.format("delta").mode(load_type).saveAsTable(target_table) |
| Target with DSX WriteMode=1 + UpdateStatement (via advisor dsx_table_map) | Replace `.saveAsTable()` or `.whenMatchedUpdateAll()` with DeltaTable `.whenMatchedUpdate(set={...})` using exact SET columns from UpdateStatement | REVIEW |
| DSX target is source table (is_markback=True, via advisor dsx_table_map) | Map to `source_table` widget, not `target_table`; remove spurious target_table widget if only used for this stage | REVIEW |

All confidence: AUTO (except DSX-derived rows which require dsx_table_map from advisor and are always REVIEW). For multiple sources use source_table1, source_table2 etc.

---

## GROUP N — Naming Standards + Teradata Placeholder Replacement

**Variable naming — absolute rule:**
- Single source: source_table · Single target: target_table
- Multiple: source_table1, source_table2 · target_table1, target_table2
- NEVER SRC, TGT, SRC1, TGT1, SRC_n, TGT_n

**Teradata database placeholder replacement (AUTO):**

Both syntax forms appear in Lakebridge output. Replace ALL occurrences:

| Pattern found | Replace with | Notes |
|---|---|---|
| {TERA_STG_TABLE_DATABASE}.TABLE_NAME | {source_table} | Curly-brace f-string form |
| {TERA_ENT_VIEW_DATABASE}.TABLE_NAME | {source_table2} | If second source |
| {TERA_ENT_TABLE_DATABASE}.TABLE_NAME | {target_table} | Target table |
| {TERA_LGCY_VIEW_DATABASE}.TABLE_NAME | {source_table3} | Legacy view — use source_table3 to avoid collision with source_table2 |
| {TARGET_TABLE_NAME} inside SQL | {target_table} | Widget variable |
| #$TERA_STG_TABLE_DATABASE#.TABLE_NAME | {source_table} | Hash-dollar form |
| #$TERA_ENT_VIEW_DATABASE#.TABLE_NAME | {source_table2} | Hash-dollar form |
| #$TERA_LGCY_VIEW_DATABASE#.TABLE_NAME | {source_table3} | Hash-dollar form — use source_table3, not source_table2 |
| ${STG_BTCH_NO} inside SQL string | {STG_BTCH_NO} | Remove $ only |
| $'${EXTRACT_CREAT_TS}' inside SQL | '{EXTRACT_CREAT_TS}' | Remove $ only |

After replacement, ensure the replaced variable is declared in the parameters cell.
If it maps to source_table or target_table → already declared.
If it introduces a new variable → add widget declaration.

**Legacy parameter rules:**

| Parameter | Action |
|---|---|
| TERA_SERVER_NAME, TERA_*_DATABASE, TERA_*_VIEW | Remove |
| DATADIR, SUB, STAT, INST_NO | Remove |
| *PASSWD*, *_USER_ID, *_USER_WW_* | Remove + clear value |
| STG_BTCH_NO, BTCH_NO, PRCS_AUDT_NO | Keep if referenced anywhere in notebook |
| EXTRACT_CREAT_TS, JOB, TARGET_TABLE_NAME | Keep if referenced anywhere in notebook |

"Referenced anywhere" means: present as a **bare Python variable** (unquoted) in any Python
expression, OR present as `{PARAM}` inside any f-string SQL body including spark.sql(f"""...""").
Scan the FULL notebook — every cell, every line.

**COUNTS as referenced (keep the widget):**
- `F.lit(PRCS_AUDT_NO)` — bare variable in Python expression
- `F.when(F.col("x") == BTCH_NO, ...)` — bare variable in condition
- `spark.sql(f"""... WHERE COL = {PRCS_AUDT_NO} ...""")` — f-string interpolation in SQL
- `.withColumn("col", F.lit(STG_BTCH_NO))` — bare variable in withColumn

**DOES NOT count as referenced (may remove if this is the only occurrence):**
- `Input_Table.PRCS_AUDT_NO` — this is a DataFrame column attribute access, NOT the widget variable
- `.alias('PRCS_AUDT_NO')` — column rename string literal, not a variable reference
- `"PRCS_AUDT_NO"` or `'PRCS_AUDT_NO'` anywhere in quotes — string value, not a variable

| Issue | Fix | Confidence |
|---|---|---|
| Legacy widget not referenced anywhere in notebook | Remove widget + variable | AUTO |
| Old CATALOG/SCHEMA/PREFIX style | Replace with source_*/target_* | AUTO |
| Any SRC/TGT/SRC_n/TGT_n uppercase | Replace with lowercase source_table/target_table | AUTO |
| Hardcoded "catalog.schema.table" string | Replace with f"{source_table}" | AUTO |
| Table not in 3-part UC format | Reconstruct as 3-part f-string | AUTO |

---

## GROUP I — Imports and Passthrough DataFrames

**Canonical import form — one style only:**
```python
from pyspark.sql import functions as F
from pyspark.sql.window import Window        # only if Window used
from delta.tables import DeltaTable          # only if DeltaTable used
```

| Pattern detected | Fix | Confidence |
|---|---|---|
| import pyspark.sql.functions as F | → from pyspark.sql import functions as F | AUTO |
| from pyspark.sql.functions import col, lit, ... | Remove; use F.col(), F.lit() | AUTO |
| from pyspark.sql.functions import * | Remove; replace all bare names with F. | AUTO |
| from pyspark.sql import * | Remove; replace with canonical | AUTO |
| from pyspark import SparkContext | Remove | AUTO |
| from pyspark.sql import SparkSession | Remove | AUTO |
| import os / import sys / import subprocess | Remove | AUTO |
| df_b = df_a (passthrough alias, no transformation) | Collapse — replace all df_b refs with df_a — **SKIP if df_b or df_a appears in any `.join()` or `.alias()` call downstream (join disambiguation)** | AUTO |
| col("x") without F. prefix | F.col("x") | AUTO |
| lit("x") without F. prefix | F.lit("x") | AUTO |
| when(...) without F. prefix | F.when(...) | AUTO |
| expr(...) without F. prefix | F.expr(...) | AUTO |
| df_var.COLUMN_NAME in a `.select()` chained after one or more `.join()` calls | df_var["COLUMN_NAME"] — bracket form preserves the DataFrame qualifier; never F.col() here because Spark cannot resolve ambiguous column names after multi-joins | AUTO |
| df_var.COLUMN_NAME.alias("ALIAS") in a `.select()` chained after `.join()` calls | df_var["COLUMN_NAME"].alias("ALIAS") | AUTO |
| df_var.COLUMN_NAME outside a post-join `.select()` (standalone DataFrame operation) | F.col("COLUMN_NAME") | AUTO |
| df_var.COLUMN_NAME.alias("ALIAS") outside a post-join `.select()` | F.col("COLUMN_NAME").alias("ALIAS") | AUTO |

---

## GROUP S — Structural Fixes

| Issue | Fix | Confidence |
|---|---|---|
| Missing # COMMAND ---------- between cells | Add separator | AUTO |
| SparkSession.builder block | Remove entirely | AUTO |
| if __name__ == "__main__": block | Remove entirely | AUTO |
| dbutils.fs.mkdirs / os.makedirs / mkdir | Remove entirely | AUTO |
| Error handler cell (dbutils.notebook.exit only) | Remove | AUTO |
| Error handler cell with business logic | Convert to try/except, keep logic | REVIEW |
| `display(df)` / `display(df.limit(n))` in a code cell | Remove — display() is interactive-only, fails silently in Databricks Jobs | AUTO |
| `display(df)` immediately after a source read or target write | Keep the `print(f"[stage] ...")` line, remove only the display() call | AUTO |

---

## GROUP SEC — Security

| Issue | Fix | Confidence |
|---|---|---|
| Hardcoded password in widget defaultValue | Clear value to '' | AUTO |
| Hardcoded password in variable assignment | Clear value to '' | AUTO |
| Hardcoded connection string with credentials | Clear credentials | AUTO |

```python
# BEFORE
dbutils.widgets.text(name='EDW_SPA_USER_WW_TERA_PASSWD', defaultValue='HDI@IJV8O9JN064IL')

# AFTER — credential cleared, secrets stub added below widget declaration:
dbutils.widgets.text(name='EDW_SPA_USER_WW_TERA_PASSWD', defaultValue='')
# BEFORE RUNNING: replace defaultValue='' with the secret:
#   dbutils.secrets.get(scope="<your-scope>", key="<your-key-name>")
# Example: dbutils.widgets.text(name='EDW_SPA_USER_WW_TERA_PASSWD',
#              defaultValue=dbutils.secrets.get(scope="kv-prod", key="edw-spa-passwd"))
# REVIEW: credential removed — configure the secret in Databricks Secrets (scope + key) before running
```

---

## GROUP L — Logic Fixes

### Broken aggregation groupBy().select() (AUTO)

Lakebridge sometimes generates:
```python
df.groupBy("col1","col2").select("col1","col2",F.sum("val").alias("total"))
```
This raises AnalysisException. Fix:
```python
df.groupBy("col1","col2").agg(F.sum("val").alias("total"))
```

### DataFrame cache and unpersist (REVIEW)

Add .cache() when a DataFrame variable is read in 2+ downstream cells (used more than once).
Add .unpersist() after the last cell that reads it.

**This rule ONLY adds .cache() and .unpersist() — nothing else changes.**

```
NEVER rename the variable
NEVER merge cells
NEVER change any withColumn expression or literal value
NEVER drop columns or traceability comments
```

Detection:
1. Count cells that READ each variable as input (.filter, .select, .join, assignment from it)
2. If read count >= 2 → cache candidate
3. Find LAST WRITE cell (last assignment to that variable) → append .cache() as final method
4. Find LAST READ cell → add variableName.unpersist() # memory released immediately after

```python
# CORRECT — only .cache() added, everything else identical
# NOTE: the F.expr(f"""IF(...)""") calls below are intentionally kept as-is —
# they contain business conditions (IS NULL, = '', <> '') that are NOT the
# null+empty guard pattern, so G-NULL-GUARD does NOT apply here.
lnkChanges = lnkChanges \
    .withColumn("SIEBELACCTIDERR1", F.expr(f"""IF(SS_SIEBEL_ACCT_ID IS NULL, '5005', IF(trim(SS_SIEBEL_ACCT_ID) = '', '5005', ''))""")) \
    .withColumn("REJECTRECORD", F.expr(f"""IF(SIEBELACCTIDERR1 <> '', 'Y', 'N')""")) \
    .cache()
# REVIEW: cache() added — lnkChanges read in 2+ cells — verify cluster memory

# ... cells using lnkChanges unchanged ...

lnkChanges.unpersist()  # memory released
```

Rules:
- Variable name NEVER changes
- ONE .cache() per variable on last WRITE cell
- ONE .unpersist() per variable after last READ
- If last read feeds a target write: unpersist after write + print line

### Timestamp format tokens (AUTO)

| DataStage | Spark |
|---|---|
| %hh | HH |
| %nn | mm |
| %ss | ss |
| YYYY | yyyy |

### CurrentTimestamp() unqualified (AUTO)

CurrentTimestamp() with capital C → F.current_timestamp()

### Capital-letter function names unqualified (AUTO)

| Pattern | Fix |
|---|---|
| LENGTH(col) unqualified | F.length(col) |
| SUBSTRING(col, s, n) unqualified | F.substring(col, s, n) |
| TRIM(col) unqualified | F.trim(col) |
| COALESCE(a, b) unqualified | F.coalesce(a, b) |

### lit() wrapping column name (REVIEW)

lit(COLUMN_NAME) where COLUMN_NAME is a column, not a Python variable:
```python
# BEFORE
LENGTH(coalesce(lit(LANGCDERR1) + lit(SCRNCOLNMEERR1), ''))

# AFTER
F.length(F.coalesce(F.concat(F.col("LANGCDERR1"), F.col("SCRNCOLNMEERR1")), F.lit("")))
# REVIEW: verify concat is the correct combination logic
```

### Self-referential lag/window SEQNO (REVIEW)

DataStage running counters using lag() referencing the column being computed — invalid PySpark.
```python
# BEFORE
expr(f"""IF(ERR_CD <> '', lag(IF(ERR_CD<>'', SEQNO+1, SEQNO)) over(ORDER BY DF_ROW_ID)+1, ...)""")

# AFTER
_w = Window.orderBy("DF_ROW_ID")
df = df.withColumn("ERR_FLAG", (F.col("ERR_CD") != "").cast("int")) \
       .withColumn("SEQNO", F.sum("ERR_FLAG").over(_w))
# REVIEW: SEQNO = running count of non-empty ERR_CD rows — verify matches original intent
```
