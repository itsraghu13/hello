# Script Analysis Rules — Shell Script → Notebook Context
# Read when input contains a .ksh / .sh / .bash file

---

## STEP 0 — DETECT SCRIPT IN INPUT

A script is present if input contains any of:
- File with `.ksh`, `.sh`, `.bash` extension
- File starting with `#!/bin/ksh`, `#!/bin/bash`, `#!/bin/sh`
- Content that is clearly shell syntax (variable assignments, if/then/fi, function blocks)

If script detected: run this file BEFORE indexing notebooks.
Extract a **Script Profile** and use it to enrich all notebook profiles.

---

## PHASE 1 — CLASSIFY SCRIPT TYPE

Read the full script. Detect type using these signals:

### ORCHESTRATION
All of these true:
- Contains `${DS_JOB} -run` or `dsjob -run`
- Main body is: set variables → build AUDIT_PARMS → run DS job
- No `tr` / `sed` / `awk` commands on data file content
- No `while read` loops processing file lines
- No FTP/sftp/wwdapget/wwdaplist operations on data files

### PRE-PROCESSING
Any of these true AND data manipulation happens BEFORE `${DS_JOB} -run`:
- Contains `tr` command on data file
- Contains `sed` command transforming file content
- Contains `awk` on file data
- Contains `grep` filtering file content (not just checking existence)
- Contains `while read` loop over file lines
- Contains `wwdapget` / `wwdaplist` / FTP download of data files
- Contains `cat` concatenating multiple data files

### POST-PROCESSING
Any of these true AND operations happen AFTER `${DS_JOB} -run`:
- Contains `sqlplus` or database update commands
- Contains `wwdapsar` or archive of output data files
- Contains processing of DS job output files

### MIXED
Contains both PRE-PROCESSING and POST-PROCESSING signals.

---

## PHASE 2 — EXTRACT SCRIPT PROFILE

Always extract these regardless of type:

```
script_profile = {
  "script_name"  : filename without extension (e.g. "wwpcaxb1")
  "job_id"       : last segment of script_name (e.g. "x17", "b1", "x89")
  "script_type"  : ORCHESTRATION | PRE-PROCESSING | POST-PROCESSING | MIXED
  "purpose"      : from header comment block (lines 8-11 typically)
  "ds_job_name"  : value of DS_JOB_NM variable
  "source_table" : value of SOURCE_TABLE_NAME or STG_TBL_NM (snake_case)
  "target_table" : value of TARGET_TABLE_NAME or TGT_TBL_NM (snake_case)
  "data_logic"   : [] list of extracted logic items (see Phase 3)
}
```

**Variable name patterns to scan for source/target:**

| Variable name | Maps to |
|---|---|
| `SOURCE_TABLE_NAME` | source_table |
| `STG_TBL_NM` | source_table |
| `SRC_TBL_NM` | source_table |
| `SRC_FILE_NM` | source_table (use stem, strip .csv/.txt) |
| `TARGET_TABLE_NAME` | target_table |
| `TGT_TBL_NM` | target_table |
| `TGT_TBL` | target_table |
| `DS_JOB_NM` | ds_job_name |
| `JOB_NAME` | ds_job_name (secondary) |

**Convert to snake_case:**
`PAAME_TRIAL_BALANCE` → `paame_trial_balance`
`PCM_MDL` → `pcm_mdl`
`PLNT_UOM_CONV_TBL` → `plnt_uom_conv_tbl`

---

## PHASE 3 — EXTRACT DATA LOGIC (PRE/POST-PROCESSING only)

For each data manipulation command found, create a logic item:

### tr commands → PySpark regexp_replace

```bash
# Remove Windows carriage return
tr -d \\015 < input > output
tr -d '\r'  < input > output
```
→
```python
# From shell script: tr -d \\015 (remove Windows CR characters)
df = df.withColumn("{col}", F.regexp_replace(F.col("{col}"), "\r", ""))
# REVIEW: tr operated on full file — specify which column(s) to clean
```

```bash
# Remove non-printable characters
tr -dc "[:alnum:][:space:][:punct:]" < input > output
```
→
```python
# From shell script: tr -dc alnum/space/punct (remove non-printable chars)
df = df.withColumn("{col}", F.regexp_replace(F.col("{col}"), "[^\\x20-\\x7E\\n]", ""))
# REVIEW: tr operated on full file — specify which column(s) to clean
```

### grep filters → PySpark filter

```bash
grep "^Baan." file > output          # keep lines starting with Baan.
grep -v "^$"  file > output          # remove blank lines
grep "STATUS=ACTIVE" file > output   # keep matching lines
```
→
```python
# From shell script: grep "^Baan." (filter rows starting with Baan.)
df = df.filter(F.col("{col}").startswith("Baan."))
# REVIEW: identify which column contains the filename/pattern being filtered

# From shell script: grep -v "^$" (remove blank/empty rows)
df = df.filter(F.col("{col}").isNotNull() & (F.trim(F.col("{col}")) != ""))
# REVIEW: specify which column to check for emptiness
```

### sed commands → PySpark regexp_replace

```bash
sed 's/|/,/g' input > output         # replace pipe with comma
sed 's/old/new/g' input > output     # general substitution
```
→
```python
# From shell script: sed 's/|/,/g' (replace pipe delimiter with comma)
df = df.withColumn("{col}", F.regexp_replace(F.col("{col}"), "\\|", ","))
# REVIEW: delimiter replacement may already be handled by Delta ingestion
```

### awk commands → PySpark

```bash
awk 'NR>1' file > output             # skip header row
awk -F',' '{print $1,$3}' file       # select columns
```
→
```python
# From shell script: awk 'NR>1' (skip header row)
# Delta read handles headers natively — verify this is not needed
# REVIEW: confirm source Delta table already excludes header row

# From shell script: awk column selection
df = df.select("{col1}", "{col3}")
# REVIEW: verify column names match Delta table schema
```

### cat concatenation → PySpark union

```bash
cat file1 file2 file3 > combined
```
→
```python
# From shell script: cat (concatenate multiple files)
# In Delta: if all files are in same table, no action needed
# If separate tables:
# REVIEW: verify if source_table contains all concatenated data
# or if multiple source tables need to be unioned:
# df = df1.unionByName(df2)
```

### File existence/size check → RuntimeError

```bash
if [ -e ${FILE} ]; then ... else exit 0; fi
if [ -s ${FILE} ]; then ... else exit 1; fi
```
→
```python
# From shell script: file existence check
if not spark.catalog.tableExists(source_table):
    raise RuntimeError(f"[PIPELINE ABORT] Source table not found: {source_table}. Check widget defaultValues and Unity Catalog permissions.")

# From shell script: file size check (has data)
if df.count() == 0:
    raise RuntimeError(f"[PIPELINE ABORT] No input data in {source_table} — nothing to process.")
```

### sqlplus update → Delta update

```bash
sqlplus user/pass@sid << EOF
  UPDATE CONTROL_TABLE SET STATUS='COMPLETE' WHERE JOB='${JOB_NAME}';
EOF
```
→
```python
# From shell script: sqlplus control table update
from delta.tables import DeltaTable
DeltaTable.forName(spark, control_table) \
    .update(
        condition=F.col("JOB_NAME") == job_name,
        set={"STATUS": F.lit("COMPLETE"),
             "END_TS": F.current_timestamp()}
    )
# REVIEW: verify control_table name and column names match Delta schema
```

---

## PHASE 4 — MAP SCRIPT TO NOTEBOOKS

**Matching algorithm (both combined):**

**Step 1 — Job ID match (primary):**
Extract job_id from script_name (e.g. `wwvehx17` → `vehx17`, `x17`, `17`).
Find all notebooks whose filename contains the same job_id suffix.
If match found → those are the target notebooks.

**Step 2 — Content match (secondary, when Step 1 ambiguous):**
- DS_JOB_NM in script vs `# Original DS name` in notebook traceability comments
- SOURCE_TABLE_NAME in script vs `spark.read` or `SRC_*` variable in notebook
- TARGET_TABLE_NAME in script vs `saveAsTable` or `TGT_*` variable in notebook

**Step 2a — Tie-breaking when Step 2 is ambiguous:**
If content matching identifies 2+ notebooks with equal fit (same DS job name, same table names):
- Mark ALL candidates as `[LOW]` confidence
- Add to NOTEBOOK MAPPING section: `# REVIEW: script mapping ambiguous — {n} candidates found ({list}). Confirm which notebook owns this script.`
- Do NOT inject widget defaultValues or data_logic until engineer confirms the mapping
- Still report the script profile in SCRIPT ANALYSIS section so engineer has the data

**Step 3 — If no match found:**
Report: "Script {name} — no matching notebook found by job ID or content.
Please confirm which notebook this script belongs to."

---

## PHASE 5 — ASSIGN CONTEXT TO CORRECT NOTEBOOK

Once mapping is confirmed:

**For ORCHESTRATION scripts:**

| Script variable | Goes to | Position |
|---|---|---|
| source_table (STG_TBL_NM) | First notebook in sequence | source_table widget defaultValue |
| target_table (TGT_TBL_NM) | Last notebook in sequence | target_table widget defaultValue |
| ds_job_name | All notebooks | Notebook title + purpose summary |
| purpose comment | All notebooks | Purpose line in %md Cell 0 |

If multiple notebooks in sequence, distribute source/target by step number:
- Step01 → source_table from script
- Step02+ → target_table from script
- Middle steps → source = previous step's output, target = next step's input

**For PRE-PROCESSING scripts:**

All of the above PLUS:
- data_logic items → injected as new cells in FIRST notebook (lowest step number)
- Position: after Cell 6 (table validation), before source read cell
- New section header added: `## 4 — Pre-processing & Data Cleaning`
- Each logic item = one cell with traceability comment:
  `# Source file : {script_name}`
  `# Logic type  : PRE-PROCESSING`
  `# Shell cmd   : {original shell command}`

**For POST-PROCESSING scripts:**

All of the above PLUS:
- data_logic items → injected AFTER last target write cell
- New section header: `## N — Post-processing`

**For MIXED scripts (both PRE and POST-PROCESSING signals):**

Apply both PRE and POST rules to the respective notebooks:

1. **Pre-processing data_logic items** → inject in FIRST notebook (lowest step number)
   - Position: after Cell 6 (table validation), before source read cell
   - Section header: `## 4 — Pre-processing & Data Cleaning`
   - Each logic item = one cell with traceability block (same format as PRE-PROCESSING)

2. **Post-processing data_logic items** → inject in LAST notebook (highest step number)
   - Position: after last target write cell
   - Section header: `## N — Post-processing`
   - Each logic item = one cell with traceability block (same format as POST-PROCESSING)

3. **Widget defaultValues** (source_table, target_table, ds_job_name) → applied to all
   notebooks as in ORCHESTRATION rules above.

4. When classifying logic items as pre vs post for a MIXED script:
   - Items found BEFORE the `${DS_JOB} -run` line → PRE-PROCESSING → first notebook
   - Items found AFTER the `${DS_JOB} -run` line → POST-PROCESSING → last notebook

---

## PHASE 6 — DISCARD LIST

Always discard these from shell scripts — never convert to notebook:

```
${DS_JOB} -run ...            DataStage job invocation
AUDIT_PARMS=... building      Legacy audit framework
echo "..." | $T               Log file writing
sh_header.sh                  Shell logging header
sh_trailer.sh                 Shell logging trailer
. dsenv                       DataStage environment setup
. pca.properties              Shell properties file sourcing
. wwdapgenfunc / wwdapds func Shell function libraries
wwdapsar                      File archiving
wwdapsar                      Archive functions
check_status function         Shell error handling
DS_SERVER / DS_DOMAIN         DataStage server config
DS_LOGIN                      DataStage login
PROJECT=PROD/TEST/DEV         DataStage project name
LOG_FILE= / T=                Logging infrastructure
cp of audit control files     Audit file management
SUB_STAT_JOB building         Shell path construction
DATA_DIR_PATH construction    Shell path construction
FTP move/rename operations    File operations (data in Delta)
```

---

## REPORT FORMAT — SCRIPT SECTION

Add this section to the advisor report when a script is present:

```
SCRIPT ANALYSIS
────────────────────────────────────────────────────────────────────
Script    : {script_name}.ksh
Type      : {ORCHESTRATION | PRE-PROCESSING | POST-PROCESSING | MIXED}
Purpose   : {from header comment}
DS Job    : {DS_JOB_NM value}
────────────────────────────────────────────────────────────────────
EXTRACTED FOR NOTEBOOKS:
  source_table : {value}  → {notebook name} source_table widget
  target_table : {value}  → {notebook name} target_table widget
  job title    : {value}  → all notebooks purpose summary

DATA LOGIC TO INJECT: {n items}  [only for PRE/POST-PROCESSING]
  [1] {description}  → {target notebook} Cell after validation
      Shell : {original command}
      PySpark: {converted code}
      # REVIEW: {what engineer must verify}

  [2] ...

DISCARDED:
  DS job invocation, audit params, logging, archiving,
  DS environment setup, shell infrastructure

NOTEBOOK MAPPING:
  {script_name} → {notebook1} (source_table)
               → {notebook2} (target_table)
               [HIGH | MEDIUM | LOW] confidence ({match method})
────────────────────────────────────────────────────────────────────
```
