# Stage Patterns — DataStage Notebook Standardizer
# Read when notebook contains TRANSFORMER, AGGREGATOR, PIVOT, SCD,
# LOOKUP, JOIN, or SORT stage comments, or relevant PySpark patterns.

---

## TRANSFORMER STAGE

**Detection:** `# Processing node ... type TRANSFORMER` or `# type SOURCE`
comment with `.withColumn()` chains containing DataStage BASIC expressions.

**Common Lakebridge failures:**
- BASIC functions not mapped: `Space()`, `Field()`, `Str()`, `Index()`
- `@INROWNUM` left as placeholder or missing
- `@NULL` not converted to `F.lit(None)`
- Multi-output links with conditional routing only partially generated
- `If/Then/Else` chains converted to nested `when()` with wrong precedence
- DataStage date macros (`%yyyy`, `%mm`, `Oconv`, `Iconv`) not converted
- `Not(expr)` left as DataStage syntax instead of `~(expr)`

**Fix — string function patterns:**
```python
# Space(n) — pad with spaces
F.rpad(F.lit(""), n, " ")

# Field(col, delim, n) — split and get nth token (1-based in DS)
F.split(F.col("col"), delim)[n - 1]

# Str(col, n) — left-pad to width n
F.lpad(F.col("col"), n, " ")

# Index(col, str, n) — find nth occurrence (use locate for first)
F.locate("search_str", F.col("col"))

# Not(expr) — logical NOT
~(expr)

# @NULL
F.lit(None)
```

**Fix — @INROWNUM (row number within group):**
```python
from pyspark.sql.window import Window
# Inspect original stage for partition key — use lit(1) if no partition
_w = Window.partitionBy("partition_key_col").orderBy(F.lit(1))
df = df.withColumn("row_num", F.row_number().over(_w))
# REVIEW: partitionBy key inferred — verify correct partition column
```

**Fix — @NUMROWS (total row count within partition):**
```python
from pyspark.sql.window import Window
_w_count = Window.partitionBy("partition_key_col")
df = df.withColumn("num_rows", F.count("*").over(_w_count))
# REVIEW: partitionBy key inferred — verify correct partition column
```

**Fix — @OUTROWNUM (global row number across all rows):**
```python
from pyspark.sql.window import Window
_w_global = Window.orderBy(F.lit(1))  # CRITICAL REVIEW: replace F.lit(1) with a real sort key
df = df.withColumn("out_row_num", F.row_number().over(_w_global))
# CRITICAL REVIEW: Window.orderBy(F.lit(1)) is NON-DETERMINISTIC — row order varies per run.
# This will produce different results on every execution. You MUST replace F.lit(1) with
# an actual stable sort column (e.g. a timestamp, sequence ID, or composite key) before
# running this in any environment. Leaving F.lit(1) will cause silent data ordering bugs.
```

**Fix — date macro conversion:**
```python
# Iconv(col, "D/MDY") → parse date string to date type
F.to_date(F.col("col"), "MM/dd/yyyy")

# Oconv(col, "D/MDY[2,2,4]") → format date to string
F.date_format(F.col("col"), "MM/dd/yyyy")

# DataStage %yyyy-%mm-%dd format tokens → Spark yyyy-MM-dd
# %yyyy → yyyy,  %mm → MM,  %dd → dd,  %hh → HH,  %nn → mm,  %ss → ss
```

**Fix — multi-output conditional routing:**
```python
# DataStage: one Transformer, two output links with different filter conditions
# Lakebridge often only generates one link — add the second
df_link1 = df.filter(F.col("flag") == "Y")
df_link2 = df.filter(F.col("flag") != "Y")
# REVIEW: filter condition inferred from stage comments — verify split logic
```

**Fix — multi-output with 3+ paths:**
```python
# DataStage Transformer with 3+ output links split by type
df_path_a   = df.filter(F.col("type_col") == "A")
df_path_b   = df.filter(F.col("type_col") == "B")
df_path_c   = df.filter(F.col("type_col") == "C")
df_path_other = df.filter(~F.col("type_col").isin("A", "B", "C"))
# REVIEW: type values and column name inferred — verify against DataStage link filter expressions
```

**Fix — Transformer reject link (error rows):**
```python
# DataStage Transformer with a reject output link for error rows
df_accepted = df.filter(F.col("REJECTRECORD") != "Y")
df_rejected = df.filter(F.col("REJECTRECORD") == "Y")
print(f"[TRANSFORMER] accepted={df_accepted.count()} rejected={df_rejected.count()}")
# REVIEW: reject condition (REJECTRECORD == 'Y') inferred — verify column name and flag value
# REVIEW: write df_rejected to quarantine/error table if downstream reject link exists
```

**Fix — nested IF precedence:**
```python
# BEFORE (wrong precedence from Lakebridge)
F.when(cond_a, val_a).when(cond_b, val_b).otherwise(
    F.when(cond_c, val_c).otherwise(val_d))

# AFTER (flat chain, correct precedence)
F.when(cond_a, val_a) \
 .when(cond_b, val_b) \
 .when(cond_c, val_c) \
 .otherwise(val_d)
```

---

## AGGREGATOR STAGE

**Detection:** `# type AGGREGATOR` or `.groupBy().` pattern.

**Common Lakebridge failures:**
- `F.first()` without `ignorenulls=True` — non-deterministic
- `F.last()` without `ignorenulls=True` — non-deterministic
- Running total (DataStage "Compute running totals") missing entirely
- GROUP BY key columns missing from `.agg()` select
- Single `F.sum()` inside `.groupBy()` call instead of `.agg()`
- Multiple agg functions collapsed into one wrong call

**Fix — standard aggregation:**
```python
df_agg = df.groupBy("key_col1", "key_col2").agg(
    F.sum("amount").alias("total_amount"),
    F.count("*").alias("record_count"),
    F.avg("price").alias("avg_price"),
    F.max("order_date").alias("latest_date"),
    F.min("order_date").alias("earliest_date"),
    F.first("description", ignorenulls=True).alias("first_desc"),
    F.last("description", ignorenulls=True).alias("last_desc"),
    F.countDistinct("customer_id").alias("unique_customers"),
)
```

**Fix — running total (DataStage "Compute running totals"):**
```python
from pyspark.sql.window import Window
_w_running = Window.partitionBy("group_col") \
    .orderBy("sort_col") \
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
df = df.withColumn("running_total", F.sum("amount").over(_w_running))
# REVIEW: partitionBy and orderBy inferred from stage — verify correct columns
```

**Fix — broken groupBy (sum inside groupBy args):**
```python
# BEFORE (Lakebridge error)
df.groupBy("dept", F.sum("salary"))
df.groupBy("dept").agg("SUM(salary)")

# AFTER
df.groupBy("dept").agg(F.sum("salary").alias("total_salary"))
```

---

## PIVOT STAGE

**Detection:** `# type PIVOT` or `PIVOT_COLUMNS_TO_ROWS` / `PIVOT_ROWS_TO_COLUMNS`
comment, or stub `# TODO: PIVOT`.

**Common Lakebridge failures:**
- Static pivot generated for dynamic DataStage pivot (column values at runtime)
- Unpivot (DataStage "Vertical pivot") missing or wrong
- Multiple value columns across pivot not handled
- PySpark version not detected — wrong unpivot syntax used

**Fix — rows to columns (standard pivot):**
```python
df_pivot = df.groupBy("key_col") \
    .pivot("category_col", ["CAT_A", "CAT_B", "CAT_C"]) \
    .agg(F.sum("value_col"))
# REVIEW: pivot values list inferred — specify known values for performance
# If values unknown at code time, omit the list (slower but dynamic):
# .pivot("category_col").agg(F.sum("value_col"))
```

**Fix — columns to rows (unpivot / vertical pivot):**
```python
# PySpark 3.4+ native
df_unpivot = df.unpivot(
    ids=["key_col"],
    values=["col_a", "col_b", "col_c"],
    variableColumnName="category",
    valueColumnName="value"
)

# PySpark < 3.4 (stack expression)
df_unpivot = df.selectExpr(
    "key_col",
    "stack(3, 'col_a', col_a, 'col_b', col_b, 'col_c', col_c) as (category, value)"
)
# REVIEW: column list for unpivot inferred from ErrRecIn/input schema — verify
```

**Fix — PIVOT_COLUMNS_TO_ROWS (PxPivot DataStage type):**

Use when the traceability comment shows `type PIVOT_COLUMNS_TO_ROWS` or the MISSING_HANDLER node
name contains `PxPivot`. DataStage converts a fixed set of named columns into key/value rows.
Build the pivot column list from the COLUMN COUNT in the traceability block and the upstream schema.

```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : PIVOT_COLUMNS_TO_ROWS
_key_cols   = ["key_col"]                        # REVIEW: non-pivoted columns (pass through as-is)
_pivot_cols = ["COL_A", "COL_B", "COL_C"]       # REVIEW: columns to pivot — one output row per column
                                                  # COLUMN COUNT in traceability = total; subtract key cols

df_pivot = df.select(
    *_key_cols,
    F.expr(
        f"stack({len(_pivot_cols)}, "
        + ", ".join(f"'{c}', {c}" for c in _pivot_cols)
        + ") as (COLUMN_NAME, COLUMN_VALUE)"
    )
)
print(f"[PIVOT_COLUMNS_TO_ROWS] count={df_pivot.count()}")
# REVIEW: output column names (COLUMN_NAME, COLUMN_VALUE) — verify against DataStage ErrRecOut link schema
# REVIEW: COLUMN COUNT in traceability block includes key cols — subtract to get pivot column count
```

---

## SCD (SLOWLY CHANGING DIMENSION) STAGE

**Detection:** `# type SCD` or `SCD_TYPE` comment, or Delta MERGE pattern
that is incomplete/missing for dimension tables.

**Common Lakebridge failures:**
- Type 1 (overwrite) generates inefficient loop-based UPDATE
- Type 2 (history) insert/expire logic missing or wrong
- Effective date defaults to `current_timestamp()` instead of business date
- `surrogate_key` generation missing
- `is_current` flag not set/reset correctly

**Fix — Type 1 SCD (overwrite current record):**
```python
from delta.tables import DeltaTable

dim = DeltaTable.forName(spark, TGT_dim)
dim.alias("t").merge(
    df_incoming.alias("s"),
    "t.natural_key = s.natural_key"  # REVIEW: natural key inferred — verify
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()
```

**Fix — Type 2 SCD (full history):**
```python
from delta.tables import DeltaTable

NATURAL_KEYS  = ["customer_id"]       # REVIEW: verify natural key columns
HIGH_DATE     = "9999-12-31"
join_cond     = " AND ".join([f"t.{k} = s.{k}" for k in NATURAL_KEYS])

dim = DeltaTable.forName(spark, TGT_dim)

# Step 1 — expire changed current rows
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenMatchedUpdate(
    condition="s.scd2_hash <> t.scd2_hash",
    set={
        "effective_end_date": F.current_date(),
        "is_current":         F.lit(False)
    }
).execute()

# Step 2 — insert new versions
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenNotMatchedInsert(values={
    "surrogate_key":      F.monotonically_increasing_id(),
    **{c: f"s.{c}" for c in df_incoming.columns},
    "effective_start_date": F.current_date(),
    "effective_end_date":   F.lit(HIGH_DATE),
    "is_current":           F.lit(True)
}).execute()
# REVIEW: scd2_hash must be pre-computed on SCD2 columns before merge
# REVIEW: column names (is_current, effective_start_date etc.) — verify schema
```

---

## LOOKUP STAGE

**Detection:** `# type LOOKUP` comment or `.join()` with broadcast pattern,
or unconnected lookup flat file reference.

**Common Lakebridge failures:**
- Sparse lookup (failure action = "continue with null") not handled — uses inner join, drops non-matching rows
- Unconnected lookup (flat file reference) generates broken file read
- Multiple lookup conditions partially mapped
- Broadcast hint missing on small reference tables
- Reject link (unmatched rows) not split out

**Fix — sparse lookup (left join):**
```python
# DataStage "Continue with null" → left join
df_result = df_main.join(
    F.broadcast(df_lookup),   # broadcast if lookup is small
    on=["join_key_col"],
    how="left"                # "inner" only for "Fail on no match"
)
# REVIEW: join type — use "inner" if DataStage was set to "Fail on no match"
```

**Fix — drop unmatched rows (DataStage "Drop" failure action):**
```python
# DataStage "Drop" action → inner join (only keep matched rows)
df_result = df_main.join(
    F.broadcast(df_lookup),
    on=["join_key_col"],
    how="inner"
)
# REVIEW: inner join drops non-matching rows — confirm DataStage lookup failure action was "Drop"
```

**Fix — reject link (unmatched rows):**
```python
df_matched   = df_result.filter(F.col("lookup_col").isNotNull())
df_unmatched = df_result.filter(F.col("lookup_col").isNull())
# REVIEW: lookup_col is the first column from the lookup table — verify correct sentinel column
```

**Fix — range lookup (lookup between bounds):**
```python
# DataStage range lookup — find reference row where value falls between lower/upper bounds
df_result = df_main.join(
    df_lookup.alias("ref"),
    (F.col("amount") >= F.col("ref.lower_bound")) &
    (F.col("amount") <= F.col("ref.upper_bound")),
    how="left"
)
# REVIEW: range columns (lower_bound, upper_bound) and value column (amount) — verify against DataStage config
# REVIEW: if multiple ranges can overlap, add .dropDuplicates([key_col]) or add tie-breaker
```

**Fix — unconnected lookup (flat file):**
```python
# Replace with Unity Catalog volume or already-ingested Delta table
df_lookup_ref = spark.read.format("delta").table(SRC_reference)
# REVIEW: original flat file path — verify Delta table exists at SRC_reference
```

**Fix — multi-condition lookup:**
```python
df_result = df_main.join(
    F.broadcast(df_lookup),
    (df_main["col_a"] == df_lookup["ref_col_a"]) &
    (df_main["col_b"] == df_lookup["ref_col_b"]),
    how="left"
)
```

---

## JOIN STAGE

**Detection:** `# type JOIN` comment or `.join()` calls with 3+ inputs,
or join key type mismatch, or duplicate columns after join.

**Common Lakebridge failures:**
- 3+ input joins converted as sequential joins losing correct join order
- DataStage "Full Outer" join missing — defaults to inner
- Join key type mismatch (string vs int) not cast before join
- Duplicate column names after join cause ambiguous reference errors
- Missing broadcast hint on small dimension tables

**Fix — multi-input join (3 sources):**
```python
# Join A + B first
df_ab = df_a.join(df_b, on="key_col", how="inner")
df_ab = df_ab.drop(df_b["key_col"])  # drop duplicate key

# Then join with C
df_final = df_ab.join(df_c, on="key_col", how="left")
# REVIEW: join order inferred from DataStage link order — verify correct sequence
```

**Fix — full outer join with coalesced key:**
```python
df_full = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="full")
df_full = df_full.withColumn(
    "key_col",
    F.coalesce(F.col("a.key_col"), F.col("b.key_col"))
)
```

**Fix — cast before join to prevent type mismatch:**
```python
df_a = df_a.withColumn("key_col", F.col("key_col").cast("string"))
df_b = df_b.withColumn("key_col", F.col("key_col").cast("string"))
df_joined = df_a.join(df_b, on="key_col", how="inner")
# REVIEW: cast to string assumed — verify correct target type for this key
```

**Fix — duplicate column dedup after join:**
```python
# After join, if both sides have same non-key column name
df_joined = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="inner")
# Reference with alias to avoid ambiguity
df_joined = df_joined.select(
    F.col("a.amount").alias("src_amount"),
    F.col("b.amount").alias("ref_amount"),
    "key_col"
)
```

---

## SORT STAGE

**Detection:** `# type SORT` comment or `.orderBy()` / `.sort()` calls.

**Common Lakebridge failures:**
- DataStage APT partition-aware sort emitted as global `orderBy()` — wrong semantics
- `NullFirst` / `NullLast` sort options not carried through — defaults to nulls last
- Sort immediately before Aggregator generates unnecessary extra shuffle
- Sort column direction (ASC/DESC) not preserved

**Fix — null-aware sort:**
```python
df_sorted = df.orderBy(
    F.col("sort_col1").asc_nulls_last(),
    F.col("sort_col2").desc_nulls_first()
)
# REVIEW: null handling (nulls_last / nulls_first) inferred — verify matches DS sort spec
```

**Fix — partition-aware sort (DataStage APT_SORT_PARTITIONED):**
```python
# DataStage sorted within each partition — use Window rather than global orderBy
from pyspark.sql.window import Window
_w = Window.partitionBy("partition_col").orderBy(F.col("sort_col").asc())
df = df.withColumn("row_rank", F.rank().over(_w))
# REVIEW: partition column inferred — verify correct partition key
```

**Fix — unnecessary sort before groupBy:**
```python
# BAD (Lakebridge often generates this — sorts then re-shuffles)
df.orderBy("key_col").groupBy("key_col").agg(F.sum("amount"))

# GOOD — groupBy already handles the shuffle, drop the orderBy
df.groupBy("key_col").agg(F.sum("amount").alias("total"))
```

---

## CHANGE_CAPTURE / CDC STAGE

**Detection:** `# type CHANGE_CAPTURE` or `# type CDC` traceability comment, or
`MISSING_HANDLER` stub with CDC node name, or incomplete if/elif chain comparing
old/new column values without a Delta MERGE.

**Common Lakebridge failures:**
- Stage emitted as MISSING_HANDLER stub entirely — no code generated
- Generated as broken if/elif comparing individual columns instead of Delta MERGE
- Delete handling missing — only inserts and updates generated
- Reject/error link (unmatched rows) not split out
- `whenNotMatchedBySourceDelete()` missing when full CDC sync is needed
- Staging-join select pulls all columns from `src` only — DELETE rows lose non-key data because `src` is null for deletes; must fall back to `tgt` for non-key columns when `change_code == 2`

**Fix — standard CDC using Delta MERGE:**
```python
# COMMAND ----------
# Source file     : {filename}
# Processing node : {link_name}
# Node type       : CHANGE_CAPTURE
from delta.tables import DeltaTable

target_dt = DeltaTable.forName(spark, target_table)
target_dt.alias("t").merge(
    df_new.alias("s"),
    "t.natural_key_col = s.natural_key_col"  # REVIEW: verify natural key column(s)
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .whenNotMatchedBySourceDelete() \
 .execute()
print(f"CDC merge complete on {target_table}")
# REVIEW: natural key column inferred from traceability — verify correct join condition
# REVIEW: whenNotMatchedBySourceDelete() requires Delta 2.0+ / DBR 11.0+ — verify runtime
# REVIEW: DataStage CDC may distinguish INSERT/UPDATE/DELETE via a change-type column —
#         if present, add whenMatchedUpdate(condition="s.chg_type = 'U'") variant
```

**Fix — CDC with explicit change-type column:**
```python
# When source contains a change_type column (I=Insert, U=Update, D=Delete)
target_dt.alias("t").merge(
    df_new.alias("s"),
    "t.natural_key_col = s.natural_key_col"
).whenMatchedUpdate(
    condition="s.change_type = 'U'",
    set={"*": "s.*"}
).whenMatchedDelete(
    condition="s.change_type = 'D'"
).whenNotMatchedInsert(
    condition="s.change_type = 'I'",
    values={"*": "s.*"}
).execute()
# REVIEW: change_type column name and values (I/U/D vs INSERT/UPDATE/DELETE) —
#         check original DataStage CDC stage configuration
```

**Fix — CDC reject link:**
```python
# Split unmatched / error records if CDC has a reject output link
df_rejected = df_new.filter(F.col("change_type").isNull() | ~F.col("change_type").isin("I", "U", "D"))
# REVIEW: reject condition inferred — verify sentinel value for unrecognised change types
```

**Fix — staging-join select (src/tgt full outer join with change_code):**

This pattern applies when the notebook full-outer-joins an incoming source (`src`) against the
current target snapshot (`tgt`) and assigns a numeric `change_code` (1=INSERT, 2=DELETE, 3=UPDATE).
After the join, the select that builds the final record **must** pull non-key columns from `tgt`
for DELETE rows because `src` is null on the source side for deletes.

```python
# WRONG — loses non-key data for DELETE rows (change_code == 2)
df_result = df_joined.select(
    F.col(f"src.{_key}").alias(_key),
    *[F.col(f"src.{c}").alias(c) for c in _non_key_cols],
    "change_code"
)

# CORRECT — key from whichever side is non-null; non-key from tgt on deletes
df_result = df_joined.select(
    F.coalesce(F.col(f"src.{_key}"), F.col(f"tgt.{_key}")).alias(_key),
    *[
        F.when(F.col("change_code") == 2, F.col(f"tgt.{c}"))
         .otherwise(F.col(f"src.{c}")).alias(c)
        for c in _non_key_cols
    ],
    "change_code"
)
# REVIEW: change_code values (1=INSERT, 2=DELETE, 3=UPDATE) — verify against DataStage
#         CDC stage output; adjust the == 2 condition if DELETE uses a different sentinel
# REVIEW: if there are multiple key columns, apply coalesce individually for each key column
```

**Why this matters:** On a DELETE, DataStage CDC only carries key columns in the source stream.
The full-outer join leaves `src.*` as null for every non-key column. Taking `src.col` for all
rows silently propagates nulls into the output and corrupts audit/history tables downstream.

---

## FUNNEL / UNION STAGE

**Detection:** `# type FUNNEL` traceability comment, or multiple DataFrames
being concatenated, or `unionAll(` / `union(` calls.

**Common Lakebridge failures:**
- `union()` used instead of `unionByName()` — column-order sensitive, breaks if schemas differ
- Schema mismatch across inputs not handled — raises AnalysisException
- DataStage FUNNEL with "Sort" option emits extra `orderBy()` after union — unnecessary shuffle
- More than 2 inputs chained with repeated `.union()` calls — correct but verbose

**Fix — standard FUNNEL (2 inputs):**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : FUNNEL
df_result = df_a.unionByName(df_b, allowMissingColumns=True)
print(f"[FUNNEL] count={df_result.count()}")
# REVIEW: allowMissingColumns=True fills missing columns with null —
#         verify all inputs have compatible column types for shared columns
```

**Fix — FUNNEL with 3+ inputs:**
```python
from functools import reduce
from pyspark.sql import DataFrame

dfs = [df_a, df_b, df_c]  # REVIEW: list all input DataFrames in DataStage link order
df_result = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), dfs)
print(f"[FUNNEL] count={df_result.count()}")
```

**Fix — remove sort after FUNNEL (unnecessary):**
```python
# If Lakebridge emits .orderBy() immediately after union — drop it
# DataStage FUNNEL sort is a partition sort, not a global sort
# REVIEW: if downstream stage explicitly requires sorted input, keep orderBy with correct key
```

---

## REMOVE_DUPLICATES / DEDUP STAGE

**Detection:** `# type REMOVE_DUPLICATES` or `# type DEDUP` traceability comment,
or `.dropDuplicates(` / `.distinct()` calls that are missing or incorrect.

**Common Lakebridge failures:**
- Key columns list empty — generates `df.distinct()` which deduplicates on ALL columns
- DataStage "Keep first" / "Keep last" selection not preserved — Spark has no built-in keep-last
- Duplicate detection across sorted groups not handled correctly
- Reject link (duplicate rows) not split out

**Fix — key-based deduplication (keep first occurrence):**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : REMOVE_DUPLICATES
df_dedup = df.dropDuplicates(["key_col1", "key_col2"])
print(f"[DEDUP] before={df.count()} after={df_dedup.count()}")
# REVIEW: key columns inferred from traceability — verify correct dedup key
```

**Fix — keep last occurrence (DataStage "Keep last"):**
```python
from pyspark.sql.window import Window
_w = Window.partitionBy("key_col1", "key_col2").orderBy(F.col("sort_col").desc())
df_ranked = df.withColumn("_rn", F.row_number().over(_w))
df_dedup   = df_ranked.filter(F.col("_rn") == 1).drop("_rn")
# REVIEW: sort_col for "keep last" inferred — verify which column determines recency
```

**Fix — split duplicate rows to reject link:**
```python
df_keys    = df.groupBy("key_col1", "key_col2").agg(F.count("*").alias("_cnt"))
df_dups    = df_keys.filter(F.col("_cnt") > 1)
df_dedup   = df.join(df_dups, on=["key_col1", "key_col2"], how="left_anti")
df_rejected = df.join(df_dups, on=["key_col1", "key_col2"], how="inner")
# REVIEW: verify key columns match REMOVE_DUPLICATES stage configuration
```

---

## FILTER STAGE

**Detection:** `# type FILTER` traceability comment, or cell with `.filter()` that maps directly
from a DataStage FILTER/SELECTION stage with a reject output link.

**Common Lakebridge failures:**
- Only one output link generated — reject link (non-matching rows) missing
- Filter condition left as DataStage BASIC syntax instead of PySpark
- Multiple filter conditions with `And`/`Or` not correctly parenthesized

**Fix — standard FILTER with pass/reject split:**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : FILTER

df_pass   = df.filter(condition)      # REVIEW: condition inferred — verify filter expression
df_reject = df.filter(~(condition))   # non-matching rows to reject output
print(f"[FILTER] pass={df_pass.count()} reject={df_reject.count()}")
# REVIEW: if no downstream reject link exists, df_reject can be dropped
# REVIEW: condition may use DataStage syntax — apply Group G fixes before running
```

---

## MODIFY / COPY STAGE

**Detection:** `# type MODIFY` or `# type COPY` traceability comment, or a cell that only
renames, reorders, or type-casts columns with no business logic. Also triggers when a
`MISSING_HANDLER` stub has node type MODIFY.

DataStage MODIFY stages rename columns, reorder them, change types, or drop columns.
COPY stages pass data through with optional column selection.

**Common Lakebridge failures:**
- Generated as MISSING_HANDLER stub entirely
- Column renames missing — downstream references break
- Type casts left as DataStage syntax

**Fix — MODIFY (rename + reorder + cast):**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : MODIFY
df_out = df.select(
    F.col("OLD_COL_NAME").alias("NEW_COL_NAME"),  # REVIEW: rename pairs inferred from traceability
    F.col("AMOUNT_STR").cast("decimal(18,2)").alias("AMOUNT"),
    "OTHER_COL"
)
# REVIEW: column list, rename pairs, and casts inferred from MODIFY stage config — verify all
```

**Fix — COPY (passthrough / column selection):**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : COPY
df_out = df.select("COL_A", "COL_B", "COL_C")
# REVIEW: column list inferred from COPY stage output link schema — verify all required columns present
```

---

## SURROGATE KEY GENERATOR STAGE (PxSurrogateKeyGenerator)

**Detection:** `# type SURROGATE_KEY` or `# Original node name PxSurrogateKeyGenerator`.
DIFFERENT from `seq_` SOURCE node — see SOURCE STAGE section for that pattern.

PxSurrogateKeyGenerator reads the current max key from a reference/lookup table and generates
new sequential keys starting from `max + 1`. Lakebridge almost always emits a MISSING_HANDLER
for this stage.

**Common Lakebridge failures:**
- Emitted as MISSING_HANDLER entirely — no code generated
- Confused with seq_ SOURCE node (which uses a widget start value, not a lookup table)

**Fix:**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : SURROGATE_KEY
from pyspark.sql.window import Window

# Step 1 — find current max surrogate key from reference table
_max_key_row = spark.read.format("delta").table(surrogate_key_ref_table) \
    .agg(F.max("surrogate_key_col")).collect()
_max_key = _max_key_row[0][0] if _max_key_row[0][0] is not None else 0
# REVIEW: surrogate_key_ref_table and surrogate_key_col — verify table name and key column

# Step 2 — assign new sequential keys
_w = Window.orderBy(F.col("natural_key_col"))   # REVIEW: order column must be deterministic
df = df.withColumn(
    "surrogate_key",
    F.row_number().over(_w) + F.lit(_max_key)
)
# REVIEW: natural_key_col for deterministic ordering — verify correct sort column
# REVIEW: _max_key type — cast to int if row_number arithmetic causes type mismatch
```

---

## TARGET STAGE

**Detection:** `# type TARGET` traceability comment, or `.merge()` called directly on a raw
DataFrame variable (not a `DeltaTable` object), or `.merge()` with an empty alias `alias('')`
and/or a malformed condition string (e.g. `'.KEY_COL = '` — leading dot, no right-hand side).

**Common Lakebridge failures:**
- `TABLE_VAR.alias('').merge(src, '.KEY_COL = ')` — missing `DeltaTable.forName()`, empty alias, broken condition
- `whenMatchedUpdate(set={})` with empty set dict — updates nothing
- Target table name not wired to widget variable

**Fix — broken Lakebridge TARGET merge:**
```python
# WRONG — Lakebridge emits this
SPA002_TABLE.alias('').merge(lnkUpdate.alias('lnkUpdate'), '.SERIAL_KEY = ') \
    .whenMatchedUpdate(set={}) \
    .execute()

# CORRECT
from delta.tables import DeltaTable

_tgt = DeltaTable.forName(spark, target_table)
_tgt.alias("tgt").merge(
    lnkUpdate.alias("src"),
    "tgt.SERIAL_KEY = src.SERIAL_KEY"  # REVIEW: key column extracted from broken condition
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()
print(f"[TARGET] merge complete on {target_table}")
# REVIEW: key column extracted from broken condition string — strip leading `.` and trailing ` = `
# REVIEW: whenMatchedUpdateAll + whenNotMatchedInsertAll assumed — verify original DS TARGET type
#         (update-only targets → remove whenNotMatchedInsertAll)
```

**Key extraction from broken condition:** The malformed string `'.KEY_COL = '` encodes the key
column — strip the leading `.` and trailing ` = ` to get `KEY_COL`. Use that name for both sides
of the merge condition.

**Fix — INSERT-only target (append mode):**
```python
# When DataStage TARGET stage was configured for INSERT only (no update, no delete)
df_source.write.format("delta").mode("append").saveAsTable(target_table)
print(f"[TARGET] appended to {target_table}")
# REVIEW: mode("append") never updates existing rows — confirm DataStage target had no UPDATE action
```

**Fix — UPDATE-only target (no new rows inserted):**
```python
from delta.tables import DeltaTable

_tgt = DeltaTable.forName(spark, target_table)
_tgt.alias("tgt").merge(
    df_source.alias("src"),
    "tgt.KEY_COL = src.KEY_COL"  # REVIEW: key column — verify
).whenMatchedUpdateAll() \
 .execute()
# No whenNotMatchedInsert — update only, new rows are silently ignored
print(f"[TARGET] update-only merge on {target_table}")
# REVIEW: confirm DataStage target had UPDATE only (no INSERT action)
```

**Fix — TRUNCATE + RELOAD (full replacement):**
```python
# DataStage target configured to delete all rows then reload
df_source.write.format("delta").mode("overwrite").saveAsTable(target_table)
print(f"[TARGET] overwrite complete on {target_table}")
# REVIEW: mode("overwrite") DELETES ALL existing rows then reloads — confirm this matches original DS behavior
# REVIEW: for partitioned tables, consider mode("overwrite") with partitionOverwriteMode=dynamic
#         to replace only affected partitions rather than the entire table
```

**Write mode decision table:**

| DataStage target action | PySpark write mode |
|---|---|
| INSERT only | `.mode("append")` |
| UPDATE + INSERT (merge) | `DeltaTable.merge()` — see broken merge fix above |
| UPDATE only | `DeltaTable.merge()` with `whenMatchedUpdateAll()` only |
| Delete all + reload | `.mode("overwrite")` |

---

## SOURCE STAGE — Surrogate Key / ROW_NUMBER

**Detection:** `# Processing node ... type SOURCE` combined with `# Original node name seq_...`
(DataStage sequence stage), AND a `withColumn` that references `F.col('ROW_NUMBER')` or
`F.col("ROW_NUMBER")` before `ROW_NUMBER` has been defined as a column in that DataFrame.

Lakebridge generates the surrogate key assignment (`svSURGTKEY = STRT_SURGT_NO + ROW_NUMBER`)
but never generates the `ROW_NUMBER` window function that produces the sequential offset.

**Fix — insert ROW_NUMBER window function before the withColumn that uses it:**
```python
from pyspark.sql.window import Window
# REVIEW: surrogate key ordering — replace F.lit(1) with actual sort column(s) to match
#         DataStage seq stage deterministic ordering
_w = Window.orderBy(F.lit(1))  # REPLACE with actual sort column(s)
{df_var} = {df_var}.withColumn("ROW_NUMBER", F.row_number().over(_w))

# Existing surrogate key assignment (already in notebook — do NOT duplicate):
# {df_var} = {df_var}.withColumn("svSURGTKEY", F.lit(STRT_SURGT_NO) + F.col("ROW_NUMBER"))
# REVIEW: STRT_SURGT_NO widget default = surrogate key start value — verify correct start
```

Insert the `ROW_NUMBER` block **immediately before** the `withColumn` that uses `F.col('ROW_NUMBER')`.
Do not move or duplicate the surrogate key withColumn — only prepend the window function.

---

## MISSING_HANDLER STUBS

**Detection:** Any of these patterns anywhere in a notebook cell:
- `MISSING_HANDLER = "..."` variable assignment
- `# TODO: MISSING_HANDLER` comment
- `pass  # MISSING_HANDLER` stub
- Cell body consisting only of `pass` with a MISSING_HANDLER traceability comment above

**Fix procedure — always REVIEW confidence:**

1. Read the `# Node type` value in the traceability block of the same cell.
2. Match the node type to a section in this file and apply that fix pattern.
3. If no traceability block is present, check the surrounding cells for context clues
   (DataFrame names, column names, join keys) to infer the stage type.

| Node type found | Apply section |
|---|---|
| `PIVOT` / `PIVOT_COLUMNS_TO_ROWS` / `PxPivot` | PIVOT STAGE section — use PIVOT_COLUMNS_TO_ROWS fix for columns-to-rows |
| `SCD` | SCD section |
| `CHANGE_CAPTURE` / `CDC` | CHANGE_CAPTURE / CDC STAGE section |
| `FUNNEL` | FUNNEL / UNION STAGE section |
| `REMOVE_DUPLICATES` / `DEDUP` | REMOVE_DUPLICATES / DEDUP STAGE section |
| `AGGREGATOR` | AGGREGATOR STAGE section |
| `JOIN` | JOIN STAGE section |
| `LOOKUP` | LOOKUP STAGE section |
| `SORT` | SORT STAGE section |
| `TRANSFORMER` | TRANSFORMER STAGE section |
| `TARGET` | TARGET STAGE section |
| `SOURCE` with `seq_` node name | SOURCE STAGE — Surrogate Key / ROW_NUMBER section |
| `SURROGATE_KEY` / `PxSurrogateKeyGenerator` | SURROGATE KEY GENERATOR STAGE section |
| `FILTER` / `SELECTION` | FILTER STAGE section |
| `MODIFY` | MODIFY / COPY STAGE section |
| `COPY` | MODIFY / COPY STAGE section |
| Not determinable | Keep stub, add: `# REVIEW: MISSING_HANDLER — stage type unknown, manual conversion required` |

**Output format for every resolved MISSING_HANDLER:**
```python
# COMMAND ----------
# Source file     : {filename}
# Processing node : {link_name}
# Node type       : {resolved_stage_type}
# Original DS name: {ds_name}
# Input link(s)   : {links}  |  Output link(s): {links}  |  Reject link(s): {links}
{converted PySpark code}
# REVIEW: MISSING_HANDLER resolved as {stage_type} — verify conversion matches original DataStage logic
```
