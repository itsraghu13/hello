# Expression Map — DataStage BASIC → PySpark
# Read when notebook contains unrecognised DataStage function names,
# @ variables, or Oconv/Iconv date format strings.

---

## STRING FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Trim(col)` | `F.trim(F.col("col"))` | both sides |
| `LTrim(col)` | `F.ltrim(F.col("col"))` | leading only |
| `RTrim(col)` | `F.rtrim(F.col("col"))` | trailing only |
| `Strip(col,"leading")` | `F.ltrim(F.col("col"))` | |
| `Strip(col,"trailing")` | `F.rtrim(F.col("col"))` | |
| `Len(col)` | `F.length(F.col("col"))` | |
| `Length(col)` | `F.length(F.col("col"))` | alias of Len |
| `Space(n)` | `F.rpad(F.lit(""), n, " ")` | n spaces |
| `Str(col, n)` | `F.lpad(F.col("col"), n, " ")` | left-pad to width |
| `Upcase(col)` | `F.upper(F.col("col"))` | |
| `Downcase(col)` | `F.lower(F.col("col"))` | |
| `Left(col, n)` | `F.col("col").substr(1, n)` | |
| `Right(col, n)` | `F.expr(f"right(col, {n})")` | |
| `Mid(col, s, n)` | `F.col("col").substr(s, n)` | s is 1-based |
| `Field(col, delim, n)` | `F.split(F.col("col"), delim)[n-1]` | n is 1-based in DS |
| `Index(col, str, n)` | `F.locate(str, F.col("col"), n)` | n = occurrence |
| `Convert(col, from, to)` | `F.regexp_replace(F.col("col"), from, to)` | |
| `LJustify(col, n)` | `F.rpad(F.col("col"), n, " ")` | |
| `RJustify(col, n)` | `F.lpad(F.col("col"), n, " ")` | |
| `Squote(col)` | `F.concat(F.lit("'"), F.col("col"), F.lit("'"))` | |
| `Dquote(col)` | `F.concat(F.lit('"'), F.col("col"), F.lit('"'))` | |
| `col1 : col2` | `F.concat(F.col("col1"), F.col("col2"))` | DS concat op |
| `col1 \|\| col2` | `F.concat(F.col("col1"), F.col("col2"))` | |
| `Char(n)` | `F.chr(F.lit(n))` | numeric code → character |
| `Ereplace(col, old, new, n)` | `F.regexp_replace(F.col("col"), old, new)` | n=occurrence (REVIEW: regex_replace replaces ALL — use REVIEW if n is specified) |
| `Change(col, old, new)` | `F.regexp_replace(F.col("col"), old, new)` | replace all occurrences |

---

## NUMERIC FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Abs(col)` | `F.abs(F.col("col"))` | |
| `Int(col)` | `F.col("col").cast("long")` | truncate toward zero — cast is correct; F.floor() gives wrong result for negatives |
| `Round(col, n)` | `F.round(F.col("col"), n)` | |
| `Mod(a, b)` | `F.col("a") % F.col("b")` | |
| `Sqrt(col)` | `F.sqrt(F.col("col"))` | |
| `Num(col)` | `F.col("col").cast("double")` | string → number |
| `IntToString(col)` | `F.col("col").cast("string")` | |
| `StringToInteger(col)` | `F.col("col").cast("integer")` | |
| `StringToDecimal(col)` | `F.col("col").cast("double")` | |
| `DecimalToString(col)` | `F.col("col").cast("string")` | |
| `Fmt(col, "picture")` | `F.format_string(picture, F.col("col"))` | REVIEW: DataStage picture format (e.g. "R#9.99") differs from printf-style — verify format string |

---

## DATE & TIMESTAMP FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Iconv(col, "D/MDY")` | `F.to_date(F.col("col"), "MM/dd/yyyy")` | parse string → date |
| `Iconv(col, "D/YMD")` | `F.to_date(F.col("col"), "yyyy-MM-dd")` | |
| `Oconv(col, "D/MDY[2,2,4]")` | `F.date_format(F.col("col"), "MM/dd/yyyy")` | format date → string |
| `Oconv(col, "D/YMD[4,2,2]")` | `F.date_format(F.col("col"), "yyyy-MM-dd")` | |
| `DateToString(col, fmt)` | `F.date_format(F.col("col"), fmt)` | |
| `StringToDate(col, fmt)` | `F.to_date(F.col("col"), fmt)` | |
| `StringToTimestamp(col, fmt)` | `F.to_timestamp(F.col("col"), fmt)` | |
| `TimeStampToDate(col)` | `F.to_date(F.col("col"))` | |
| `SecondsToTime(col)` | `F.from_unixtime(F.col("col"))` | |
| `Age(col)` | `F.datediff(F.current_date(), F.col("col"))` | days since date |
| `DaysSince(col)` | `F.datediff(F.current_date(), F.col("col"))` | alias |
| `Today()` | `F.current_date()` | |
| `Now()` | `F.current_timestamp()` | |
| `CurrentTimestamp()` | `F.current_timestamp()` | capital-C DS variant |

**DataStage date format token → Spark format token:**

| DataStage | Spark | Meaning |
|---|---|---|
| `%yyyy` | `yyyy` | 4-digit year |
| `%yy` | `yy` | 2-digit year |
| `%mm` | `MM` | month (01–12) |
| `%dd` | `dd` | day (01–31) |
| `%hh` | `HH` | hour 24h (00–23) |
| `%nn` | `mm` | minutes (00–59) |
| `%ss` | `ss` | seconds (00–59) |

---

## NULL & CONDITIONAL FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `IsNull(col)` | `F.col("col").isNull()` | |
| `IsNotNull(col)` | `F.col("col").isNotNull()` | |
| `NVL(col, val)` | `F.coalesce(F.col("col"), F.lit(val))` | |
| `NullToEmpty(col)` | `F.coalesce(F.col("col"), F.lit(""))` | |
| `NullToZero(col)` | `F.coalesce(F.col("col"), F.lit(0))` | |
| `IF(c, t, f)` | `F.when(c, t).otherwise(f)` | Python context |
| `IF(c, t, f)` | `CASE WHEN c THEN t ELSE f END` | SQL context |
| `Not(expr)` | `~(expr)` | logical NOT |
| `@NULL` | `F.lit(None)` | null literal |
| `@TRUE` | `F.lit(True)` | |
| `@FALSE` | `F.lit(False)` | |

---

## NULL PROPAGATION DIFFERENCES

DataStage and Spark handle nulls similarly in most cases, but these differences cause silent data
quality issues when not accounted for:

| Scenario | DataStage behavior | Spark behavior | Action |
|---|---|---|---|
| `NVL(col, val)` | Returns val if col is null OR empty string | Returns val only if col is null | If DataStage used NVL as null+empty guard, replace with `F.when(F.col("col").isNull() \| (F.col("col") == ""), F.lit(val)).otherwise(F.col("col"))` |
| `Trim(null)` | Returns null | Returns null | Same — no change needed |
| Arithmetic with null | null propagates | null propagates | Same — no change needed |
| String concat with null | null propagates → result is null | null propagates | Same — no change needed |
| `Length(null)` | Returns 0 in some DS versions | Returns null in Spark | Add `F.coalesce(F.length(F.col("col")), F.lit(0))` if 0 was expected |

---

## ROW & PARTITION VARIABLES

| DataStage Variable | PySpark | Notes |
|---|---|---|
| `@INROWNUM` | `F.row_number().over(Window.partitionBy(...).orderBy(F.lit(1)))` | row number within partition |
| `@NUMROWS` | `F.count("*").over(Window.partitionBy(...))` | total rows in partition |
| `@OUTROWNUM` | `F.row_number().over(Window.orderBy(F.lit(1)))` | global row number |
| `@FILENAME` | `F.input_file_name()` | name of source file being read — only valid when reading from files, not Delta tables |
| `@PARTITIONNUM` | `F.spark_partition_id()` | Spark partition ID (0-based, not same as DataStage partition) |
| `@NUMPARTITIONS` | `F.lit(df.rdd.getNumPartitions())` | REVIEW: computed at planning time — not a column expression |

For Window-based `@` row variables (`@INROWNUM`, `@NUMROWS`, `@OUTROWNUM`) — always add:
```python
# REVIEW: Window partition/order columns inferred — verify correct keys
```

For file-based `@FILENAME` — always add:
```python
# REVIEW: @FILENAME only works when reading raw files (CSV/Parquet paths), not Delta tables
# If source is a Delta table, @FILENAME will return the internal Delta file path — verify intent
```

For partition variables (`@PARTITIONNUM`, `@NUMPARTITIONS`) — always add:
```python
# REVIEW: Spark partition IDs differ from DataStage APT partition numbers — verify logic is partition-agnostic
```

---

## OPERATORS

| DataStage | PySpark (Python context) | PySpark (SQL context) |
|---|---|---|
| `<>` | `!=` | keep as `<>` — valid ANSI SQL |
| `And` | `&` with parentheses | `AND` |
| `Or` | `\|` with parentheses | `OR` |
| `:` (concat) | `F.concat(...)` | `concat(...)` |
| `\|\|` (concat) | `F.concat(...)` | `concat(...)` or `\|\|` |
| `x In (a, b, c)` | `F.col("x").isin(a, b, c)` | membership test |
| `x Not In (a, b, c)` | `~F.col("x").isin(a, b, c)` | exclusion test |
| `Match(col, pattern)` | `F.col("col").rlike(pattern)` | REVIEW: DataStage Match uses its own pattern syntax — convert to regex |
| `MatchesPattern(col, p)` | `F.col("col").rlike(p)` | REVIEW: same as Match — verify pattern syntax conversion |

---

## DETECTION PATTERNS

Scan for these strings to know when to apply this map:

**Capitalised function names** (NameError at runtime):
`Trim(`, `LTrim(`, `RTrim(`, `Strip(`, `Upcase(`, `Downcase(`, `Left(`,
`Right(`, `Mid(`, `Field(`, `Index(`, `Convert(`, `LJustify(`, `RJustify(`,
`Space(`, `Str(`, `Len(`, `Length(`, `Squote(`, `Dquote(`,
`Abs(`, `Int(`, `Round(`, `Mod(`, `Sqrt(`, `Num(`,
`StringToInteger(`, `StringToDecimal(`, `IntToString(`, `DecimalToString(`,
`Iconv(`, `Oconv(`, `Age(`, `DaysSince(`, `Today(`, `Now(`,
`TimeStampToDate(`, `SecondsToTime(`, `CurrentTimestamp(`,
`IsNull(`, `IsNotNull(`, `NVL(`, `NullToEmpty(`, `NullToZero(`, `Not(`,
`Char(`, `Ereplace(`, `Change(`, `Fmt(`, `In `, `Match(`, `MatchesPattern(`

**@ variables** (SyntaxError or NameError):
`@INROWNUM`, `@NUMROWS`, `@OUTROWNUM`, `@NULL`, `@TRUE`, `@FALSE`,
`@FILENAME`, `@PARTITIONNUM`, `@NUMPARTITIONS`

**Date format tokens** (wrong output):
`%yyyy`, `%mm`, `%dd`, `%hh`, `%nn`, `%ss`, `D/MDY`, `D/YMD`

**Concat operators in Python context** (SyntaxError):
`col1 : col2`, `col1 || col2` (when outside a spark.sql string)
