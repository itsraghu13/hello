---
name: databricks-pipeline-advisor
description: >
  Analyzes a folder of Databricks PySpark notebooks to build a dependency
  map, suggest consolidation, and optionally merge approved notebooks into
  one standardized combined notebook. Trigger on: "analyze these notebooks",
  "can we merge these", "consolidate this pipeline", "what order do these
  run in", "are there duplicates", "reduce number of notebooks", or when
  a user pastes multiple .py files or a folder listing. Analysis phase is
  always read-only. Merge only runs after explicit approval.
---

# Databricks Pipeline Advisor

Analyze a collection of Databricks notebooks. Show dependency map and
consolidation recommendations. Merge and standardize only after approval.

**Hard rules:**
- Analysis (Steps 1–3) is always read-only — no code generated
- Merge (Steps 4–5) only runs after `merge` command from user
- Never change business logic during merge — structure only
- One combined notebook output for the whole folder

---

## Step 0 — Detect and analyze script (if present)

Before indexing notebooks, check if input contains a shell script
(.ksh / .sh / .bash / starts with #!/bin/ksh or #!/bin/bash).

If script detected:
1. Read `references/script-analysis-rules.md`
2. Classify script type (ORCHESTRATION / PRE-PROCESSING / POST-PROCESSING / MIXED)
3. Extract script profile (source_table, target_table, ds_job_name, data_logic)
4. Map script to notebooks using job ID + content matching
5. Store script profile — use it to enrich notebook profiles in Step 2

If no script detected: skip this step entirely, proceed to Step 1.

## Step 1 — Detect input

Accept any of: filenames only, full notebook content, mixed, or a path.
For paths: ask user to paste content — cannot fetch from DBFS directly.
For filenames only: partial analysis (no source/target detection).

Read `references/analysis-rules.md` for extraction rules and merge signals.

## Step 2 — Index (silent, per notebook)

For each notebook extract:
- `file_name`, `seq_no`, `domain` — from filename pattern
- `sources`, `targets` — from SRC/TGT widgets → spark.read/saveAsTable → traceability comments → filename
- `stage_types` — from `# Node type` traceability comments
- `cell_count`, `converted_on` — from header

If script profile exists from Step 0:
- Override source_table defaultValue with script profile source_table
- Override target_table defaultValue with script profile target_table
- Add ds_job_name to notebook purpose
- Add data_logic items to notebook profile for injection during fix

## Step 2.5 — Table Validation Script

After Step 2 indexing is complete, collect every unique source and target table from all
notebook profiles (deduplicate). Generate and **execute** the following validation cell
directly via executeCode — do NOT ask the engineer to copy/paste it manually.
`spark` is available in Genie's executeCode context.

```python
# TABLE VALIDATION — executed inline by Databricks Pipeline Advisor

import pandas as pd

tables_to_check = [
    # ("ROLE", "notebook_filename", "catalog.schema.table")
    ("SOURCE", "{notebook_name}", "{full_3_part_table_name}"),
    ("TARGET", "{notebook_name}", "{full_3_part_table_name}"),
    # one row per unique table across all notebooks
]

# Dynamically find tier catalogs — avoids hardcoding, keeps search fast
tier_keywords = ["bronze", "silver", "gold", "raw", "landing", "staging"]
all_catalogs  = [c.name for c in spark.catalog.listCatalogs()]
tier_catalogs = [c for c in all_catalogs if any(kw in c.lower() for kw in tier_keywords)]

results = []
for role, notebook, full_name in tables_to_check:
    parts       = full_name.split(".")
    table_name  = parts[-1]
    schema_name = parts[-2] if len(parts) >= 2 else "default"
    found       = spark.catalog.tableExists(full_name)
    suggestion  = None

    if not found:
        for cat in tier_catalogs:
            candidate = f"{cat}.{schema_name}.{table_name}"
            if spark.catalog.tableExists(candidate):
                suggestion = candidate
                break

    results.append({
        "role":       role,
        "notebook":   notebook,
        "expected":   full_name,
        "found":      "YES" if found else "NO",
        "suggestion": suggestion if suggestion else ("—" if found else "NOT FOUND"),
    })

df = pd.DataFrame(results)
print(df.to_string(index=False))
```

**Parse the executeCode printed output directly** — no paste-back step needed.
For each printed row store:
- `found = YES | NO`
- `suggestion = {3-part path} | — | NOT FOUND`
Attach to the corresponding table entries in the profile store. Proceed to Step 3.

**If executeCode fails** (spark unavailable, permission error, or any exception): fall back —
output the script and prompt:
```
Run this cell in a Databricks notebook and paste the full printed output below.
Type  skip  to proceed without table validation — all tables will be marked # REVIEW.
```
Parse the pasted output the same way.

**If engineer types `skip`:** Mark all tables as `UNVERIFIED`. Proceed to Step 3.

**If table name contains widget variables** (e.g. `{source_catalog}.{source_schema}.{source_table}`
where the actual catalog/schema/table are not yet resolved): mark as `UNVERIFIED` and
exclude from the `tables_to_check` list — do not generate a check for it.

---

## Step 3 — Analyze (silent, across all profiles)

Using all profiles:
1. Build dependency DAG — notebook A depends on B if A's source = B's target
2. Topological sort → execution order + parallel groups
3. Apply merge signals from `references/analysis-rules.md`
4. Detect redundancies (duplicate source reads, same target written by 2+ notebooks)
5. Detect orphans (no detected source or target)
6. Carry each profile's confidence level (HIGH/MEDIUM/LOW from Step 2) into merge candidate scoring — widget-parameterized sources downgrade to MEDIUM; filename-only inference downgrades to LOW

## Step 4 — Report

Output this exact structure:

```
DATABRICKS PIPELINE ADVISOR
────────────────────────────────────────────────────────────────────
Notebooks : {n}   Sources : {n}   Targets : {n}
────────────────────────────────────────────────────────────────────

EXECUTION ORDER
  STAGE 1 (parallel): {notebook names}
  STAGE 2 (depends on Stage 1): {notebook names}
  INDEPENDENT: {notebook names}

MERGE CANDIDATES
  MERGE-01 — {type}  [MERGE | KEEP SEPARATE]  [{HIGH|MEDIUM|LOW} confidence]
    Notebooks : {list}
    Reason    : {one sentence}
    Scoring   : {✓ or ✗ for each of the 7 factors — see analysis-rules.md}
    Decision  : MERGE | KEEP SEPARATE
    Risk      : {LOW | MEDIUM | HIGH}

REDUNDANCIES
  RED-01 — {type}: {description}  [{LOW|MEDIUM|HIGH} severity}]

ORPHANS
  {filename} — {reason no dependencies detected}

TABLE STATUS
  ────────────────────────────────────────────────────────────────────
  Role    Notebook            Expected                              Found  Suggestion
  ────────────────────────────────────────────────────────────────────
  SOURCE  Step01_Unload.py    dev_edf_bronze.default.orders         YES    —
  TARGET  Step03_CDC.py       dev_edf_silver.default.order_sum      NO     prod_edf_silver.default.order_sum
  ────────────────────────────────────────────────────────────────────
  ⚠  {n} table(s) not found — suggestion available, defaultValue will be corrected in output.
  ⚠  {n} table(s) not found with no suggestion — will be marked # REVIEW in output.

INVENTORY
  File                     Cells  Sources  Targets  Stage Types
  ──────────────────────────────────────────────────────────────
  {filename}               {n}    {n}      {n}      {list}

SUMMARY
  Merge candidates  : {n}
  Redundancies      : {n}
  Orphans           : {n}
  Execution stages  : {n}
────────────────────────────────────────────────────────────────────
{CONTEXT-AWARE COMMANDS — see rules below}
────────────────────────────────────────────────────────────────────
```

Confidence levels: HIGH = SRC/TGT widgets found, MEDIUM = spark.read/saveAsTable found, LOW = filename only.

**TABLE STATUS rendering rules:**
- All tables found → replace section body with: `All {n} tables verified in Unity Catalog.`
- Step 2.5 was skipped → replace section body with: `Table validation skipped — all tables marked # REVIEW in output.`
- Mix of found/not-found → show the full table as above; include only the ⚠ lines that apply (omit lines with n=0)
- UNVERIFIED tables (widget variables, unresolvable at analysis time) → omit from table, note count: `{n} table(s) use widget variables — verified at runtime by RuntimeError check in Cell 6.`

**Context-aware commands rule — choose the right block based on analysis result:**

If ALL merge candidates are KEEP SEPARATE:
```
Commands:
  @datastage-notebook-standardizer fix all              → standardize all {n} notebooks
  @datastage-notebook-standardizer fix Step01,Step03    → standardize specific notebooks only
  report only                                           → stop here, no changes made
```

If at least one merge candidate is MERGE:
```
Commands:
  merge all                                             → merge all MERGE candidates + fix kept-separate notebooks
  merge MERGE-01                                        → merge specific group only + fix kept-separate notebooks
  skip MERGE-02                                         → exclude group from merge, fix it individually instead
  @datastage-notebook-standardizer fix all              → skip merging, standardize all notebooks individually
  report only                                           → stop here, no changes made
```

If zero merge candidates found (no dependency patterns detected):
```
Commands:
  @datastage-notebook-standardizer fix all              → standardize all {n} notebooks
  @datastage-notebook-standardizer fix Step01           → standardize one specific notebook
  report only                                           → stop here, no changes made
```

**Never show `merge all` or `merge MERGE-xx` commands when all candidates are KEEP SEPARATE.**
**Always show `@datastage-notebook-standardizer fix all` as an option — it is always valid regardless of merge outcome.**
**Always show `report only` as the last option.**
**The `@datastage-notebook-standardizer` prefix is required — this routes the fix command to the
canonical skill. Do NOT show `fix all` as a bare command without the prefix.**

Also add to SUMMARY section when all are KEEP SEPARATE:
```
RECOMMENDED NEXT STEP:
  All notebooks should remain separate.
  Copy and run: @datastage-notebook-standardizer fix all
  This routes to the standardizer skill which will fix each notebook in sequence.
  Use this execution order for your Databricks Workflow:
  {repeat the execution order from the EXECUTION ORDER section}
```

Also add to SUMMARY section when result is mixed (some MERGE, some KEEP SEPARATE):
```
RECOMMENDED NEXT STEP:
  Type a merge command above to merge and fix in one pass (runs within this skill).
  Or copy and run: @datastage-notebook-standardizer fix all  to skip merging and standardize all individually.
```

---

## Step 4.5 — Persist Session to Workspace

**Run this immediately after outputting the Step 4 report — before waiting for any command.**
This step generates and executes a Python cell that saves the full analysis to the user's
workspace. Do NOT skip this step. It enables the standardizer to load structured data instead
of parsing conversation context, and enables resume if the session is interrupted.

**Note:** This step generates OPERATIONAL code (session management) — it is NOT part of any
notebook being standardized and is NOT subject to the notebook HARD RULES.

**Generate and execute this Python cell:**

```python
import json, os, re
from datetime import datetime

# ── Resolve current user ──────────────────────────────────────────
current_user = spark.sql("SELECT current_user()").collect()[0][0]

# ── Build deterministic session ID ───────────────────────────────
# Derive from the source folder name so standardizer can reconstruct it
_source_folder = "{source_folder}"   # e.g. /Workspace/Users/user/spa_party
_folder_name   = os.path.basename(_source_folder.rstrip("/"))
_safe_name     = re.sub(r"[^a-zA-Z0-9_-]", "_", _folder_name).strip("_").lower()
session_id     = f"{_safe_name}_{datetime.now().strftime('%Y%m%d')}"
session_path   = f"/Workspace/Users/{current_user}/migration_tmp/{session_id}"
session_file   = f"{session_path}/analysis.json"

# ── Check for existing session (resume guard) ────────────────────
_resume = False
if os.path.exists(session_file):
    with open(session_file) as _f:
        _existing = json.load(_f)
    _done  = sum(1 for v in _existing.get("fix_progress", {}).values() if v == "complete")
    _total = len(_existing.get("fix_queue", []))
    if _done > 0:
        print(f"⚠  Existing session found: {_done}/{_total} notebooks already fixed.")
        print(f"   Overwriting analysis — fix_progress will be reset to pending.")
        print(f"   To resume the previous session instead, type: list sessions")
    _resume = True

# ── Create session directory ──────────────────────────────────────
os.makedirs(session_path, exist_ok=True)

# ── Build session data — populate from analysis ───────────────────
# Replace every {placeholder} below with the actual value from the Step 2–3 analysis.
# fix_queue must be in topological execution order (Stage 1 first, then Stage 2, etc.)
session_data = {
    "schema_version": "1.0",
    "session_id":     session_id,
    "session_path":   session_path,
    "created_by":     current_user,
    "created_at":     datetime.now().isoformat(),
    "source_folder":  _source_folder,
    "status":         "analysis_complete",

    # One entry per notebook from Step 2 index
    "notebooks": [
        # {
        #   "filename":    "Step01_Unload.py",
        #   "seq_no":      1,
        #   "domain":      "SPA_PARTY",
        #   "sources":     ["dev_edf_bronze.default.orders"],
        #   "targets":     ["dev_edf_silver.default.order_stg"],
        #   "stage_types": ["SOURCE", "TRANSFORMER", "TARGET"],
        #   "cell_count":  12,
        #   "confidence":  "HIGH"
        # },
        {NOTEBOOK_LIST}
    ],

    # DAG execution order from Step 3
    "execution_order": {
        # "stage_1": ["Step01_Unload.py"],
        # "stage_2": ["Step03_CDC.py"],
        # "independent": []
        {EXECUTION_ORDER}
    },

    # Merge decisions from Step 3
    "merge_candidates": [
        # {
        #   "id": "MERGE-01", "type": "Linear Chain",
        #   "decision": "KEEP_SEPARATE",
        #   "notebooks": ["Step01_Unload.py", "Step03_CDC.py"],
        #   "risk": "LOW"
        # },
        {MERGE_CANDIDATES}
    ],

    # Table validation results from Step 2.5 (empty dict if skipped)
    # Schema: key = full 3-part table name, value = result dict
    # found: False = not found in Unity Catalog, True = found
    # suggestion: 3-part path if an alternative was found, None if none available
    # "dev_edf_bronze.default.orders": {"role": "SOURCE", "notebook": "Step01.py", "found": True,  "suggestion": None}
    # "dev_edf_silver.default.order_s": {"role": "TARGET", "notebook": "Step03.py", "found": False, "suggestion": "prod_edf_silver.default.order_s"}
    # When populating {TABLE_VALIDATION}: translate printed "YES" → True, "NO" → False,
    # "—" → None (suggestion for found rows), "NOT FOUND" → None (no suggestion available).
    "table_validation": {
        {TABLE_VALIDATION}
    },

    # Script profile from Step 0 (None if no script provided)
    "script_profile": {SCRIPT_PROFILE},

    # fix_queue: notebooks in topological order — standardizer processes in this order
    "fix_queue": [{FIX_QUEUE}],

    # fix_progress: all start as "pending" — standardizer updates to "complete" per notebook
    "fix_progress": {
        {FIX_PROGRESS_PENDING}   # "{filename}": "pending" for every notebook in fix_queue
    },

    # fix_plan: populated by standardizer during BATCH phase 1 scan — eliminates double scanning
    # key = filename, value = {"cells": [{"index": n, "content": "...", "fixes": [...]}]}
    # fixes list per cell: [{id, group, severity, confidence, description, before, after, assumed}]
    # Empty on creation — standardizer fills this before phase 2 begins
    "fix_plan": {},

    "completed_at": None
}

# ── Atomic write (write to .tmp then rename — prevents corruption on crash) ──
_tmp_file = session_file + ".tmp"
try:
    with open(_tmp_file, "w") as f:
        json.dump(session_data, f, indent=2)
    os.replace(_tmp_file, session_file)   # atomic on same filesystem
except Exception as e:
    if os.path.exists(_tmp_file):
        os.remove(_tmp_file)
    raise RuntimeError(f"[SESSION WRITE FAILED] {e}") from e

# ── Confirm ───────────────────────────────────────────────────────
_nb_count = len(session_data["fix_queue"])
print(f"✓ Session saved  : {session_file}")
print(f"  Session ID     : {session_id}")
print(f"  Notebooks      : {_nb_count} queued ({', '.join(session_data['fix_queue'])})")
_tv = session_data.get('table_validation') or {}
_tv_found     = sum(1 for v in _tv.values() if v.get('found') is True)
_tv_not_found = sum(1 for v in _tv.values() if v.get('found') is False)
print(f"  Table results  : {_tv_found} found  /  {_tv_not_found} not found  {'(validation skipped)' if not _tv else ''}")
print(f"  Script profile : {'yes' if session_data['script_profile'] else 'none'}")
```

**Placeholder substitution rules — apply before executing:**

| Placeholder | Replace with |
|---|---|
| `{source_folder}` | The folder path the user provided in Step 1 |
| `{NOTEBOOK_LIST}` | One dict per notebook from Step 2 profiles (all fields populated) |
| `{EXECUTION_ORDER}` | `"stage_1": [...]`, `"stage_2": [...]`, `"independent": [...]` from Step 3 DAG |
| `{MERGE_CANDIDATES}` | One dict per merge candidate from Step 3 (decision + scoring) |
| `{TABLE_VALIDATION}` | One entry per table from Step 2.5 output (or `{}` if skipped) |
| `{SCRIPT_PROFILE}` | Script profile dict from Step 0, or `None` if no script |
| `{FIX_QUEUE}` | Comma-separated quoted filenames in topological execution order |
| `{FIX_PROGRESS_PENDING}` | `"Step01.py": "pending", "Step03.py": "pending", ...` for all notebooks |

**After successful execution, append to the SUMMARY section of the Step 4 report:**
```
SESSION
  Saved to : /Workspace/Users/{current_user}/migration_tmp/{session_id}/analysis.json
  Run @datastage-notebook-standardizer fix all — session will be loaded automatically.
  To list all sessions: list sessions
  To delete this session manually: cleanup {session_id}
```

**Session management commands (handle at any time, before or after Step 5):**

`list sessions` — generate and execute:
```python
import json, os

current_user = spark.sql("SELECT current_user()").collect()[0][0]
base_path = f"/Workspace/Users/{current_user}/migration_tmp"

if not os.path.exists(base_path):
    print("No sessions found.")
else:
    rows = []
    for sid in sorted(os.listdir(base_path)):
        sfile = f"{base_path}/{sid}/analysis.json"
        if os.path.exists(sfile):
            with open(sfile) as f:
                s = json.load(f)
            done    = sum(1 for v in s.get("fix_progress", {}).values() if v == "complete")
            total   = len(s.get("fix_queue", []))
            rows.append((sid, s.get("status","?"), s.get("created_at","?")[:19], done, total))
    if not rows:
        print("No sessions found.")
    else:
        print(f"{'Session ID':<45} {'Status':<22} {'Created':<20} {'Done':>4}{'Total':>6}")
        print("─" * 100)
        for sid, status, created, done, total in rows:
            print(f"{sid:<45} {status:<22} {created:<20} {done:>4}/{total:<5}")
```

`cleanup {session_id}` — generate and execute:
```python
import json, os

current_user = spark.sql("SELECT current_user()").collect()[0][0]
_session_id = "SESSION_ID_HERE"   # ← agent replaces with the session ID from the user's command
_sfile = f"/Workspace/Users/{current_user}/migration_tmp/{_session_id}/analysis.json"
if os.path.exists(_sfile):
    # Read source_folder BEFORE removing — we need it for the confirmation message
    try:
        with open(_sfile) as _f:
            _s_data = json.load(_f)
        _src_folder = _s_data.get("source_folder", None)
    except Exception:
        _src_folder = None
    os.remove(_sfile)
    print(f"✓ Session metadata removed : {_sfile}")
    if _src_folder:
        print(f"  Fixed notebooks retained : {_src_folder}/fixed/")
    else:
        print(f"  Fixed notebooks retained : check your source folder/fixed/ in Workspace browser")
else:
    print(f"Not found: {_sfile}")
```
**Replace `SESSION_ID_HERE` with the actual session ID from the user's `cleanup ...` command before executing.**

---

## Step 5 — Execute (after command)

**Content guard — check before any merge or fix:**
If notebook content was NOT provided in Step 1 for any notebook named in the command
(i.e. only filenames were given, no actual code), stop immediately and respond:
```
Cannot proceed — notebook content required.
Paste the full content of these notebooks to continue:
  {list each notebook whose content is missing}
```
Do not attempt to generate, infer, or fabricate notebook content.

**Table correction rules — apply to every table widget in every output notebook:**

For each `source_table`, `target_table`, `source_table1`, `source_table2`, etc. widget:

| Validation status | Action |
|---|---|
| `found = YES` | Use expected path as-is. No change. |
| `found = NO`, suggestion exists | Replace widget `defaultValue` with suggestion. Add comment: `# Table corrected: {expected} not found — updated to {suggestion} (from validation check)` |
| `found = NO`, no suggestion | Keep original defaultValue. Add: `# REVIEW: {table} — not found in Unity Catalog and no suggestion available. Verify before running.` |
| `UNVERIFIED` (widget variable or skipped) | Keep original defaultValue. The `RuntimeError` check in Cell 6 will catch this at runtime. |

These corrections apply to both the `merge` path and the `fix all` path.

**If command is `merge ...`:**
Read `references/fix-rules-embedded.md` and assemble merged notebook.
See assembly order below.

**If command is bare `fix all` or `fix Step01,Step03` (without `@datastage-notebook-standardizer` prefix):**
The canonical path is `@datastage-notebook-standardizer fix all` — if the user typed the bare
command, remind them: "For best results use: `@datastage-notebook-standardizer fix all` — this
routes to the canonical standardizer skill. Continuing with embedded rules as fallback."
Then run standardizer rules from `references/fix-rules-embedded.md` on each specified notebook
individually. For each notebook, generate and execute a write cell (atomic pattern — see below)
that writes the fixed notebook to `{_source_folder}/fixed/{filename}.py` —
fixed notebooks land in a `fixed/` folder next to the originals (same parent as source folder).
`_source_folder` is set from `{source_folder}` placeholder in Step 4.5. Label each write cell clearly:
```
── Fixing: Step01_Unload_ENR005.py ──────────────────────
[executeCode write cell — writes to {_source_folder}/fixed/Step01_Unload_ENR005.py]
── Fixing: Step03_Ins_SSD_TYP.py ────────────────────────
[executeCode write cell — writes to {_source_folder}/fixed/Step03_Ins_SSD_TYP.py]
```
Use the same atomic write pattern as the standardizer skill:
embed full fixed content in a Python triple-quoted string (escape `"""` as `\"\"\"`),
write to `.tmp` path, then `os.replace` to final path.

Assembly order:
1. `# Databricks notebook source`
2. Cell 0: `%md` purpose summary (enriched with ds_job_name from script if available)
3. Cell 1: `%md` "1 — Setup & Imports" header
4. Cell 2: unified imports
5. Cell 3: `%md` "2 — Parameters & Configuration" header
6. Cell 4: unified parameters (widget defaultValues from script profile if available)
7. Cell 5: `%md` "3 — Table Validation" header
8. Cell 6: table existence checks for every source and target
   - Include only tables that will exist at runtime (external sources + final targets)
   - For every intermediate table eliminated by this merge: omit its check and add:
     `# Intermediate table {name} eliminated — direct DataFrame handoff, check skipped`
   - One check per table variable, no exceptions for tables that remain
   - Use RuntimeError, not assert (assert is suppressed by Python -O flag and gives poor job failure messages):
     ```python
     if not spark.catalog.tableExists(source_table):
         raise RuntimeError(f"[PIPELINE ABORT] Source table not found: {source_table}. Check widget defaultValues and Unity Catalog permissions.")
     ```

If script type is PRE-PROCESSING and data_logic items exist:
9. Cell 7: `%md` "4 — Pre-processing & Data Cleaning" header
         `_Cleaning logic from {script_name}.ksh — applied before source read_`
10. Cell 8+: one cell per data_logic item with traceability block:
    ```python
    # COMMAND ----------
    # Source file  : {script_name}.ksh
    # Logic type   : PRE-PROCESSING
    # Shell cmd    : {original shell command}
    {converted PySpark code}
    # REVIEW: {what engineer must verify}
    ```
Then stage cells from notebooks in DAG order.

If script type is POST-PROCESSING:
- Inject data_logic cells AFTER last target write cell
- Add section header: `## N — Post-processing`
- Same traceability block format as above

If script type is ORCHESTRATION:
- No extra cells injected — only widget defaultValues enriched

For each approved merge group — eliminate intermediate tables:
- Remove write cell from upstream notebook
- Remove read cell from downstream notebook
- Connect DataFrames directly
- Add `# Intermediate table {name} eliminated — direct DataFrame handoff`
- Add `# REVIEW: {table_name} no longer written — verify no external consumers`

For notebooks kept separate — include their cells with origin separator:
```
# ══════════════════════════════════════════════════
# FROM: {original_notebook_filename}
# ══════════════════════════════════════════════════
```

Apply standardizer fixes inline during assembly (not as a second pass):
- I000: canonicalize imports
- G/EXPR: DataStage syntax → PySpark (includes G-NULL-GUARD for F.expr null+empty guard pattern)
- Q: SQL context fixes
- R: source/target conversion
- N: naming standards
- I002: collapse passthrough DataFrames
- L: logic fixes (aggregations, PIVOT, MISSING_HANDLER, CDC, FUNNEL, REMOVE_DUPLICATES)
- S: structural fixes (SparkSession.builder, __main__, mkdirs, display() removal)
- SEC: security fixes (hardcoded credentials → clear value + dbutils.secrets stub)

**count() REVIEW:** Every `print(f"[{stage}] count={df.count()}")` line emitted in source/target
cells must include: `# REVIEW: .count() triggers a full scan — remove for large tables`

## Step 6 — Output

```
MERGE SUMMARY
─────────────────────────────────────────
Merged    : {n} groups — {filenames}
Kept      : {filenames}
Eliminated: {n} intermediate tables
Fixes     : {n} applied (AUTO: {n}  REVIEW: {n})

MIGRATION LOG
─────────────────────────────────────────
Date              : {today YYYY-MM-DD}
Fix rules version : fix-rules-embedded.md (sync: 2026-04-01)
Notebooks in      : {list all input notebooks}
Script analyzed   : {script_name}.ksh | none
Merges executed   : {MERGE-01: Step01 + Step03 → Step01_03_domain.py | none}
Written to        : {source_folder}/fixed/{merged_filename}.py
Tables corrected  : {expected_path → suggestion_path | none}
Tables flagged    : {n} — search # REVIEW in output
Fixes AUTO        : {list fix IDs}
Fixes REVIEW      : {list fix IDs — require engineer verification before running}
─────────────────────────────────────────
```

Generate and execute a write cell that writes the merged notebook to workspace:
- `output_path = f"{_source_folder}/fixed/{merged_filename}.py"` — lands next to the originals
- `_source_folder` is set in Step 4.5; `os.makedirs(f"{_source_folder}/fixed", exist_ok=True)` first
- Use atomic write pattern: embed full merged content in triple-quoted string (escape `"""` as `\"\"\"`),
  write to `.tmp`, then `os.replace` to final path.
- After execution, print: `✓ Written : {output_path}`

Then REVIEW checklist for any REVIEW-tier fixes.

---

## References

`references/analysis-rules.md` — load in Steps 2–3.
Filename patterns, source/target extraction, merge signal scoring,
redundancy detection, DAG logic, consolidation decision rules.

`references/script-analysis-rules.md` — load in Step 0 only (when script detected).
Script classification, extraction rules, shell→PySpark conversion map,
notebook mapping algorithm, discard list, report format.

`references/fix-rules-embedded.md` — load in Step 5 only.
All standardizer fix rules (Groups G Q R N I L S + stage patterns + expression map).
